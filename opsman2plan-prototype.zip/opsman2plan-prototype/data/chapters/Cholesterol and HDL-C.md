# Underwriting Manual: Cholesterol and HDL-C

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Cholesterol is a lipid molecule essential for cell membranes and hormone synthesis. HDL-C (high-density lipoprotein cholesterol) is known as "good cholesterol" because it helps remove excess cholesterol from the bloodstream. Hypercholesterolemia is a medical condition characterized by elevated cholesterol levels, which may be asymptomatic but increases risk for atherosclerosis and cardiovascular disease.

**Typical Signs and Symptoms:**
- Usually asymptomatic
- Xanthomas (cholesterol deposits in skin/tendons) in severe cases
- Arcus senilis (cholesterol ring in cornea)
- Symptoms of coronary artery disease (chest pain, shortness of breath) if advanced

### 1b. Risk Factors Affecting Prognosis and Protective Factors

**Risk Factors:**
- Age (risk increases with age)
- Male sex
- Smoking
- Hypertension
- Diabetes mellitus
- Family history of premature coronary artery disease
- Obesity
- Sedentary lifestyle
- Low HDL-C (<40 mg/dl)

**Protective Factors:**
- High HDL-C (>60 mg/dl)
- Regular physical activity
- Healthy diet
- Compliance with lipid-lowering therapy
- Non-smoking status
- Good control of blood pressure and blood sugar

### 1c. Classification of Severity

**Severity Cut-offs:**
- **Total Cholesterol:**
  - Desirable: <200 mg/dl
  - Borderline high: 200–239 mg/dl
  - High: ≥240 mg/dl

- **HDL-C:**
  - Low: <40 mg/dl (men), <50 mg/dl (women)
  - High: ≥60 mg/dl

- **Cholesterol/HDL-C Ratio:**
  - Optimal: <5.0
  - Moderate risk: 5.0–7.4
  - High risk: ≥7.5

### 1d. Diagnostic Tests

- Fasting lipid profile (total cholesterol, HDL-C, LDL-C, triglycerides)
- Non-fasting lipid profile (acceptable for screening)
- ApoA-1/ApoB ratio (occasionally available)
- Other tests: Lipoprotein(a), hs-CRP (for advanced risk stratification)

### 1e. Treatments

**Lifestyle Modification:**
- Diet (low saturated fat, increased fiber)
- Exercise
- Weight loss
- Smoking cessation

**Medications:**
- Statins (atorvastatin, simvastatin, rosuvastatin)
- Ezetimibe
- PCSK9 inhibitors (alirocumab, evolocumab)
- Fibrates (fenofibrate, gemfibrozil)
- Niacin
- Bile acid sequestrants (cholestyramine)

---

## 2. Underwriting Focus

**Key Factors to Assess:**
- Total cholesterol and HDL-C values
- Cholesterol/HDL-C ratio (preferred)
- Age, sex, and smoking status
- Other cardiovascular risk factors (hypertension, diabetes, family history)
- Compliance with treatment and lifestyle modification
- Evidence of end-organ damage (CAD, stroke, PAD)
- Results of diagnostic tests
- Co-morbid conditions (obesity, metabolic syndrome)

---

## 3. Requirements

- Recent fasting lipid profile (within 12 months)
- Age, sex, smoking status
- Medical history (including family history of CAD, diabetes, hypertension)
- Medication list and compliance documentation

**Additional Requirements (if indicated):**
- ApoA-1/ApoB ratio (if available)
- Evidence of cardiovascular disease (ECG, stress test, imaging)
- Physician’s statement for severe or familial cases

---

## 4. Rating

**NOTES TO LIPID RATINGS:**
- Use Chol/HDL-C ratio in preference to total cholesterol.
- If HDL-C is not available, use total cholesterol.
- If cholesterol is <200 mg/dl, rating is +0 regardless of ratio.
- LDL-C/HDL-C ratios are not used for rating.
- ApoA-1/ApoB ratio may modify the Chol/HDL-C ratio rating.

**ApoA-1/ApoB Ratio Credits/Debits:**

| ApoA-1/ApoB Ratio | Rating Adjustment |
|-------------------|------------------|
| 3.6 and up        | -100             |
| 2.0–3.5           | -50              |
| 0.90–1.9          | 0                |
| 0.80–0.89         | +50              |
| <0.80             | +75              |

**Low cholesterol (<180 mg/dl) in applicants over age 70 should be closely scrutinized for cancer risk.**

**Cholesterol and HDL-C Rating Table:**

| Age Group | Cholesterol (mg/dl) | Rating |
|-----------|---------------------|--------|
| <30       | 250–300             | +0     |
| <30       | 301–350             | +75    |
| <30       | 351–400             | +100   |
| <30       | >400                | Decline|
| 31–55     | 250–300             | +0     |
| 31–55     | 301–350             | +50    |
| 31–55     | 351–400             | +75    |
| 31–55     | >400                | IC     |
| 56–64     | 250–300             | +0     |
| 56–64     | 301–350             | +25    |
| 56–64     | 351–400             | +50    |
| 56–64     | >400                | +150   |
| 65+       | 250–300             | +0     |
| 65+       | 301–350             | +0     |
| 65+       | 351–400             | +25    |
| 65+       | >400                | +50    |

**Chol/HDL-C Ratio Rating Table:**

| Age Group | Chol/HDL-C Ratio | Rating |
|-----------|------------------|--------|
| All ages  | <7.4             | +0     |
| <30       | 7.5–8.5          | +50    |
| <30       | 8.6–10.5         | +75    |
| <30       | 10.6–12.5        | +100   |
| <30       | 12.6–14.5        | IC     |
| <30       | >14.5            | Decline|
| 31–55     | 7.5–8.5          | +0     |
| 31–55     | 8.6–10.5         | +50    |
| 31–55     | 10.6–12.5        | +75    |
| 31–55     | 12.6–14.5        | +125   |
| 31–55     | >14.5            | Decline|
| 56–64     | 7.5–8.5          | +0     |
| 56–64     | 8.6–10.5         | +25    |
| 56–64     | 10.6–12.5        | +50    |
| 56–64     | 12.6–14.5        | +75    |
| 56–64     | >14.5            | Decline|
| 65+       | 7.5–8.5          | +0     |
| 65+       | 8.6–10.5         | +0     |
| 65+       | 10.6–12.5        | +25    |
| 65+       | 12.6–14.5        | +50    |
| 65+       | >14.5            | IC     |

**WP, ADB, and LTC Table:**

| LIFE Rating | WP      | ADB   | LTC (for LIFE > +75, Decline) |
|-------------|---------|-------|-------------------------------|
| +0          | +0      | +0    | +0                            |
| +25 to +50  | Decline | 1.5x  | +50                           |
| +75 to +100 | Decline | 2x    | Decline                       |
| >+100       | Decline | Decline| Decline                       |

---

## 5. Additional Considerations

### Credits for Protective Factors

| Protective Factor                | Credit Applied |
|----------------------------------|---------------|
| Excellent compliance             | -25           |
| HDL-C >60 mg/dl                  | -25           |
| Non-smoker                       | -25           |
| Documented improvement (>20% drop in Chol/HDL-C ratio) | -50 |

---

**Note to Underwriters:**
Always use the Chol/HDL-C ratio in preference to total cholesterol. Consider all risk and protective factors, and apply credits/debits as indicated. For applicants over age 70 with cholesterol <180 mg/dl, assess for possible underlying malignancy.
