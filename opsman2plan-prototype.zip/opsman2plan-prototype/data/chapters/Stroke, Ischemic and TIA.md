# Stroke, Ischemic and TIA – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
- **Stroke** is a sudden loss of brain function due to a disturbance in blood supply, either from blockage (ischemic) or bleeding (hemorrhagic).  
- **Ischemic stroke** is caused by blockage of an artery supplying the brain.  
- **TIA (Transient Ischemic Attack)** is a temporary episode of neurological dysfunction caused by loss of blood flow, with symptoms resolving within 24 hours and no permanent damage.

**Typical Signs and Symptoms:**  
- Sudden weakness or numbness (especially on one side of the body)
- Sudden confusion, trouble speaking, or understanding speech
- Sudden vision problems in one or both eyes
- Sudden trouble walking, dizziness, loss of balance or coordination
- Sudden severe headache with no known cause

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Age (older age increases risk)
- Hypertension
- Diabetes mellitus
- Smoking
- Hyperlipidemia
- Atrial fibrillation
- Previous stroke or TIA
- Carotid artery disease
- Obesity
- Sedentary lifestyle
- Excessive alcohol use

**Protective Factors:**  
- Good control of blood pressure, cholesterol, and diabetes
- Smoking cessation
- Regular physical activity
- Healthy diet (low salt, low saturated fat)
- Compliance with prescribed medications (antiplatelets, statins, anticoagulants if indicated)
- Regular medical follow-up

---

### 1c. Classification of Severity

**Severity is commonly classified using the Modified Rankin Scale (mRS):**

| Severity   | Symptoms/Findings                                                                 |
|------------|-----------------------------------------------------------------------------------|
| Minimal    | TIA or mini-stroke, symptoms resolved within 24 hours, mRS 0, no deficits         |
| Mild       | Mild stroke, symptoms resolved within 6 months, mRS 1-2, no significant deficits  |
| Moderate   | Moderate stroke, symptoms may persist 6-12 months, mRS 3, mild-moderate deficits  |
| Severe     | Severe stroke, permanent symptoms, mRS 4-5, significant disability                 |

---

### 1d. Diagnostic Tests

- **Neuroimaging:** CT scan, MRI (to confirm diagnosis and assess extent)
- **Carotid ultrasound:** To assess for carotid artery disease
- **Echocardiogram:** To assess for cardiac sources of emboli
- **ECG/Holter monitor:** To detect atrial fibrillation
- **Blood tests:** Lipids, glucose, coagulation profile
- **Other:** Transcranial Doppler, MR angiography, CT angiography

---

### 1e. Treatments

- **Acute treatments:** Thrombolysis (alteplase), mechanical thrombectomy (for ischemic stroke)
- **Secondary prevention:**  
  - Antiplatelet agents (aspirin, clopidogrel)
  - Anticoagulants (warfarin, DOACs) for atrial fibrillation
  - Statins (atorvastatin, simvastatin)
  - Antihypertensives (ACE inhibitors, beta-blockers, calcium channel blockers)
  - Diabetes management (metformin, insulin)
  - Lifestyle modification (diet, exercise, smoking cessation)
- **Rehabilitation:** Physical, occupational, and speech therapy

---

## 2. Underwriting Focus

Underwriters should focus on:
- Age at onset and at application
- Number of events and time since last event
- Severity and residual deficits (using mRS or similar scale)
- Control of risk factors (BP, cholesterol, diabetes)
- Smoking status
- Presence of atrial fibrillation or other cardiac disease
- Neuroimaging findings (extent of infarct, hemorrhage, white matter changes)
- Compliance with medications and follow-up
- Co-morbid conditions (CAD, diabetes, COPD, PAD, depression)

---

## 3. Requirements

- Attending physician statement (APS) with details of event(s), residuals, and follow-up
- Recent neurological consultation report
- Neuroimaging reports (CT/MRI)
- Carotid ultrasound or vascular imaging
- ECG/Echocardiogram reports
- Blood tests (lipids, glucose, renal function)
- Details of risk factor control and medication compliance

---

## 4. Rating

### TIA and Stroke Severity Classification

| Criteria                                      | Minimal                | Mild                   | Moderate                | Severe                  |
|-----------------------------------------------|------------------------|------------------------|-------------------------|-------------------------|
| Symptoms                                      | Resolved <24h          | Resolved <6 months     | May persist 6-12 months | Permanent               |
| Defined by attending as                       | TIA or Mini Stroke     | Mild Stroke            | Moderate Stroke         | Severe Stroke           |
| Modified Rankin Scale                         | 0                      | 1-2                    | 3                       | 4-5                     |
| Cognitive Status                              | Normal                 | Normal                 | Normal/almost normal    | May be impaired         |
| Instrumental Activities of Daily Living (IADL)| Able to carry on       | Able to carry on       | May need minimal assist | Requires assistance     |
| Basic Activities of Daily Living (ADL)        | Able to carry on       | Able to carry on       | May need minimal assist | Requires assistance     |
| Motor Deficit                                 | None                   | None                   | Fully mobile, may use cane | Unable to walk unassisted |
| MRI/CT scan                                  | Normal                 | Normal/minimal ischemia| Visible ischemia/infarct| Visible ischemia/infarct|

---

### TIA and Stroke Rating Table (Synthetic Data)

| Age at Application | Time Since Last Event | Minimal (TIA) | Mild Stroke | Moderate Stroke | Severe Stroke |
|--------------------|----------------------|---------------|-------------|----------------|--------------|
| <50                | 0-6 months           | Postpone      | Postpone    | Postpone       | Decline      |
| <50                | 6-12 months          | +140          | +260        | Postpone       | Decline      |
| <50                | 1-3 years            | +90           | +210        | +270           | Decline      |
| <50                | >3 years             | +60           | +160        | +210           | Decline      |
| 50-59              | 0-6 months           | Postpone      | Postpone    | Postpone       | Decline      |
| 50-59              | 6-12 months          | +110          | +170        | +220           | Decline      |
| 50-59              | 1-3 years            | +80           | +120        | +170           | Decline      |
| 50-59              | >3 years             | +60           | +110        | +160           | Decline      |
| 60-74              | 0-6 months           | Postpone      | Postpone    | Postpone       | Decline      |
| 60-74              | 6-12 months          | +70           | +110        | +160           | Decline      |
| 60-74              | 1-3 years            | +50           | +80         | +120           | Decline      |
| 60-74              | >3 years             | +0 to +40     | +70         | +110           | Decline      |
| ≥75                | 0-6 months           | Postpone      | Postpone    | Postpone       | Decline      |
| ≥75                | 6-12 months          | +40           | +60         | +110           | Decline      |
| ≥75                | 1-3 years            | +0 to +40     | +50         | +100           | Decline      |
| ≥75                | >3 years             | +0            | +0 to +40   | +60            | Decline      |

---

### Smoking Debit Table (Synthetic Data)

| Smoking Status         | <49   | 50-69         | 70-79        | ≥80         |
|-----------------------|--------|---------------|--------------|-------------|
| <1 pack/day           | Decline| +60 to +110   | +35 to +60   | +0 to +35   |
| >1 pack/day           | Decline| Decline       | Decline      | Decline     |
| Occasional cigar      | +0     | +0            | +0           | +0          |
| Daily cigar           | Rate as cigarettes, <1 pack/day |

---

### Basic Credits (Synthetic Data, Age >50)

| Criteria                                                      | Credit  |
|---------------------------------------------------------------|---------|
| BP/Lipids within range for 2 years                            | -20     |
| Negative exercise stress test (see criteria)                  | -30 (if rating ≤+110), -55 (if rating >+110) |
| No evidence of disease progression (carotid US/MRI, 2 years)  | -30     |
| Pro-BNP test normal (last 12 months)                          | -15     |
| Use of 2+ protective medications (ASA, beta-blocker, statin)  | -15     |
| Meets 4+ healthy lifestyle criteria (see list)                | -20     |

---

### WP and ADB (Synthetic Data)

| Life Rating     | WP      | ADB     |
|-----------------|---------|---------|
| +0              | +0      | +0      |
| +30 to +60      | Decline | 1.5x    |
| +80 to +110     | Decline | 2x      |
| >+110           | Decline | Decline |

---

### LTC (Synthetic Data)

| Condition                                                      | LTC Rating |
|---------------------------------------------------------------|------------|
| Stroke                                                        | Decline    |
| TGA, Migraine equivalent, or TIA (single, no residuals, >2yr) | +60        |
| TGA, Migraine equivalent, or TIA (single, no residuals, <2yr) | Decline    |
| DM, smoker, CAD, chronic AF, retinal artery occlusion, white matter changes | Decline |
| More than one TIA                                             | Decline    |

---

## 5. Additional Considerations

### Co-morbid Conditions and Risk Factors (Synthetic Data)

| Condition/Factor                | Adjustment/Action         |
|---------------------------------|---------------------------|
| Atrial fibrillation (chronic, TIA >3yr, no CVD) | Add +60 to +80 |
| Atrial fibrillation (chronic, others)           | Decline        |
| Atrial fibrillation (paroxysmal)                | IC             |
| ASD without surgery                             | Rate as Mild Stroke |
| ASD with surgery, no deficit (<6mo)             | Postpone       |
| ASD with surgery, no deficit (6-12mo)           | +60            |
| ASD with surgery, no deficit (>12mo)            | Standard       |
| Blood pressure +0 to +60                        | Sum debits     |
| Blood pressure >+60                             | Decline        |
| Build +0 to +110                                | Sum debits     |
| Build >+110                                     | IC/Decline     |
| Carotid stenting                                | Rate as endarterectomy +30 |
| COPD mild                                       | IC             |
| COPD moderate/severe                            | Decline        |
| Coronary disease mild                           | IC             |
| Coronary disease moderate/severe                | Decline        |
| Diabetes type 1                                 | Decline        |
| Diabetes type 2, good control, no CAD           | Sum debits +60 |
| Diabetes type 2, otherwise                      | Decline        |
| Depression mild                                 | +0             |
| Depression moderate                             | +80            |
| Depression severe                               | Decline        |
| Endarterectomy (<6mo)                           | Postpone       |
| Endarterectomy (>6mo)                           | TIA/Stroke rating +60 |
| Hyperlipidemia +0 to +60                        | Sum debits     |
| Hyperlipidemia >+60                             | Decline        |
| Medication-caused event (<6mo)                  | Postpone       |
| Medication-caused event (>6mo, no deficits)     | +0             |
| Medication-caused event (otherwise)             | Rate as Stroke |
| Patent foramen ovale (no surgery)               | Rate as Mild Stroke |
| Patent foramen ovale (surgery, no deficit <6mo) | Postpone       |
| Patent foramen ovale (surgery, no deficit 6-12mo)| +60           |
| Patent foramen ovale (surgery, no deficit >12mo)| Standard       |
| Peripheral arterial disease mild                | IC             |
| Peripheral arterial disease moderate/severe     | Decline        |
| Recurrence: TIA >1                              | Postpone 1yr, +60 |
| Recurrence: TGA >2                              | Postpone 6mo, +60 |
| Recurrence: Stroke >1                           | Decline        |
| Sleep apnea mild, well controlled 2yr           | +0             |
| Sleep apnea moderate, well controlled 2yr       | +60            |
| Sleep apnea severe, well controlled 2yr         | IC             |
| Stress ECG positive                             | IC/Decline     |

---

### Credits for Protective Factors (Synthetic Data)

| Criteria/Factor                                  | Credit  |
|--------------------------------------------------|---------|
| BP/Lipids within range (2 years)                 | -20     |
| Negative exercise stress test                    | -30 or -55 |
| No disease progression (carotid US/MRI, 2 years) | -30     |
| Pro-BNP normal (last 12 months)                  | -15     |
| Use of 2+ protective medications                 | -15     |
| Meets 4+ healthy lifestyle criteria              | -20     |

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.
