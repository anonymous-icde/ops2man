# Alcohol Misuse and Alcoholism – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Alcohol misuse and alcoholism (alcohol use disorder) is a chronic condition characterized by excessive or uncontrolled consumption of alcohol, leading to health, social, or occupational problems.

**Typical Signs and Symptoms:**  
- Strong cravings for alcohol  
- Loss of control over drinking  
- Withdrawal symptoms (tremors, sweating, anxiety)  
- Tolerance (needing more to achieve the same effect)  
- Neglect of responsibilities  
- Continued use despite harm

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Early onset of heavy drinking  
- High daily or binge consumption  
- Family history of alcoholism  
- Co-existing psychiatric disorders  
- Poor social support  
- History of relapse  
- Abnormal liver function tests (LFTs)  
- Presence of alcohol-related medical complications

**Protective Factors:**  
- Sustained abstinence  
- Participation in support programs (e.g., AA)  
- Good social support  
- Compliance with treatment  
- No evidence of organ damage  
- Stable employment and relationships

---

### 1c. Classification of Severity

| Severity Level | Criteria (Synthetic Example)                                  |
|----------------|--------------------------------------------------------------|
| Mild           | Occasional misuse, no withdrawal, no complications           |
| Moderate       | Regular heavy use, some withdrawal, minor complications      |
| Severe         | Daily use, withdrawal, major complications (liver, CNS, etc) |


---

### 1d. Diagnostic Tests

- Liver function tests (AST, ALT, GGT, bilirubin)
- Carbohydrate-deficient transferrin (CDT)
- Mean corpuscular volume (MCV)
- HDL cholesterol, triglycerides
- Screening questionnaires (AUDIT, CAGE)
- Imaging (liver ultrasound if indicated)

---

### 1e. Treatments

- Behavioral therapy and counseling
- Medications: naltrexone, acamprosate, disulfiram, topiramate
- Support groups (e.g., Alcoholics Anonymous)
- Medical management of withdrawal
- Treatment of complications (liver disease, psychiatric care)

---

## 2. Underwriting Focus

Underwriters should focus on:
- Current and past drinking patterns (amount, frequency, duration)
- Time since last use or reduction
- Laboratory markers (LFTs, CDT, MCV, HDL, triglycerides)
- History of withdrawal, relapses, or treatment
- Presence of complications (liver, cardiac, neurological, psychiatric)
- Participation in support or rehabilitation programs
- Co-morbid conditions (depression, other substance use)

---

## 3. Requirements

| Requirement                  | Details / Cut-off                        |
|------------------------------|------------------------------------------|
| Attending physician statement| Diagnosis, treatment, complications      |
| Recent labs                  | LFTs, CDT, MCV, HDL, triglycerides (last 12 months) |
| Details of complications     | Hospitalizations, liver imaging, psychiatric reports |
| Documentation of abstinence  | If claimed, evidence required            |
| Participation in support     | AA or similar, if applicable             |

---

## 4. Rating

### 1. Alcohol Markers

| Marker/History                                  | Age      | Rating         |
|-------------------------------------------------|----------|---------------|
| Positive CDT, other markers positive            | >60      | +60           |
| Positive CDT, other markers positive            | <60      | +120          |
| Positive CDT, other markers negative            | Any      | Standard      |
| Abnormal LFTs                                   | Any      | Individual Consideration (IC) |

---

### 2. Liver Function Tests (LFTs)

| LFTs Status                | Alcohol Marker      | Rating         |
|----------------------------|--------------------|----------------|
| Elevated LFTs, no criticism| Positive           | IC             |
| Elevated LFTs, no criticism| Negative           | See LFTs table |
| Elevated LFTs, no criticism| No marker available| See LFTs table |
| Elevated LFTs, with criticism| Any              | Rate as heavy drinking |

---

### 3. Current Daily Alcohol Drinking Pattern

| Number of Drinks per Day | Rating         |
|-------------------------|---------------|
| 0–2                     | Standard      |
| 3–4                     | Standard      |
| 5–6                     | +60 (IC)      |
| 7–10                    | Rate as alcohol excess |
| >10                     | Rate as alcohol abuse  |

---

### 4. Alcohol Excess (Heavy Drinking or Criticism, Binge Drinking)

| Time Since Last Use/Reduction | <30 yrs | 30–49 yrs | 50–64 yrs | 65+ yrs |
|------------------------------|---------|-----------|-----------|---------|
| 0–1 year                     | Decline | +140      | +100      | +80     |
| 1–2 years                    | +180    | +100      | +60       | +30     |
| 2–3 years                    | +100    | +60       | Standard  | Standard|
| 3–4 years                    | +60     | Standard  | Standard  | Standard|
| >4 years                     | Standard | Standard | Standard  | Standard|

**Note:To determine if alcohol excess is present if an only if: either there is a positive alcohol marker or if previous guidelines conclude rating as alcohol excess. 

**Factors Associated with Alcohol Excess**

| Factor                                              | Rating         |
|-----------------------------------------------------|---------------|
| Recurrent heavy use                                 | Rate as 0–1 yr |
| Positive CDT, normal LFTs, other markers negative   | Rate as 0–1 yr |
| Positive CDT, normal LFTs, other markers positive   | Decline (IC)   |
| Elevated LFTs                                       | IC             |
| With substance abuse                                | Postpone 5 yrs, then IC |
| Attending AA                                        | Credit -25     |

---

### 5. Alcohol Abuse or Dependence (Abstinence After Treatment)

| Time Since Last Use | <30 yrs | 30–49 yrs | 50–64 yrs | 65+ yrs |
|---------------------|---------|-----------|-----------|---------|
| 0–1 year            | Decline | Decline   | Decline   | Decline |
| 1–2 years           | Decline | Decline   | +180      | +100    |
| 2–3 years           | +180    | +120      | +80       | +40     |
| 3–4 years           | +120    | +80       | +40       | Standard|
| 4–5 years           | +80     | +40       | Standard  | Standard|
| >5 years            | +40     | Standard  | Standard  | Standard|

**Note: this is only applicable when there is an evidence of abstinence after some treatment. 

**Factors Associated with Alcohol Abuse or Dependence**

| Factor                                 | Rating         |
|-----------------------------------------|---------------|
| Current drinking                       | Usually Decline|
| Positive CDT or HAA                    | Decline        |
| Elevated LFTs                          | IC             |
| With substance abuse                   | Postpone 5 yrs, then IC |
| Currently in residential treatment     | Decline        |
| Use of disulfiram, naltrexone, etc.    | IC             |
| Attending AA                           | Credit -25     |
| One relapse <2 years                   | Postpone       |
| One relapse 2–10 years                 | Add +50        |
| One relapse >10 years                  | Add +25        |
| Two or more relapses                   | Postpone 5 yrs, then IC |
| Anti-social personality                | Decline        |
| Severe depression                      | Decline        |
| Moderate depression                    | IC             |
| Mild depression                        | Add +0 to +40  |
| Gambling disorder                      | IC             |
| Suicide attempt <5 years               | Decline        |
| Suicide attempt >5 years               | IC             |
| Cardiomyopathy, current drinking       | Decline        |
| Cardiomyopathy, abstinent              | IC             |
| Portal hypertension, bleeding          | Decline        |
| Portal hypertension, no bleeding       | IC             |
| Korsakoff's syndrome                   | Decline        |
| Wernicke's encephalopathy, current     | Decline        |
| Wernicke's encephalopathy, remote      | IC             |
| Atrial fibrillation, current drinking  | Decline        |
| Atrial fibrillation, abstinent         | Rate as AF     |
| Liver transplant                       | Decline        |

---

### 6. WP, ADB, and LTC Ratings

| LIFE Rating         | WP      | ADB     | LTC      |
|---------------------|---------|---------|----------|
| Standard            | Standard| Standard| Standard |
| +25 to +60          | Decline | Decline | Decline  |
| +80 or higher       | Decline | Decline | Decline  |
| Ratable alcohol abuse, dependence, or excess | Decline | Decline | Decline |
| >4 drinks/day       | Decline | Decline | Decline  |

---

## 5. Additional Considerations

**Co-morbidities and Risk Factors**

| Additional Factor                  | Rating Adjustment      |
|------------------------------------|-----------------------|
| Elevated LFTs, no alcohol criticism| See LFTs table        |
| Abnormal alcohol marker, LFTs normal| IC                   |
| Abnormal alcohol marker, LFTs abnormal| Rate as heavy drinking |
| Negative history, on long-term Antabuse| IC                |

**Protective Factors (Credits)**

| Protective Factor                  | Credit  |
|------------------------------------|---------|
| Attending AA or similar program    | -25     |
| Sustained abstinence >5 years      | -25     |
| Stable employment and relationships| -25     |

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.
