# Osteoarthritis – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Osteoarthritis (OA) is a degenerative joint disease involving the breakdown of cartilage and underlying bone, leading to pain, stiffness, and loss of joint function.

**Typical Signs and Symptoms:**  
- Joint pain (worse with activity, relieved by rest)  
- Morning stiffness (usually <30 minutes)  
- Swelling or tenderness  
- Reduced range of motion  
- Crepitus (grating sensation)  
- Joint deformity in advanced cases

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Older age  
- Female sex  
- Obesity  
- Previous joint injury or surgery  
- Repetitive joint use  
- Family history of OA  
- Co-morbidities (e.g., diabetes, metabolic syndrome)

**Protective Factors:**  
- Maintaining healthy weight  
- Regular low-impact exercise  
- Early and consistent use of physical therapy  
- Good pain management and medication adherence  
- Use of assistive devices as needed

---

### 1c. Classification of Severity

Severity is classified using clinical and functional criteria, referencing ACR and OARSI guidelines:

| Severity | Symptoms/Medications | Joint Function | Functional Status | Surgery History | Therapy Use |
|----------|----------------------|---------------|-------------------|-----------------|-------------|
| Mild     | Occasional pain, uses acetaminophen or NSAIDs as needed | Full range of motion, no deformity | No activity limitation | None or 1 minor procedure | Occasional PT/OT, not recent |
| Moderate | Frequent pain, regular NSAIDs or topical agents | Some loss of motion, mild deformity | Occasional limitation, may miss work | 1-2 joint surgeries | PT/OT within past 6 months |
| Severe   | Daily pain, requires opioids or regular steroid injections | Significant loss of motion, visible deformity | Persistent limitation, uses cane/walker, periods of disability | >2 surgeries or joint replacement | Ongoing PT/OT or recent hospitalization |

---

### 1d. Diagnostic Tests

- **Clinical assessment:** History and physical exam  
- **X-rays:** Joint space narrowing, osteophytes, subchondral sclerosis  
- **MRI:** For soft tissue and cartilage evaluation (if needed)  
- **Laboratory tests:** To rule out other causes  
- **Functional assessment:** Gait analysis, range of motion testing

---

### 1e. Treatments

- **Non-pharmacologic:** Physical therapy, occupational therapy, weight loss, exercise, assistive devices  
- **Pharmacologic:**  
  - Acetaminophen  
  - NSAIDs (ibuprofen, naproxen, celecoxib)  
  - Topical NSAIDs (diclofenac gel)  
  - Intra-articular corticosteroid injections  
  - Opioids (for severe cases, short-term)  
  - Duloxetine (for chronic pain)  
- **Procedures:** Joint injections, viscosupplementation  
- **Surgical:** Joint replacement (arthroplasty), osteotomy, arthroscopy

---

## 2. Underwriting Focus

- Severity and frequency of symptoms  
- Functional limitations and disability history  
- Medication use (especially narcotics or steroids)  
- Number and type of surgeries  
- Use of assistive devices  
- Recent or pending physical/occupational therapy  
- Co-morbidities (obesity, diabetes, cardiovascular disease)  
- Pending or recommended surgery

---

## 3. Requirements

- Attending physician statement (APS) with diagnosis, treatment, and follow-up  
- Recent imaging reports (X-ray, MRI if available)  
- Details of medication use (including narcotics, steroids)  
- History of surgeries and hospitalizations  
- Physical/occupational therapy records  
- Functional status assessment

---

## 4. Rating

### Osteoarthritis Rating Table (Synthetic, Near-Original Values)

| Severity  | LIFE   | WP     | ADB    | LTC    |
|-----------|--------|--------|--------|--------|
| Mild      | +0     | +0     | +0     | +0     |
| Moderate (non-weight bearing joint) | +30    | +0     | +0     | +35    |
| Moderate (weight bearing joint)     | +60    | +60    | +60    | +85    |
| Severe   | +110   | Decline | Decline| Decline|

**Legend:**  
- **+0** = Standard rate  
- **+30, +35, +60, +85, +110** = Extra mortality loading (basis points, synthetic and near to original)  
- **Decline** = Application not accepted

---

## 5. Additional Considerations

### Co-morbidities and Other Risk Factors

| Condition/Factor                | LIFE   | WP     | ADB    | LTC    |
|---------------------------------|--------|--------|--------|--------|
| Pending or recommended surgery  | +85    | IC     | IC     | Decline|
| Ratable build                   | Add build rating | Decline | Decline | Decline |
| Diabetes or cardiovascular disease | Add +35 to +60 | IC     | IC     | IC     |
| Use of chronic opioids          | +60    | Decline | Decline| Decline|
| Non-compliance with therapy     | IC     | IC     | IC     | IC     |
| Use of wheelchair or bedridden  | Decline| Decline | Decline| Decline|

**Credits for Protective Factors:**  
- Good compliance with therapy: -30  
- Successful joint replacement with full recovery: -55  

---

**All values above are synthetic, near to but not the same as original values, and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.**
