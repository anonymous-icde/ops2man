# Drug Dependence and Addiction  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Drug dependence and addiction is a chronic, relapsing disorder characterized by compulsive drug seeking, continued use despite harmful consequences, and long-lasting changes in the brain.

**Typical Signs and Symptoms:**
- Craving and compulsive drug use
- Loss of control over drug intake
- Withdrawal symptoms when not using
- Tolerance (needing more for same effect)
- Neglect of responsibilities
- Social, legal, or financial problems

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Family history of substance use disorder
- Co-occurring psychiatric disorders
- Early onset of drug use
- Polysubstance abuse
- Unstable employment or living situation
- History of relapse
- Legal issues

**Protective Factors:**
- Long-term abstinence
- Stable employment and living environment
- Compliance with treatment and follow-up
- Supportive social network
- No co-morbid psychiatric or medical conditions
- No history of relapse

#### 1c. Classification of Severity

| Severity                | Criteria                                                                                   |
|-------------------------|-------------------------------------------------------------------------------------------|
| Current Use             | Ongoing use of addictive drugs                                           |
| Early Abstinence        | Abstinent <3 years, no maintenance therapy                                                |
| Intermediate Abstinence | Abstinent 3–5 years, no maintenance therapy                                               |
| Sustained Abstinence    | Abstinent >5 years, no maintenance therapy                                                |
| Maintenance Therapy     | On methadone, buprenorphine, or naltrexone for opioid dependence                          |
| Relapse History         | One or more relapses after initial abstinence                                             |

#### 1d. Diagnostic Tests

- Urine drug screening
- Liver function tests
- Hepatitis and HIV screening
- Psychiatric evaluation
- Review of prescription monitoring programs
- Medical records review

#### 1e. Treatments

- **Medications:** Methadone, buprenorphine, naltrexone (for opioid dependence); disulfiram, acamprosate (for alcohol)
- **Behavioral therapy:** Cognitive-behavioral therapy, motivational interviewing
- **Support groups:** 12-step programs, peer support
- **Inpatient or outpatient rehabilitation**
- **Ongoing monitoring and follow-up**

---

### 2. Underwriting Focus

- Current drug use status
- Duration and stability of abstinence
- Type of drugs used (illicit, prescription, polysubstance)
- History and number of relapses
- Participation in and compliance with treatment
- Maintenance therapy status
- Employment and living stability
- Co-morbid psychiatric or medical conditions
- Legal or criminal history
- Laboratory and medical evidence of complications

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Physician’s statement      | Diagnosis, treatment, compliance         |
| Urine drug screen          | Recent, negative for all substances      |
| Lab tests                  | Liver function, hepatitis, HIV           |
| Psychiatric evaluation     | If co-morbid mental health conditions    |
| Employment verification    | For stability assessment                 |
| Legal history              | If prior convictions or ongoing issues   |

---

### 4. Rating

#### Drug Dependence and Addiction Ratings (Synthetic Example)

| Status/Scenario                                 | Life    | WP      | ADB     | LTC     |
|-------------------------------------------------|---------|---------|---------|---------|
| Current use                                     | Decline | Decline | Decline | Decline |
| Abstaining <3 years                             | +150    | Decline | Decline | Decline |
| Abstaining 3–5 years                            | +75     | +100    | Decline | Decline |
| Abstaining >5 years                             | +25     | +25     | +25     | +25     |
| Methadone for chronic pain                      | IC, rate as chronic pain | IC | IC | IC      |
| Methadone for opioid dependence                 | Decline | Decline | Decline | Decline |
| Naltrexone for opioid dependence                | Decline | Decline | Decline | Decline |
| Buprenorphine for chronic pain                  | Rate as chronic pain | Rate as chronic pain | Rate as chronic pain | Rate as chronic pain |
| Buprenorphine maintenance <3 years abstinent    | Decline | Decline | Decline | Decline |
| Buprenorphine maintenance 3–5 years abstinent   | IC, consider +200 | IC | IC | IC      |
| Buprenorphine maintenance >5 years abstinent    | IC, consider +150 | IC | IC | IC      |
| Off maintenance, 0–3 years since completion     | +75     | +75     | +75     | +75     |
| Off maintenance, >3 years since completion      | +25     | +25     | +25     | +25     |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Scenario/Factor                                 | Rating Adjustment                |
|-------------------------------------------------|----------------------------------|
| Polysubstance abuse (including alcohol)         | Postpone minimum 4 years, then IC|
| One relapse                                     | +75 to Decline                   |
| Two or more relapses                            | IC                               |
| Unstable employment or self-employed (unstable) | Postpone                         |
| Co-morbid psychiatric impairments               | IC                               |
| Prior felony convictions                        | IC to Decline                    |
| Unstable domestic environment                   | Postpone                         |

#### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| Stable employment and living situation    | -50         |
| No relapses in >5 years                  | -25         |
| Compliance with treatment and follow-up   | -50         |
| Supportive social network                 | -25         |

---

**Legend:**  
- IC = Individual Consideration  
- WP = Waiver of Premium  
- ADB = Accidental Death Benefit  
- LTC = Long-Term Care  

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes
