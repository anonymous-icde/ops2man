# Blood Pressure – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Blood pressure is the force exerted by circulating blood on the walls of the arteries. Hypertension (high blood pressure) is a chronic condition where blood pressure readings are consistently above normal.

**Typical Signs and Symptoms:**  
- Often asymptomatic  
- Headaches  
- Dizziness  
- Visual disturbances  
- Nosebleeds  
- Chest pain or shortness of breath (in severe cases)

---

### 1b. Risk and Protective Factors

**Risk Factors:**  
- Older age  
- Male sex  
- Family history  
- Obesity  
- High salt intake  
- Sedentary lifestyle  
- Smoking  
- Excessive alcohol  
- Diabetes  
- Chronic kidney disease  
- Poor medication adherence

**Protective Factors:**  
- Good medication compliance  
- Healthy diet (low sodium, DASH)  
- Regular exercise  
- Weight control  
- Smoking cessation  
- Limiting alcohol  
- Regular monitoring

---

### 1c. Classification of Severity

| Category                | Systolic (mmHg) | Diastolic (mmHg) |
|-------------------------|-----------------|------------------|
| Normal                  | <120            | <80              |
| Elevated                | 120–129         | <80              |
| Hypertension Stage 1    | 130–139         | 80–89            |
| Hypertension Stage 2    | 140–159         | 90–99            |
| Hypertension Stage 3    | ≥160            | ≥100             |

---

### 1d. Diagnostic Tests

- Office BP measurements (multiple readings)
- Ambulatory BP monitoring (ABPM)
- Home BP monitoring
- Blood/urine tests (renal, glucose, lipids)
- ECG, echocardiogram (if indicated)
- Fundoscopy

---

### 1e. Treatments

- Lifestyle modification (diet, exercise, weight loss, sodium reduction)
- Antihypertensive medications:
  - Thiazide diuretics
  - ACE inhibitors
  - ARBs
  - Calcium channel blockers
  - Beta-blockers
  - Others (aldosterone antagonists, vasodilators)
- Treat secondary causes if present
- Regular follow-up

---

## 2. Underwriting Focus

- Age, sex, BP readings (systolic/diastolic)
- Duration and control of hypertension
- Medication compliance and number of medications
- End-organ damage (heart, kidney, eyes)
- Co-morbidities (diabetes, obesity, CKD, CAD)
- Smoking status
- Lab and diagnostic results
- Family history of CVD

---

## 3. Requirements

| Requirement                  | Details / Cut-off                        |
|------------------------------|------------------------------------------|
| Attending physician statement| Diagnosis, treatment, complications      |
| Recent BP readings           | Multiple readings over time              |
| Laboratory tests             | Renal, electrolytes, lipids, glucose     |
| ECG/Echo                     | If history of heart disease or LVH       |
| Urinalysis                   | Proteinuria, kidney function             |
| Details of co-morbidities    | Diabetes, CAD, CKD, obesity              |

---

## 4. Rating

### FEMALE TABLE (Machine Readable)

| Diastolic | Age Group | Systolic 136-140 | Systolic 141-145 | Systolic 146-150 | Systolic 151-155 | Systolic 156-160 | Systolic 161-165 | Systolic 166-170 | Systolic 171-175 | Systolic 176-180 | Systolic 181-185 | Systolic 186-190 | Systolic 191-195 | Systolic 196-200 |
|-----------|-----------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|
| 60-95     | 17-39     | 0                | 0                | 25               | 30               | 40               | 55               | 70               | 90               | 110              | 130              | 160              | 190              | 220              |
| 60-95     | 40-49     | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 150              | 180              |
| 60-95     | 50-59     | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 45               | 60               | 80               | 100              |
| 60-95     | 60-69     | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 70               | 90               |
| 60-95     | 70+       | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 55               | 70               |
| 96-100    | 17-39     | 30               | 35               | 40               | 55               | 70               | 85               | 100              | 120              | 140              | 160              | 190              | 220              | 250              |
| 96-100    | 40-49     | 0                | 0                | 25               | 30               | 40               | 55               | 70               | 85               | 100              | 120              | 140              | 170              | 200              |
| 96-100    | 50-59     | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 150              |
| 96-100    | 60-69     | 0                | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 65               | 80               | 100              | 120              |
| 96-100    | 70+       | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 70               | 90               |
| 101-105   | 17-39     | 60               | 70               | 80               | 95               | 110              | 130              | 150              | 170              | 190              | 210              | 240              | 270              | 300              |
| 101-105   | 40-49     | 40               | 50               | 60               | 70               | 85               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 101-105   | 50-59     | 0                | 0                | 25               | 30               | 40               | 55               | 70               | 85               | 100              | 120              | 140              | 170              | 200              |
| 101-105   | 60-69     | 0                | 0                | 0                | 0                | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 150              | 180              |
| 101-105   | 70+       | 0                | 0                | 0                | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 140              | 170              | 200              |
| 106-110   | 17-39     | 100              | 120              | 130              | 150              | 170              | 190              | 210              | 240              | 260              | 290              | 320              | 350              | 380              |
| 106-110   | 40-49     | 80               | 90               | 100              | 120              | 140              | 160              | 180              | 200              | 220              | 250              | 280              | 310              | 340              |
| 106-110   | 50-59     | 40               | 50               | 60               | 70               | 85               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 106-110   | 60-69     | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 106-110   | 70+       | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 111-115   | Any       | 150              | 170              | 190              | 210              | 230              | 250              | 270              | 300              | 320              | 350              | 400              | 450              | 500              |
| 116-120   | Any       | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          |

---

### MALE TABLE (Machine Readable)

| Diastolic | Age Group | Systolic 136-140 | Systolic 141-145 | Systolic 146-150 | Systolic 151-155 | Systolic 156-160 | Systolic 161-165 | Systolic 166-170 | Systolic 171-175 | Systolic 176-180 | Systolic 181-185 | Systolic 186-190 | Systolic 191-195 | Systolic 196-200 |
|-----------|-----------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|------------------|
| 60-95     | 17-39     | 0                | 0                | 20               | 25               | 35               | 50               | 65               | 85               | 100              | 120              | 150              | 180              | 210              |
| 60-95     | 40-49     | 0                | 0                | 0                | 0                | 20               | 30               | 45               | 60               | 75               | 95               | 115              | 140              | 170              |
| 60-95     | 50-59     | 0                | 0                | 0                | 0                | 0                | 20               | 30               | 45               | 60               | 80               | 100              | 130              | 160              |
| 60-95     | 60-69     | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 20               | 30               | 50               | 70               | 100              | 130              |
| 60-95     | 70+       | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 20               | 30               | 50               | 80               | 100              |
| 96-100    | 17-39     | 25               | 30               | 35               | 50               | 65               | 80               | 95               | 110              | 130              | 150              | 180              | 210              | 240              |
| 96-100    | 40-49     | 0                | 0                | 20               | 25               | 35               | 50               | 65               | 80               | 95               | 110              | 130              | 160              | 190              |
| 96-100    | 50-59     | 0                | 0                | 0                | 0                | 20               | 30               | 45               | 60               | 75               | 95               | 115              | 140              | 170              |
| 96-100    | 60-69     | 0                | 0                | 0                | 0                | 0                | 20               | 30               | 45               | 60               | 80               | 100              | 130              | 160              |
| 96-100    | 70+       | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 0                | 20               | 30               | 50               | 80               | 100              |
| 101-105   | 17-39     | 50               | 60               | 70               | 85               | 100              | 120              | 140              | 160              | 180              | 200              | 230              | 260              | 290              |
| 101-105   | 40-49     | 30               | 40               | 50               | 60               | 75               | 90               | 110              | 130              | 150              | 170              | 200              | 230              | 260              |
| 101-105   | 50-59     | 20               | 25               | 30               | 40               | 55               | 70               | 85               | 100              | 120              | 140              | 160              | 190              | 220              |
| 101-105   | 60-69     | 0                | 0                | 20               | 30               | 45               | 60               | 75               | 95               | 115              | 140              | 160              | 190              | 220              |
| 101-105   | 70+       | 0                | 0                | 0                | 20               | 30               | 45               | 60               | 80               | 100              | 120              | 140              | 170              | 200              |
| 106-110   | 17-39     | 90               | 100              | 110              | 130              | 150              | 170              | 190              | 210              | 230              | 260              | 290              | 320              | 350              |
| 106-110   | 40-49     | 70               | 80               | 90               | 110              | 130              | 150              | 170              | 190              | 210              | 240              | 270              | 300              | 330              |
| 106-110   | 50-59     | 40               | 50               | 60               | 70               | 85               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 106-110   | 60-69     | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 106-110   | 70+       | 25               | 35               | 50               | 65               | 80               | 100              | 120              | 140              | 160              | 180              | 210              | 240              | 270              |
| 111-115   | Any       | 130              | 150              | 170              | 190              | 210              | 230              | 250              | 280              | 300              | 330              | 380              | 430              | 480              |
| 116-120   | Any       | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          | Decline          |

---

### JUVENILES

| Age Group | Blood Pressure Status      | Rating         |
|-----------|---------------------------|---------------|
| 0–16      | Any elevated blood pressure| IC            |

---

### WP and ADB

| Life Rating      | WP      | ADB     |
|------------------|---------|---------|
| 0                | 0       | 0       |
| 25 to 50         | 1.5x    | 1.5x    |
| 75 to 100        | 2x      | 2x      |
| >100             | Decline | Decline |
| Decline          | Decline | Decline |

---

### LTC

| Blood Pressure Status         | LTC Rating                |
|------------------------------|---------------------------|
| Up to 160/95, no other risks | Life Rating (before credits) |
| >160/95                      | Decline                   |

---

## 5. Additional Considerations

### a) Co-morbid Conditions and Risk Factors

| Additional Condition         | Rating Adjustment      |
|-----------------------------|-----------------------|
| Diabetes mellitus           | 25 or 50              |
| Proteinuria                 | 50                    |
| Coronary artery disease     | See CAD section       |
| Chronic kidney disease      | 50 or Decline         |
| Obesity (BMI >35)           | 25                    |
| Smoking                     | 25                    |
| Poor medication compliance  | 50 or Decline         |
| End-organ damage            | 50 or Decline         |

---

### b) Credits for Protective Factors (Multiples of 5)

| Criteria/Factor                        | Credit (Tables) |
|----------------------------------------|-----------------|
| Cholesterol <220 mg/dL                 | -5              |
| Chol/HDL ratio <5.0                    | -5              |
| Build within standard table            | -5              |
| Negative cardiac investigations        | -5 or -10       |
| Total points ≥8 and age <55            | -15             |
| Total points ≥8 and age ≥55            | -10             |
| Total points =7 and age <55            | -10             |
| Total points =7 and age ≥55            | -5              |

| Age Group | Max Table Credits |
|-----------|------------------|
| <55       | -15              |
| ≥55       | -20              |

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical
