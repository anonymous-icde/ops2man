# Build-Risk Assessment  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Build-risk assessment evaluates the mortality and morbidity risk associated with an applicant’s height and weight (build), using standardized tables to determine if the build is underweight, average, overweight, or obese.

**Typical Signs and Symptoms:**
- Overweight/obesity: increased body fat, central adiposity, elevated BMI
- Underweight: low body mass, muscle wasting, frailty
- Associated symptoms may include fatigue, reduced exercise tolerance, or signs of comorbid conditions (e.g., hypertension, diabetes)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- High BMI or weight above standard tables
- Central obesity (waist circumference)
- Family history of cardiovascular disease
- Co-existing hypertension, diabetes, or dyslipidemia
- Sedentary lifestyle
- Smoking
- Rapid weight gain or loss

**Protective Factors:**
- Normal or near-normal build
- Regular physical activity
- Healthy diet
- No family history of premature cardiovascular disease
- Good control of blood pressure, cholesterol, and glucose
- Stable weight over time

#### 1c. Classification of Severity

**Severity is classified by comparing the applicant’s weight to standard build tables for their height and sex.**

- **Overweight/Obese:**
  - +25 to +400 ratings based on weight above standard for height
  - Ratings increase with higher weight categories
- **Underweight:**
  - +50 to +100 ratings based on weight below standard for height
  - Separate tables for male and female

**BMI cut-offs:**
  - Underweight: BMI <18.5
  - Normal: BMI 18.5–24.9
  - Overweight: BMI 25–29.9
  - Obese: BMI ≥30

#### 1d. Diagnostic Tests

- Height and weight measurement (required)
- BMI calculation
- Waist circumference (optional, for central obesity)
- Blood pressure, cholesterol, glucose (for risk stratification)
- Cardiac stress testing (if indicated for credits)

#### 1e. Treatments

- **Lifestyle:** diet modification, increased physical activity, behavioral therapy
- **Medications:** weight loss agents (e.g., orlistat, liraglutide)
- **Surgery:** bariatric surgery for severe obesity
- **Nutritional support:** for underweight or malnutrition
- **Management of comorbidities:** antihypertensives, statins, diabetes medications

---

### 2. Underwriting Focus

- Applicant’s height and weight (current and historical trends)
- BMI and waist circumference
- Family history of premature cardiovascular disease
- Presence of comorbidities (hypertension, diabetes, dyslipidemia)
- Blood pressure, cholesterol, and glucose levels
- Results of cardiac investigations (if available)
- Smoking status
- Age and sex

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Accurate height and weight | Measured, not self-reported              |
| BMI calculation            | Required for all applicants              |
| Blood pressure, cholesterol, glucose | For risk credits               |
| Cardiac stress test        | For maximum credits (if indicated)       |
| Family history             | Premature CVD, diabetes                  |
| Medical history            | Comorbid conditions                      |

---

### 4. Rating

#### Overweight Build Table (Adults) – Synthetic Data

| Height | +25 | +50 | +75 | +100 | +125 | +150 | +200 | +250 | +300 | +350 | +400 |
|--------|-----|-----|-----|------|------|------|------|------|------|------|------|
| 4'8"   | 190 | 201 | 207 | 214  | 222  | 226  | 239  | 248  | 258  | 266  | 275  |
| 4'9"   | 194 | 205 | 211 | 218  | 226  | 232  | 243  | 252  | 262  | 270  | 279  |
| 4'10"  | 199 | 209 | 215 | 222  | 228  | 236  | 248  | 257  | 264  | 276  | 284  |
| 4'11"  | 203 | 213 | 221 | 226  | 234  | 240  | 252  | 261  | 270  | 279  | 288  |
| 5'0"   | 204 | 217 | 225 | 230  | 239  | 244  | 256  | 262  | 274  | 282  | 292  |
| 5'1"   | 213 | 222 | 228 | 234  | 243  | 248  | 260  | 269  | 278  | 288  | 296  |
| 5'2"   | 214 | 226 | 233 | 244  | 247  | 254  | 262  | 272  | 281  | 289  | 299  |
| 5'3"   | 218 | 231 | 237 | 248  | 253  | 259  | 272  | 281  | 288  | 299  | 308  |
| 5'4"   | 226 | 237 | 242 | 252  | 260  | 266  | 279  | 289  | 298  | 308  | 316  |
| 5'5"   | 232 | 244 | 249 | 256  | 266  | 274  | 286  | 294  | 306  | 313  | 323  |
| 5'6"   | 238 | 249 | 255 | 260  | 272  | 279  | 294  | 303  | 312  | 322  | 328  |
| 5'7"   | 243 | 255 | 263 | 270  | 278  | 288  | 302  | 311  | 320  | 329  | 338  |
| 5'8"   | 252 | 263 | 270 | 274  | 288  | 296  | 309  | 319  | 328  | 337  | 346  |
| 5'9"   | 256 | 271 | 271 | 288  | 296  | 304  | 318  | 328  | 338  | 344  | 356  |
| 5'10"  | 260 | 278 | 281 | 294  | 302  | 308  | 326  | 334  | 344  | 354  | 366  |
| 5'11"  | 270 | 283 | 291 | 302  | 312  | 316  | 334  | 344  | 352  | 364  | 374  |
| 6'0"   | 278 | 291 | 301 | 312  | 319  | 324  | 342  | 352  | 362  | 372  | 382  |
| 6'1"   | 287 | 301 | 308 | 318  | 324  | 332  | 349  | 361  | 372  | 381  | 391  |
| 6'2"   | 296 | 309 | 311 | 326  | 334  | 342  | 358  | 368  | 380  | 388  | 398  |
| 6'3"   | 304 | 315 | 321 | 334  | 344  | 352  | 366  | 379  | 389  | 399  | 409  |
| 6'4"   | 312 | 323 | 333 | 344  | 352  | 358  | 372  | 388  | 398  | 408  | 411  |
| 6'5"   | 319 | 333 | 340 | 352  | 358  | 368  | 384  | 397  | 407  | 417  | 427  |
| 6'6"   | 327 | 341 | 341 | 358  | 368  | 376  | 394  | 406  | 416  | 426  | 436  |
| 6'7"   | 333 | 347 | 351 | 368  | 378  | 386  | 402  | 415  | 425  | 433  | 442  |
| 6'8"   | 340 | 355 | 361 | 376  | 388  | 392  | 411  | 422  | 432  | 441  | 454  |
| 6'9"   | 351 | 361 | 371 | 384  | 392  | 402  | 418  | 433  | 442  | 451  | 461  |
| 6'10"  | 359 | 371 | 381 | 393  | 400  | 412  | 429  | 442  | 452  | 461  | 472  |
| 6'11"  | 367 | 381 | 391 | 401  | 408  | 419  | 437  | 451  | 462  | 471  | 481  |

*Note: +25 is not charged if this is the only rating applicable. Ratings above +200 are speculative.*
*Note: for a weight that goes below the weight corresponding to the +25 rating, simply go with rating of +0*

#### Underweight Build Table (Adults) – Synthetic Data

| Height | Male +100 | Male +50 | Male Avg | Female +100 | Female +50 | Female Avg |
|--------|-----------|----------|----------|-------------|------------|------------|
| 4'8"   | 80        | 90       | 121      | 69          | 80         | 106        |
| 4'9"   | 82        | 92       | 124      | 70          | 81         | 108        |
| 4'10"  | 84        | 96       | 127      | 73          | 84         | 114        |
| 4'11"  | 86        | 97       | 130      | 76          | 88         | 116        |
| 5'0"   | 88        | 101      | 133      | 77          | 90         | 119        |
| 5'1"   | 90        | 102      | 136      | 79          | 93         | 124        |
| 5'2"   | 92        | 103      | 139      | 81          | 96         | 126        |
| 5'3"   | 94        | 108      | 143      | 84          | 99         | 129        |
| 5'4"   | 96        | 111      | 147      | 86          | 100        | 132        |
| 5'5"   | 99        | 113      | 151      | 88          | 103        | 135        |
| 5'6"   | 100       | 116      | 154      | 91          | 106        | 137        |
| 5'7"   | 101       | 119      | 158      | 93          | 110        | 140        |
| 5'8"   | 102       | 122      | 162      | 96          | 111        | 143        |
| 5'9"   | 109       | 125      | 166      | 98          | 112        | 146        |
| 5'10"  | 111       | 128      | 170      | 101         | 116        | 154        |
| 5'11"  | 112       | 131      | 174      | 104         | 119        | 159        |
| 6'0"   | 116       | 134      | 178      | 107         | 121        | 160        |
| 6'1"   | 120       | 137      | 182      | 110         | 124        | 164        |
| 6'2"   | 122       | 139      | 186      | 113         | 128        | 168        |
| 6'3"   | 123       | 143      | 190      | 116         | 129        | 172        |
| 6'4"   | 129       | 146      | 194      | 119         | 134        | 174        |
| 6'5"   | 130       | 149      | 198      | 122         | 137        | 180        |
| 6'6"   | 131       | 152      | 202      | 125         | 140        | 184        |
| 6'7"   | 134       | 154      | 206      | 128         | 143        | 188        |
| 6'8"   | 143       | 157      | 210      | 131         | 146        | 192        |
| 6'9"   | 144       | 160      | 214      | 134         | 149        | 199        |
| 6'10"  | 145       | 162      | 218      | 137         | 152        | 201        |
| 6'11"  | 150       | 164      | 222      | 140         | 155        | 206        |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Condition/Factor                          | Rating Adjustment         |
|-------------------------------------------|--------------------------|
| Family history of premature CVD (<60)     | No additional debits     |
| With rateable hypertension                | Sum debits               |
| With diabetes mellitus                    | Sum debits               |
| Combination with other impairments        | Refer to specific impairment |

---

**Note:**
- Ratings of +50 or more for build cannot be improved to STD+ or preferred.
- Table is not applicable for combination impairments (e.g., build and diabetes, CAD).
- All values and tables above are
