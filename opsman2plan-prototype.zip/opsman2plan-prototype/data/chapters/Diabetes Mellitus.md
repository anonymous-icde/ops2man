# Diabetes Mellitus – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Diabetes mellitus is a chronic metabolic disorder characterized by high blood glucose levels due to defects in insulin secretion, insulin action, or both. The main types are Type 1 (autoimmune, insulin-dependent), Type 2 (insulin resistance ± deficiency), and gestational diabetes (onset during pregnancy).

**Typical Signs and Symptoms:**  
- Increased thirst and urination
- Fatigue
- Blurred vision
- Unintentional weight loss (Type 1)
- Slow-healing wounds
- Recurrent infections

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Poor glycemic control (high HbA1c)
- Early age of onset
- Long duration of diabetes
- Presence of complications (retinopathy, nephropathy, neuropathy, CVD)
- Smoking
- Obesity
- Hypertension and dyslipidemia
- Non-adherence to treatment

**Protective Factors:**  
- Good glycemic control (HbA1c <7.1%)
- Regular follow-up and monitoring
- Healthy diet and regular exercise
- Blood pressure and lipid control
- Non-smoker status
- Early detection and management of complications

---

### 1c. Classification of Severity

| Severity   | Criteria (synthetic example)                                  |
|----------------|---------------------------------------------------------------|
| Mild           | no complications, short duration                 |
| Moderate       | minor complications ( mild microalbuminuria), moderate duration |
| Severe         | major complications (proliferative retinopathy), long duration               |

---

### 1d. Diagnostic Tests

- Fasting plasma glucose
- HbA1c (glycated hemoglobin)
- Oral glucose tolerance test
- Random plasma glucose
- Urine microalbumin
- Lipid profile
- Renal function tests
- Eye exam (retinopathy screening)
- Foot exam (neuropathy screening)

---

### 1e. Treatments

- **Type 1:** Insulin (glargine, lispro, aspart, etc.), lifestyle management
- **Type 2:** Oral agents (metformin, sulfonylureas, DPP-4 inhibitors, SGLT2 inhibitors, GLP-1 agonists), insulin if needed, lifestyle management
- **Gestational:** Diet, insulin if needed
- **Other:** Blood pressure and lipid-lowering agents, antiplatelet therapy, regular monitoring

---

## 2. Underwriting Focus

Underwriters should focus on:
- Type and duration of diabetes
- Age at diagnosis and at application
- Glycemic control (HbA1c trends)
- Presence and severity of complications (retinopathy, nephropathy, neuropathy, CVD)
- Blood pressure and lipid control
- Smoking status
- Compliance with treatment and follow-up
- Co-morbid conditions (hypertension, obesity, depression)

---

## 3. Requirements

| Requirement                  | Details / Cut-off                        |
|------------------------------|------------------------------------------|
| Attending physician statement| Diagnosis, treatment, complications      |
| Recent labs                  | HbA1c, fasting glucose, lipids, renal function (last 6–12 months) |
| Urine microalbumin           | Required                                 |
| Eye and foot exam reports    | If available                             |
| Details of complications     | Hospitalizations, reoperations           |

---

## 4. Rating

### 1. DIABETES TYPE

#### Gestational Diabetes

| Status                | Treatment/Control           | Rating         |
|-----------------------|----------------------------|---------------|
| Currently pregnant    | Diet or oral medication     | IC            |
|                       | Insulin                    | Postpone      |
| Not pregnant          | HbA1c ≤ 6.0                | Standard      |
|                       | HbA1c 6.1–6.4              | +40           |
|                       | HbA1c ≥ 6.5                | Rate as Type 2|

#### Prediabetes

| Age      | Other Risk Factors Present | Rating         |
|----------|---------------------------|---------------|
| <40      | None                      | +40           |
| 40–49    | Any                       | Standard      |
| 50–59    | Any                       | Standard      |
| 60–69    | Any                       | Standard+     |
| 70+      | Any                       | Preferred     |

---

### 2. BASIC RATING

#### Type 1 Diabetes

| Age at Application | Basic Rating | Minimum Rating after Credits |
|--------------------|--------------|-----------------------------|
| 0–16               | Decline      | Decline                     |
| 17–19              | +160         | +120                        |
| 20–29              | +120         | +80                         |
| 30–39              | +80          | +50                         |
| 40–49              | +50          | +30                         |
| 50–59              | +30          | Standard                    |
| 60–69              | Standard     | Standard+                   |
| 70+                | Standard     | Preferred                   |

#### Type 2 Diabetes

| Age at Application | Basic Rating | Minimum Rating after Credits |
|--------------------|--------------|-----------------------------|
| 0–16               | Decline      | Decline                     |
| 17–19              | +100         | +70                         |
| 20–29              | +70          | +40                         |
| 30–39              | +40          | +20                         |
| 40–49              | +20          | Standard                    |
| 50–59              | Standard     | Standard+                   |
| 60–69              | Standard     | Preferred                   |
| 70+                | Standard     | Preferred                   |

---

### 3. DIABETES SPECIFIC COMPLICATIONS

| Complication                | Rating Adjustment      |
|-----------------------------|-----------------------|
| Microalbuminuria (mild)     | +30                   |
| Macroalbuminuria            | +80                   |
| Retinopathy (background)    | +0                    |
| Retinopathy (proliferative) | +60                   |
| Neuropathy (mild)           | +0                    |
| Neuropathy (moderate)       | +40                   |
| Neuropathy (severe)         | Decline               |
| Amputation (due to diabetes)| Decline               |
| Renal impairment            | IC                    |
| Ulcer, lower extremity      | Decline               |

---

## 4. Additional Considerations

### a) Co-morbid Conditions and Risk Factors

| Co-morbid Condition         | Rating Adjustment      |
|----------------------------|-----------------------|
| Alcohol excess (current)    | Decline               |
| Build (BMI 30–34.9)         | +20                   |
| Build (BMI 35–39.9)         | +40                   |
| Build (BMI ≥40)             | +80 or Decline        |
| Coronary artery disease     | See CAD section       |
| Peripheral artery disease   | +40 (mild), Decline (moderate/severe) |
| Cerebrovascular disease     | See CVD section       |
| Depression (mild)           | +0                    |
| Depression (moderate)       | +30                   |
| Depression (severe)         | Decline               |
| Hypertension (controlled)   | +20                   |
| Hypertension (uncontrolled) | +60 or Decline        |
| Hyperlipidemia (controlled) | +10                   |
| Hyperlipidemia (uncontrolled)| +30                  |
| Smoking (≤1 pack/day)       | Smoker rates          |
| Smoking (>1 pack/day)       | +30 to +50            |

### b) Credits for Protective Factors

| Protective Factor                                  | Credit  |
|----------------------------------------------------|---------|
| BP/Lipids within range (2 years)                   | -10     |
| Negative exercise study (last 2 years)             | -20     |
| Favorable EBCT (last 2 years)                      | -10     |
| Use of 2+ preventative medications                 | -10     |
| Excellent compliance and follow-up                 | -20     |
| Non-smoker (≥10 years)                             | -10     |

### c) DIABETIC CONTROL CHART

| Control     | HbA1c   or Fasting Glucose | Credit/Debit |
|-------------|---------------------------|-------------|
| Excellent   | <7.1   or <140 mg/dl      | -40         |
| Good        | 7.1–8.0 or 140–175 mg/dl   | -20 to 0    |
| Fair        | 8.1–9.5 or 176–200 mg/dl   | 0 to +20    |
| Poor        | 9.6–11  or 201–220 mg/dl   | +40 to +80  |
| Uncontrolled| >11    or  >220 mg/dl      | Decline     |

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current
