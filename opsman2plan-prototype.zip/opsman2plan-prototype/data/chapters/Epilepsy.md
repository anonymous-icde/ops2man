# Epilepsy  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Epilepsy is a chronic neurological disorder characterized by recurrent, unprovoked seizures due to abnormal electrical activity in the brain.

**Typical Signs and Symptoms:**
- Recurrent seizures (generalized or partial)
- Loss of consciousness or awareness
- Convulsions, muscle rigidity, or jerking
- Aura (sensory, emotional, or cognitive symptoms before a seizure)
- Confusion or fatigue post-seizure

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Early age of onset
- Poor seizure control
- Frequent or prolonged seizures
- History of status epilepticus
- Structural brain abnormalities
- Poor compliance with medication
- Alcohol or substance abuse
- Co-morbid psychiatric conditions

**Protective Factors:**
- Good seizure control
- Long duration without seizures
- Compliance with medication and follow-up
- No history of status epilepticus
- No co-morbidities
- Supportive social environment

#### 1c. Classification of Severity and Control tTpes

| Severity Type                | Criteria                                                                 |
|------------------------------|--------------------------------------------------------------------------|
| Absence (petit mal)          | Brief, frequent lapses in awareness, usually in children                 |
| Generalized/Partial (known cause) | Seizures with identified etiology (e.g., trauma, tumor, infection)   |
| Generalized/Partial (unknown cause) | Seizures with no identifiable cause                              |
| Status Epilepticus           | Seizure lasting >5 minutes or repeated seizures without recovery         |



| Control Type                 | Criteria                                                                 |
|------------------------------|--------------------------------------------------------------------------|
| Control: Good                | 1 seizure / year, compliant with meds                             |
| Control: Fair                | 2 seizures / year, compliant with meds                                   |
| Control: Poor                | >2 seizures/year, poor compliance or refractory                          |

#### 1d. Diagnostic Tests

- EEG (electroencephalogram)
- Brain MRI or CT scan
- Blood tests (to rule out metabolic causes)
- Medication blood levels
- Neuropsychological assessment (if indicated)

#### 1e. Treatments

- **Antiepileptic drugs (AEDs):** levetiracetam, lamotrigine, valproic acid, carbamazepine, phenytoin, topiramate
- **Surgical intervention:** for refractory cases (e.g., temporal lobectomy)
- **Vagus nerve stimulation**
- **Lifestyle modifications:** sleep hygiene, avoiding triggers
- **Ketogenic diet:** in select pediatric cases

---

### 2. Underwriting Focus

- Type and frequency of seizures
- Age at onset and duration since first seizure
- Seizure control (good, fair, poor)
- Medication compliance
- Cause known or unknown
- History of status epilepticus
- Results of EEG and imaging
- Co-morbidities (psychiatric, substance use)
- History of accidents or injuries
- Occupational and driving status

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent physician’s report  | Seizure type, frequency, control, meds   |
| EEG and imaging reports    | Within last 2 years                      |
| Medication list            | Current and past 12 months               |
| Compliance documentation   | If available                             |
| Accident/injury history    | If applicable                            |
| Psychiatric evaluation     | If co-morbid depression or suicide risk  |

---

### 4. Rating

#### Seizure History Ratings (Synthetic Example, Revised)

| Seizure Type/Control                | LIFE   | WP    | ADB    | LTC         |
|-------------------------------------|--------|-------|--------|-------------|
| Absence attacks (petit mal)         | +10    | +10   | Decline| Standard    |
| Generalized/Partial (known cause)   |        |       |        |             |
| 0–12 mo since last seizure         | Postpone| Postpone| Decline| Decline  |
| >12 mo, good control                | +25    | +25   | Decline| +25         |
| >12 mo, fair control                | +75    | Decline| Decline| Decline     |
| >12 mo, poor control                | IC     | Decline| Decline| Decline     |
| Generalized/Partial (unknown cause) |        |       |        |             |
| No/incomplete investigation         | IC     | Decline| Decline| Decline     |
| 0–12 mo since last seizure         | Postpone| Postpone| Decline| Decline  |
| 12 mo–3 yrs, good control           | +60    | Decline| Decline| +60         |
| 12 mo–3 yrs, fair control           | +120   | Decline| Decline| Decline     |
| 12 mo–3 yrs, poor control           | IC     | Decline| Decline| Decline     |
| >3 yrs, good control                | +10    | +10   | Decline| +10         |
| >3 yrs, fair control                | +60    | Decline| Decline| Decline     |
| >3 yrs, poor control                | IC, +90| Decline| Decline| Decline     |
| Partial, no secondary generalization|        |       |        |             |
| 0–12 mo since last seizure         | Postpone| Postpone| Decline| Decline  |
| 12 mo–3 yrs, good control           | Standard| Decline| Decline| +10        |
| 12 mo–3 yrs, fair control           | +40    | Decline| Decline| Decline     |
| 12 mo–3 yrs, poor control           | +90    | Decline| Decline| Decline     |
| >3 yrs, good control                | +0     | +0    | Decline| +0          |
| >3 yrs, fair control                | Standard| Decline| Decline| Decline     |
| >3 yrs, poor control                | IC, +60| Decline| Decline| Decline     |
| Status epilepticus, 0–2 yrs         | Postpone| Postpone| Decline| Decline  |
| Status epilepticus, >2 yrs          | Add +60 to above ratings | Decline | Decline | +60 |

Notes: the times mentioned in the table below refer to the duration since last seizure.
---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Factor/Condition                    | Rating Adjustment               |
| Poor compliance with medications    | Decline                         |
| Alcohol abuse                       | Decline                         |
| Depression                          | IC, usually +50                 |
| History of suicide attempt          | IC, usually +75                 |
| Frequent accidents                  | IC, usually +50                 |
| Hazardous avocations                | IC, usually +50                 |
| Surgery for epilepsy                | IC, usually +25                 |

#### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| seizure-free >3 yrs                       | -30         |
| No accidents/injuries, stable employment  | -20         |
| Supportive social/family environment      | -20         |

---

**Legend:**
- IC = Individual Consideration
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- Standard = Standard rates

---

**Note:**
All values and tables above are synthetic and
