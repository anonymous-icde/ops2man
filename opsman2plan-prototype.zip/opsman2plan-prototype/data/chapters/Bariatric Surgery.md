# Bariatric Surgery
## Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Bariatric surgery refers to a group of surgical procedures performed to help with weight loss in individuals with severe obesity. Common types include restrictive (e.g., gastric banding), malabsorptive (e.g., jejuno-ileal bypass), and combined procedures (e.g., Roux-en-Y gastric bypass).

**Typical Signs and Symptoms (post-surgery):**
- Rapid weight loss
- Changes in appetite
- Gastrointestinal symptoms (nausea, vomiting, diarrhea)
- Nutritional deficiencies (iron, B12, calcium, etc.)
- Dumping syndrome (especially after gastric bypass)

### 1b. Risk and Protective Factors

**Risk Factors:**
- Pre-existing comorbidities (diabetes, hypertension, sleep apnea)
- Poor compliance with follow-up or supplements
- History of surgical complications
- Malnutrition or significant weight regain
- Liver dysfunction

**Protective Factors:**
- Good compliance with medical and nutritional follow-up
- Stable weight loss
- Absence of complications
- Regular monitoring and supplementation

### 1c. Classification of Severity

| Severity Level | Criteria                                                                 |
|----------------|--------------------------------------------------------------------------|
| Uncomplicated  | No significant complications, stable weight, normal labs                 |
| Mild Complications | Minor nutritional deficiencies, managed with supplements             |
| Moderate Complications | Recurrent GI symptoms, mild lab abnormalities, managed medically |
| Severe Complications | Major surgical or metabolic complications, abnormal liver function |


### 1d. Diagnostic Tests

- CBC, iron studies, vitamin B12, folate, calcium, vitamin D
- Liver function tests
- Blood glucose, HbA1c
- Lipid profile
- Imaging (if complications suspected)

### 1e. Treatments

- **Nutritional supplements:** multivitamins, iron, calcium, vitamin B12
- **Medical management:** for complications (e.g., diabetes, hypertension)
- **Surgical revision:** for severe complications or failed procedures
- **Lifestyle modification:** diet, exercise, behavioral therapy

---

## 2. Underwriting Focus

- Type of bariatric procedure performed
- Time since surgery
- Presence and severity of complications
- Weight stability and current BMI
- Compliance with follow-up and supplementation
- Presence of comorbid conditions (diabetes, hypertension, depression, etc.)

---

## 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Surgery details, complications, follow-up |
| Recent labs (CBC, iron, B12, calcium, LFTs) | Within last 12 months   |
| Weight history and current BMI | Required                              |
| Documentation of comorbidities | Diabetes, hypertension, etc.          |
| Surgical reports (if available) | Type and date of procedure           |

---

## 4. Rating

#### Bariatric Surgery Rating Table (Human Readable, Synthetic Values)

| Procedure Type                | Time Since Surgery | Complications           | Life   | WP     | ADB    | LTC    |
|-------------------------------|-------------------|------------------------|--------|--------|--------|--------|
| Malabsorptive (e.g., bypass)  | <1 year           | Any                    | Postpone | Postpone | Postpone | Postpone |
| Malabsorptive                 | 1-3 years         | None                   | +80    | Decline | Decline | Decline |
| Malabsorptive                 | 1-3 years         | Minor                  | +120   | Decline | Decline | Decline |
| Malabsorptive                 | >3 years          | None                   | +40    | +80     | +80     | +100   |
| Malabsorptive                 | >3 years          | Minor                  | +80    | +120    | +120    | +150   |
| Malabsorptive                 | Any               | Major                  | Decline| Decline | Decline | Decline |
| Restrictive (e.g., banding)   | <6 months         | Any                    | Postpone | Postpone | Postpone | Postpone |
| Restrictive                   | 6-12 months       | None                   | +60    | Decline | Decline | Decline |
| Restrictive                   | 6-12 months       | Minor                  | +90    | Decline | Decline | Decline |
| Restrictive                   | 1-3 years         | None                   | +30    | +60     | +60     | +80    |
| Restrictive                   | 1-3 years         | Minor                  | +60    | +90     | +90     | +120   |
| Restrictive                   | >3 years          | None                   | Standard | +30   | +30     | +40    |
| Restrictive                   | >3 years          | Minor                  | +30    | +60     | +60     | +80    |
| Restrictive                   | Any               | Major                  | Decline| Decline | Decline | Decline |
| Combined (e.g., Roux-en-Y)    | <6 months         | Any                    | Postpone | Postpone | Postpone | Postpone |
| Combined                      | 6-12 months       | None                   | +70    | Decline | Decline | Decline |
| Combined                      | 6-12 months       | Minor                  | +100   | Decline | Decline | Decline |
| Combined                      | 1-3 years         | None                   | +35    | +70     | +70     | +90    |
| Combined                      | 1-3 years         | Minor                  | +70    | +100    | +100    | +130   |
| Combined                      | >3 years          | None                   | Standard | +35   | +35     | +50    |
| Combined                      | >3 years          | Minor                  | +35    | +70     | +70     | +90    |
| Combined                      | Any               | Major                  | Decline| Decline | Decline | Decline |

**Legend:**  
- **Minor complications:** Mild anemia, mild nutritional deficiency, resolved wound infection  
- **Major complications:** Reoperation, persistent severe deficiency, chronic GI symptoms  
- **Standard:** Standard risk class per build table  
- **Postpone:** Application deferred until minimum time since surgery has passed  
- **Decline:** Not insurable under current guidelines  

---

## 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Co-morbid Condition         | Rating Adjustment      |
|----------------------------|-----------------------|
| Well-controlled diabetes    | Add +40               |
| Poorly controlled diabetes  | Decline               |
| Hypertension (controlled)   | Add +20               |
| Hypertension (uncontrolled)| Decline               |
| Depression (mild, stable)  | Add +20               |
| Depression (severe/unstable)| Decline              |
| Significant nutritional deficiency | Add +60        |
| Abnormal liver function     | Decline               |

#### 5b. Credits for Protective Factors

| Protective Factor                                  | Credit  |
|----------------------------------------------------|---------|
| Stable weight >2 years post-surgery                | -20     |
| No complications since surgery                     | -20     |
| Excellent compliance with supplements and follow-up| -20     |
| Active lifestyle (regular exercise)                | -10     |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
