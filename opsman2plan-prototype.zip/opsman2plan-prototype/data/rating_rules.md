# Rating Rules (in addition to Underwriting Guidelines)


1. **Range of Ratings:** If the output contains a range of ratings, select the minimum rating within that range.

2. **Credits to Rating:** If the manual specifies a credit (e.g., -10, -25), but the medical summary lacks sufficient information to justify applying the credit, do not apply the credit. Be conservative in such cases.


3. **Debits to Rating:** If the manual specifies a debit (e.g., +10, +25, Decline) or requires determining severity, and the medical summary lacks sufficient information, apply the minimum debit possible. Lean toward the favorable side for the applicant.


4. **Additional Considerations:** When applying additional considerations for impairment X, if the guideline simply states “See Y” (where Y is another impairment, e.g., “See CAD”), ignore this additional consideration for X. The co-morbidity of X and Y will be addressed when rating Y.


