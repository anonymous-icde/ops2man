# opsman2plan
A repo to analyze operational manuals like UW manual and reason on them.

## 🚀 Quick Start

### 1. Install Dependencies

```bash
uv sync --all-groups --all-extras
```


### 4. Configure Environment Variables

Set the following environment variables:

```bash
# [OPTIONAL] Required only when using azure_openai as your model provider. (in run_experiment.ipynb change model names to have prefix azure_openai:)
AZURE_OPENAI_ENDPOINT="<your_endpoint>"
AZURE_OPENAI_API_KEY="<your_api_key>"
OPENAI_API_VERSION="preview"

# [OPTIONAL] Required only when using openai or openai api compliant API eg. Ollama (in run_experiment.ipynb change model names to have prefix openai:)
OPENAI_API_BASE="" # Your Endpoint Here. 
OPENAI_API_VERSION="preview"
OPENAI_API_KEY="<your_api_key>"
```

### 5. Run Notebook

Execute the notebook at: `src/run_experiment.ipynb`

Configure models and systems in the final cell to start evaluation.


### Viewing Run Stats

We utilize mlflow to track the requests and gather statistics. You can either use local mlflow server or point to your own tracking server. 

#### Local MLFlow

To use local mlflow server nothing needs to be done. mlflow by default store the results in folder `mlruns` in the same folder as `src/run_experiment.ipynb` file. Simply run command `mlflow ui --host 0.0.0.0 --port 5000` from that folder and you will have a local mlflow server running where you can view all the traces and metrics. You can visit `http://localhost:5000` to view. 

#### Remote MLFlow
To setup a remote tracking URI for mlflow server add `MLFLOW_TRACKING_URI` and `MLFLOW_EXPERIMENT_ID`. Setup will vary depending on your remote. For more information see [this](https://mlflow.org/docs/latest/ml/tracking/tutorials/remote-server/)