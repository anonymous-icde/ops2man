import os
import csv
import random

PARENT_DIR = os.path.dirname(os.path.dirname(__file__))
DATA_DIR = os.path.join(PARENT_DIR, 'synthetic_data')
CSV_PATH = os.path.join(PARENT_DIR, 'manual_synthetic.csv')

def extract_page_id(filename):
    return filename[:2]

def extract_page_name(filename):
    # Assumes format: "NN - Page Name.md"
    parts = filename.split(' - ')
    if len(parts) > 1:
        name = parts[1].rsplit('.md', 1)[0]
        return name.strip()
    return ''

def generate_checksum():
    return str(random.randint(10**11, 10**12 - 1))

def main():
    fieldnames = [
        "site_id", "module_id", "chapter_id", "page_id", "chapter_name",
        "page_name", "component_name", "content", "keywords", "references", "checksum"
    ]
    rows = []
    for fname in os.listdir(DATA_DIR):
        if fname.endswith('.md'):
            page_id = extract_page_id(fname)
            page_name = extract_page_name(fname)
            with open(os.path.join(DATA_DIR, fname), 'r', encoding='utf-8') as f:
                content = f.read()
            rating_header = "## 4. Rating"
            IC_header = "## 5. Additional Considerations"
            if rating_header in content and IC_header in content:
                general_info, after_rating = content.split(rating_header, 1)
                rating, _ = after_rating.split(IC_header, 1)
                general_info = general_info.strip()
                rating = rating.strip()
            elif rating_header in content:
                general_info, rating = content.split(rating_header, 1)
                general_info = general_info.strip()
                rating = rating.strip()
            else:
                general_info = content.strip()
                rating = ""
            if IC_header in content:
                _, additional_considerations = content.split(IC_header, 1)
                additional_considerations = additional_considerations.strip()
            else:
                additional_considerations = ""
            row_rating = {
                "site_id": 40,
                "module_id": 164,
                "chapter_id": 1061,
                "page_id": page_id,
                "chapter_name": "chapter 1",
                "page_name": page_name,
                "component_name": "Rating",
                "content": rating,
                "keywords": [],
                "references": [],
                "checksum": generate_checksum()
            }
            rows.append(row_rating)
            row_general_info = {
                "site_id": 40,
                "module_id": 164,
                "chapter_id": 1061,
                "page_id": page_id,
                "chapter_name": "chapter 1",
                "page_name": page_name,
                "component_name": "General Information",
                "content": general_info,
                "keywords": [],
                "references": [],
                "checksum": generate_checksum()
            }
            rows.append(row_general_info)
            if IC_header in content:
                row_IC = {
                    "site_id": 40,
                    "module_id": 164,
                    "chapter_id": 1061,
                    "page_id": page_id,
                    "chapter_name": "chapter 1",
                    "page_name": page_name,
                    "component_name": "Additional Considerations",
                    "content": additional_considerations,
                    "keywords": [],
                    "references": [],
                    "checksum": generate_checksum()
                }
                rows.append(row_IC)

    with open(CSV_PATH, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            # Convert lists to string representation
            row['keywords'] = str(row['keywords'])
            row['references'] = str(row['references'])
            writer.writerow(row)

if __name__ == "__main__":
    main()