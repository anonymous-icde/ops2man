from pathlib import Path


PROMPT_DIR = Path(__file__).parent / "prompts"