from pathlib import Path
from typing import Dict, Any
from langgraph.graph import StateGraph, END, START

from workflow_agent.agents.planner_agent import PlannerAgent
from workflow_agent.agents.annotator_agent import AnnotatorAgent
from workflow_agent.agents.prerequisite_step_agent import PrerequisiteAgent
from workflow_agent.agents.step_extractor_agent import StepExtractorAgent
from workflow_agent.agents.refiner_agent import RefinerAgent
from workflow_agent.agents.sequence_agent import SequenceAgent
from workflow_agent.agents.formatter_agent import FormatterAgent
from workflow_agent.utils import setup_logger, extract_contents
from workflow_agent.state import WorkflowState, Document

class WorkflowGraph:
    """LangGraph implementation of the workflow generation process."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = setup_logger("WorkflowGraph", config.get("log_level", "INFO"))
        
        # Initialize agents
        self.annotator = AnnotatorAgent(config)
        self.extractor = StepExtractorAgent(config)         
        self.prerequisite = PrerequisiteAgent(config)

        # Build the graph
        self.graph = self._build_graph()
    
    def _should_continue_extraction(self, state: WorkflowState) -> str:
        """Determine if extraction should continue."""
        return "StepExtractorAgent" if not state.extraction_complete else "PrerequisiteAgent"
    
    def _should_continue_refinement(self, state: WorkflowState) -> str:
        """Determine if refinement should continue."""
        if not state.refinement_complete:
            return "RefinerAgent"
        #return "SequenceAgent"
        return "FormatterAgent"
    
    def _should_continue_sequencing(self, state: WorkflowState) -> str:
        """Determine if sequencing should continue."""
        if not state.sequencing_complete:
            return "SequenceAgent"
        return "FormatterAgent"
    
    def _build_graph(self) -> StateGraph:
        """Build the workflow graph."""
        self.logger.info("Building workflow graph")
        
        # Create the state graph
        builder = StateGraph(WorkflowState)
        
        # Add nodes for each agent
        # builder.add_node("PlannerAgent", self.planner.run)
        builder.add_node("AnnotatorAgent", self.annotator.run)
        builder.add_node("StepExtractorAgent", self.extractor.run)
        builder.add_node("PrerequisiteAgent", self.prerequisite.run)
        # builder.add_node("RefinerAgent", self.refiner.run)
        #builder.add_node("SequenceAgent", self.sequencer.run)
        # builder.add_node("FormatterAgent", self.formatter.run)
        
        # Add conditional edges to enable agent autonomy
        # builder.add_edge(START, "PlannerAgent")
        builder.add_edge(START, "AnnotatorAgent")
        builder.add_edge("AnnotatorAgent", "StepExtractorAgent")
        builder.add_conditional_edges(
            "StepExtractorAgent",
            self._should_continue_extraction,
        )
        builder.add_edge("PrerequisiteAgent", END)
        
        return builder.compile()
    
    def run(self, manual_section: str, documents: Dict[str, str]) -> Dict[str, Any]:
        """Run the workflow generation process."""
        self.logger.info(f"Starting workflow generation for: {manual_section}")
        
        # Prepare initial state
        '''
        initial_state = WorkflowState(
            manual_section=manual_section,
            documents={
                "rating": {"title": "Rating", "content": documents.get("rating", "")},
                "general_info": {"title": "General Information", "content": documents.get("general_info", "")}
            }
        )
        '''
        initial_state = WorkflowState(
            manual_section=manual_section,
            documents={
                "rating": Document(title="Rating", content=documents.get("rating", "")),
                "general_info": Document(title="General Information", content=documents.get("general_information", ""))
            }
        )
        
        # Execute graph
        config = {"configurable": self.config}
        final_state = self.graph.invoke(initial_state, config=config, debug=False)
        # for s in self.graph.stream(initial_state, config=config, stream_mode="values", debug=True):
        #     self.logger.info(s)
        # self.logger.info(final_state)
        self.logger.info("Workflow generation complete")
        return WorkflowState(**final_state)


if __name__ == "__main__":
    # quick test to view results on mlflow
    import os
    import mlflow
    import json

    
    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan graph generation")

    mlflow.langchain.autolog()

    config_file = Path(__file__).parent.parent.parent / "config" / "config.json"
    chapter_dir = Path(__file__).parents[4] / "data" / "chapters"

    impairment = "Blood Pressure"

    input_dict = extract_contents(impairment, (chapter_dir / f"{impairment}.md").read_text())

    with mlflow.start_run() as run:
        for trial in range(1):
            with mlflow.start_span(name=f"Trial {trial+1}"):
                agent = WorkflowGraph(config=json.loads(config_file.read_text()))
                output = agent.run(manual_section=input_dict['page_name'], documents=input_dict)
            mlflow.flush_trace_async_logging()
