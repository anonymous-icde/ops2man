from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any, Union

class Message(BaseModel):
    """A message between agents."""
    from_agent: str
    to_agent: str
    content: str
    
class Document(BaseModel):
    """A document section from the operational manual."""
    title: str
    content: str

class Segment(BaseModel):
    """An annotated segment from a document."""
    segment_id: int
    content: List[Any]
    
class WorkflowStep(BaseModel):
    """A step in a workflow process."""
    step_id: int
    description: str
    segment_ids: List[int] = []
    text_from_manual: List[Any] = []
    
class WorkflowState(BaseModel):
    """The state of the workflow generation process."""
    manual_section: str
    documents: Dict[str, Document] = Field(default_factory=dict)
    segments: List[Segment] = Field(default_factory=list)
    steps: List[WorkflowStep] = Field(default_factory=list)
    messages: List[Message] = Field(default_factory=list)
    
    # Agent-specific states
    annotator_state: Dict[str, Any] = Field(default_factory=dict)
    extractor_state: Dict[str, Any] = Field(default_factory=dict)
    
    # Control flow
    annotation_complete: bool = False
    extraction_complete: bool = False
    
    # Final output
    final_workflow: Optional[Dict[str, Any]] = None