from typing import Dict, Any, List

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, Message
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class FormatterAgent:
    """Agent that formats the final workflow output."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "FormatterAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("formatter_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Format the final workflow output."""
        self.logger.info("Formatting final workflow")
        
        if not state.steps: #or not state.ordered_steps:
            self.logger.warning("No steps or sequence available for formatting")
            return {
                "messages": [
                    Message(
                        from_agent=self.name,
                        to_agent="SequenceAgent",
                        content="Need sequenced steps before formatting"
                    )
                ]
            }
        
        # Get steps in the correct order
        ordered_steps = []
        for step_id in state.ordered_steps:
            # Find the step with this ID
            matching_steps = [s for s in state.steps if s.step_id == step_id]
            if matching_steps:
                # Get associated segments
                step = matching_steps[0]
                step_segments = [s.content for s in state.segments if s.segment_id in step.segment_ids]
                ordered_steps.append({
                    "id": step.step_id,
                    "description": step.description,
                    "details": step.details,
                    "ratings": step.ratings,
                    "segment_content": "\n".join(step_segments),
                    "references": step.references
                })
        
        input_data = {
            "manual_section": state.manual_section,
            "ordered_steps": ordered_steps,
            "has_general_info": "general_info" in state.documents and state.documents["general_info"].content
        }
        
        # Format workflow
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})
        
        self.logger.info("Workflow formatting complete")
        
        # Create the final workflow output
        final_workflow = {
            "section": state.manual_section,
            "workflow_steps": result.get("formatted_steps", []),
            "metadata": {
                "total_steps": len(state.ordered_steps),
                "has_general_info_references": result.get("has_references", False)
            }
        }
        
        return {
            "formatting_complete": True,
            "formatter_state": {
                "status": "complete",
                "iteration": state.formatter_state.get("iteration", 0) + 1
            },
            "final_workflow": final_workflow
        }