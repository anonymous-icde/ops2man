from typing import Dict, Any, List

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, Message
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class SequenceAgent:
    """Agent that determines the logical sequence of workflow steps."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "SequenceAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("sequence_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Determine the logical sequence of workflow steps."""
        self.logger.info("Determining step sequence")
        
        if not state.steps:
            self.logger.warning("No steps available to sequence")
            return {
                "messages": [
                    Message(
                        from_agent=self.name,
                        to_agent="RefinerAgent",
                        content="Need refined workflow steps before sequencing"
                    )
                ]
            }
        
        # Prepare input with any relevant messages
        relevant_messages = [msg.content for msg in state.messages if msg.to_agent == self.name]
        
        # Get segment content for context
        step_details = []
        for step in state.steps:
            step_segments = [s.content for s in state.segments if s.segment_id in step.segment_ids]
            step_details.append({
                "id": step.step_id,
                "description": step.description,
                "details": step.details,
                "ratings": step.ratings,
                "segment_content": "\n".join(step_segments)
            })
        
        input_data = {
            "manual_section": state.manual_section,
            "steps": step_details,
            "messages": relevant_messages,
            "existing_sequence": state.ordered_steps if state.ordered_steps else []
        }
        
        # Sequence steps
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})
        
        # Extract the ordered step IDs
        ordered_steps = result.get("ordered_steps", [])
        self.logger.info(f"Determined sequence for {len(ordered_steps)} steps")
        
        # Update step dependencies based on sequence
        updated_steps = []
        for step in state.steps:
            # Find position in sequence
            try:
                pos = ordered_steps.index(step.step_id)
                # Dependencies are steps that come before this one
                dependencies = ordered_steps[:pos] if pos > 0 else []
                updated_step = step.copy(update={"dependencies": dependencies})
                updated_steps.append(updated_step)
            except ValueError:
                # Step not in sequence, keep as is
                updated_steps.append(step)
        
        # Check if the sequencing is complete
        is_complete = result.get("is_complete", True)
        
        # If not, add a message requesting refinement
        messages = []
        if not is_complete:
            messages.append(
                Message(
                    from_agent=self.name,
                    to_agent=self.name,
                    content=result.get("refinement_needed", "Sequencing needs refinement")
                )
            )
        
        return {
            "steps": updated_steps,
            "ordered_steps": ordered_steps,
            "sequencing_complete": is_complete,
            "sequence_state": {
                "status": "complete" if is_complete else "needs_refinement",
                "iteration": state.sequence_state.get("iteration", 0) + 1,
                "reasoning": result.get("reasoning", "")
            },
            "messages": messages
        }