from typing import Dict, Any

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, Document
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class PlannerAgent:
    """Agent that plans the workflow extraction process."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "PlannerAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("planner_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Run the planner agent to create a workflow extraction plan."""
        self.logger.info(f"Planning workflow extraction for {state.manual_section}")
        
        # Create documents if they don't exist yet
        if "rating" not in state.documents and "general_info" not in state.documents:
            self.logger.info("No documents found in state, requesting from user input")
            # In a real system, this might be retrieved from a database or user input
            
        # Prepare input for the planning prompt
        input_data = {
            "manual_section": state.manual_section,
            "rating_doc": state.documents.get("rating", Document(title="", content="")).content,
            "general_info_doc": state.documents.get("general_info", Document(title="", content="")).content
        }
        
        # Generate the plan
        chain = self.prompt | self.llm | self.parser
        plan = chain.invoke({"input": input_data})
        
        self.logger.info(f"Generated plan with {len(plan.get('steps', []))} steps")
        
        # Store the plan in the state
        state_update = {
            "planner_state": {
                "plan": plan,
                "status": "complete"
            },
            "planning_complete": True
        }
        
        return state_update