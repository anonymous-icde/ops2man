from typing import Dict, Any, List

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, Segment, Message
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class AnnotatorAgent:
    """Agent that annotates document sections."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "AnnotatorAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("annotator_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Run the annotator agent to segment documents into meaningful parts."""
        self.logger.info("Starting document annotation")
        
        # Get the rating document
        rating_doc = state.documents.get("rating")
        
        if not rating_doc or not rating_doc.content:
            self.logger.error("Rating documents are required for annotation")
            raise ValueError("Rating documents are required for annotation")
                
        input_data = {
            "document_content": rating_doc.content,
        }
        
        # Generate annotations
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})
        
        # Process segments
        segments = []
        for seg in result.get("segments", []):
            segments.append(
                Segment(
                    segment_id=seg["id"],
                    content=seg["content"]
                )
            )
        
        self.logger.info(f"Generated {len(segments)} document segments")
        
        return {
            "segments": segments,
            "annotator_state": {
                "status": "complete",
                "iteration": state.annotator_state.get("iteration", 0) + 1
            }
        }

    def refine(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Refine the existing segmentation."""
        return self.run(state, config)