import logging
from kg_agent.utils import load_jinja_prompt, get_llm
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig
from typing import Dict, Any, List

class EdgeExtractorAgent:
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger('EdgeExtractorAgent')
        self.prompt_template = load_jinja_prompt(template_name="edge_prompt")
        self.model = get_llm(model_id=self.config['model_id'])
        self.chain = self.prompt_template | self.model | JsonOutputParser()

    def run(self, state, config: RunnableConfig) -> Dict[str, Any]:
        input_data = {
            "IMPAIRMENT_NAME": state.current_page.impairment,
            "ADDITIONAL_CONSIDERATIONS": state.current_page.content,
            "input": "" # Placeholder for any additional input
        }
        
        
        result = self.chain.invoke({
            "input": input_data
        })
        self.logger.info(f"Extracted edges for {state.current_page.impairment}")

        
        return {
            "node_info": result
        }
    
