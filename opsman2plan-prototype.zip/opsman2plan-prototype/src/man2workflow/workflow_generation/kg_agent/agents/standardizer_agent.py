import logging
from kg_agent.utils import load_jinja_prompt, get_llm
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables.config import RunnableConfig
from typing import Dict, Any, List

class StandardizerAgent:
    def __init__(self, config, standard_impairment_names):
        self.config = config
        self.standard_impairment_names = standard_impairment_names
        self.logger = logging.getLogger('StandardizerAgent')
        prompt_template = load_jinja_prompt(template_name="standard_name_prompt")
        model = get_llm(model_id=self.config['model_id'])
        self.chain = prompt_template | model | StrOutputParser()

    def standardize(self, name, primary_impairment) -> str: 
        names_list = "\n".join(f"-{n}" for n in self.standard_impairment_names if n != primary_impairment)
        
        input_data = {
            "MEDICAL_CONDITION": name,
            "STANDARDIZED_NAMES": names_list
        }

        result = self.chain.invoke({"input": input_data})

        if result == primary_impairment:
            return name
        self.logger.info(f"Standardized {name} -> {result}")

        return result
    
    def run(self, state, config: RunnableConfig)-> Dict[str, Any]:
        standardized = {}
        primary_impairment = state.current_page.impairment
        for consideration in state.node_info:
            standardized_name = self.standardize(consideration, primary_impairment)
            standardized[consideration] = standardized_name
        #state.standardized_considerations = standardized
        return {
            "standardized_considerations": standardized
        }