from pydantic import BaseModel, Field, ConfigDict
from typing import Dict, List, Optional, Any, Union
import networkx as nx

class PageContent(BaseModel):
    impairment: str
    content: str

class KGState(BaseModel):
    current_page: PageContent
    standard_impairment_names: List[str]
    node_info: Optional[Dict[str, Any]] = None
    standardized_considerations: Optional[Dict[str, str]] = None
    relevant_data: List[PageContent] = None
    knowledge_graph: Any
        

class Message(BaseModel):
    """A message between agents."""
    from_agent: str
    to_agent: str
    content: str
    
class Document(BaseModel):
    """A document section from the operational manual."""
    title: str
    content: str