from langgraph.graph import StateGraph, START, END
from kg_agent.agents.edge_extractor_agent import EdgeExtractorAgent
from kg_agent.agents.standardizer_agent import StandardizerAgent
from kg_agent.agents.kg_builder_agent import KGBuilderAgent
from kg_agent.state import KGState
import json
import networkx as nx
import logging

class KGGraph:
    def __init__(self, config, relevant_data, standard_impairment_names,
                 current_knowledge_graph):
        self.config = config
        self.relevant_data = relevant_data
        self.standard_impairment_names = standard_impairment_names
        
        self.edge_extractor = EdgeExtractorAgent(config)
        self.standardizer = StandardizerAgent(config, standard_impairment_names)
        self.kg_builder = KGBuilderAgent(current_knowledge_graph)
        self.logger = logging.getLogger('LangGraph')
        self.graph = self._build_graph()

    def _build_graph(self):
        graph = StateGraph(KGState)
        graph.add_node("edge_extractor", self.edge_extractor.run)
        graph.add_node("standardizer", self.standardizer.run)
        graph.add_node("kg_builder", self.kg_builder.run)
        graph.add_edge(START, "edge_extractor")
        graph.add_edge("edge_extractor", "standardizer")
        graph.add_edge("standardizer", "kg_builder")
        graph.add_edge("kg_builder", END)

        return graph.compile()

    def run(self, page, current_knowledge_graph):
        self.logger.info(f"Starting KG generation for: {page.impairment}")
        
        primary_impairment = page.impairment
        self.logger.info(f"Processing impairment: {page.impairment}")

        initial_state = KGState(
            current_page=page,
            relevant_data=self.relevant_data,
            standard_impairment_names=self.standard_impairment_names,
            knowledge_graph=current_knowledge_graph
        )
        final_state = self.graph.invoke(initial_state, debug=True)

        return KGState(**final_state)