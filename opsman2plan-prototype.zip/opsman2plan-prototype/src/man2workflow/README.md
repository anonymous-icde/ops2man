workflow_generation/
│
├── __init__.py
├── main.py                      # Entry point
├── utils.py                     # Utilities
│
├── agents/                      # Autonomous agents
│   ├── __init__.py
│   ├── planner_agent.py         # Plans the workflow extraction
│   ├── annotator_agent.py       # Annotates document sections
│   ├── step_extractor_agent.py  # Identifies workflow steps
│   ├── refiner_agent.py         # Refines and improves steps
│   ├── sequence_agent.py        # Orders the steps logically
│   └── formatter_agent.py       # Formats the final workflow
│
├── workflow/
│   ├── __init__.py
│   ├── state.py                 # State management
│   └── graph.py                 # LangGraph implementation
│
└── prompts/                     # Jinja prompt templates
    ├── planner_prompt.jinja2
    ├── annotator_prompt.jinja2
    ├── step_extractor_prompt.jinja2
    ├── refiner_prompt.jinja2
    ├── sequence_prompt.jinja2
    └── formatter_prompt.jinja2


Environment Variables
AZURE_OPENAI_API_KEY 
AZURE_OPENAI_ENDPOINT