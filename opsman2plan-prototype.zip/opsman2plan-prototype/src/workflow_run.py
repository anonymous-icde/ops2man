# Import required libararies
import ast
import os
import sys
from pathlib import Path

import mlflow
import pandas as pd

# Determine the base path
try:
    base_path = Path(__file__).parent.parent / "src"  # When __file__ is available
except NameError:
    base_path = (
        Path(os.getcwd()).parent / "src"
    )  # Fallback for environments like Databricks


# Add the base path to sys.path
sys.path.append(os.path.abspath(base_path))


# Load the evaluation dataset
def parse_workup(workup_str: str) -> dict:
    """Parse JSON strings into actual dictionaries."""
    return ast.literal_eval(workup_str)


def to_evaluation_format(row: pd.Series) -> dict:
    """Convert the DataFrame into the required evaluation format."""
    return {
        "inputs": {"scenario": row["Rephrased"]},
        "expectations": {
            "rating": row["Synthetic_life_rating"],
            "workup": parse_workup(row["Synthetic_life_rating_workup"]),
        },
        "tags": {"id": row["DeID"]},
    }


data = pd.read_csv("../data/rating_data.csv")
data = data[(data["Selected"] == "y") | (data["Selected"] == "Y")]
data = data.iloc[::-1].reset_index(
    drop=True
)  # Reverse the DataFrame to start from the last row
# data = data.head(10)  # For testing, limit to first 10 rows

# Define systems to compare
from typing import Any, Protocol


class PredictionSystem(Protocol):
    def predict(self, scenario: str) -> Any: ...


from pydantic import BaseModel, Field

from workflow2reasoning.core.agents.underwriting import UnderwritingAgent


class ConditionRating(BaseModel):
    name: str
    condition_rating: str


class WorkflowUWResponse(BaseModel):
    rating: str | None = None
    conditions: list[ConditionRating] = Field(default_factory=list)
    error: str | None = None


class WorkflowSystem(PredictionSystem):
    def __init__(self, model_name: str = "gpt-4o"):
        self.agent = UnderwritingAgent().compile()
        self.model_name = model_name

    @mlflow.trace
    def predict(self, scenario: str) -> WorkflowUWResponse:
        mlflow.update_current_trace(tags={"id": id})
        try:
            response = self.agent.invoke(
                {"medical_summary": scenario},
                config={
                    "max_concurrency": 4,
                    "recursion_limit": 300,
                    "configurable": {
                        "model_name": self.model_name,
                        "ablation_type": ablation_type,
                    },
                },
            )
            response = WorkflowUWResponse(
                rating=response["overall_rating"]["life_rating"],
                conditions=[
                    ConditionRating(
                        name=impairment,
                        condition_rating=trace["rating"]["co-morbidity"],
                    )
                    for impairment, trace in response["trace"].items()
                ],
            )
        except Exception as e:
            response = WorkflowUWResponse(error=str(e))
        return response


from langchain.chat_models import init_chat_model
from langchain_core.rate_limiters import InMemoryRateLimiter

from uw_baseline.agent import UnderwritingResponse, get_underwriter


class ReActResponse(UnderwritingResponse):
    rating: str | None = None
    error: str | None = None


class ReActSystem(PredictionSystem):
    def __init__(self, model_name: str):
        rate_limiter = None
        if rate_settings := self.get_rate_limit_settings(model_name):
            rate_limiter = InMemoryRateLimiter(
                requests_per_second=rate_settings["requests_per_second"],
                check_every_n_seconds=0.1,
                max_bucket_size=rate_settings["max_bucket_size"],
            )
        self.model = init_chat_model(model_name, rate_limiter=rate_limiter)
        self.agent = get_underwriter(model=self.model)

    @mlflow.trace
    def predict(self, scenario: str, max_retry: int = 5) -> UnderwritingResponse | dict:
        try:
            response = self.agent.invoke(
                {"messages": [("user", scenario)]},
                {"config": {"recursion_limit": 50, "retry_limit": 10}},
            )
        except Exception as e:
            return ReActResponse(rating="", conditions=[], error=str(e))

        if "structured_response" not in response:
            if max_retry > 0:
                return self.predict(scenario, max_retry=max_retry - 1)
            else:
                return ReActResponse(
                    rating="",
                    conditions=[],
                    error="No structured response received from the model.",
                )
        return response["structured_response"]

    def get_rate_limit_settings(self, model_name: str) -> dict:
        settings = {
            "azure_openai:gpt-4o": {"requests_per_second": 40, "max_bucket_size": 42},
            "azure_openai:gpt-4o-mini": {
                "requests_per_second": 18,
                "max_bucket_size": 19,
            },
            "azure_openai:gpt-4.1": {"requests_per_second": 2, "max_bucket_size": 2},
            "azure_openai:gpt-4.1-mini": {
                "requests_per_second": 46,
                "max_bucket_size": 48,
            },
            "azure_openai:gpt-4.1-nano": {
                "requests_per_second": 41,
                "max_bucket_size": 44,
            },
            "azure_openai:gpt-5": {"requests_per_second": 80, "max_bucket_size": 84},
            "azure_openai:gpt-5-mini": {"requests_per_second": 3, "max_bucket_size": 4},
            "azure_openai:o1-mini": {"requests_per_second": 3, "max_bucket_size": 4},
        }
        return settings.get(
            model_name.replace("azure_openai:", ""), None
        )  # Default to empty dict if model not found


# Define Experiment
import argparse

import mlflow
import pandas as pd

from evals.scorers import condition_details_match, rating_is_exact_match


def run_evaluations(
    data: pd.DataFrame,
    change_id: str,
    change_description: str,
    trial: int,
    models: list,
    systems: dict[str, PredictionSystem],
):
    for model_name in models:
        for system_name, system_cls in systems.items():
            # System to evaluate
            system = system_cls(model_name=model_name)
            # Run Name
            provider, model = model_name.split(":")
            run_name = f"{system_name}-{model}-{change_id}-trial-{trial}"
            with mlflow.start_run(
                run_name=run_name,
                description=f"Evaluating {system_name} with {model} for the following changes: {change_description}",
                nested=True,
            ) as run:
                mlflow.log_table(data, "ground_truth.json")
                mlflow.log_params(
                    {
                        "change_id": change_id,
                        "change_description": change_description,
                        "system": system_name,
                        "model": model,
                        "provider": provider,
                        "num_samples": len(data),
                        "trial": trial,
                    }
                )
                results = mlflow.genai.evaluate(
                    data=data.apply(to_evaluation_format, axis=1).to_list(),
                    predict_fn=system.predict,
                    scorers=[rating_is_exact_match, condition_details_match],
                )
                print(f"Completed run: {run.info.run_id} - {run_name}")
                print(f"Results: {results.metrics}")
    print("All evaluations completed.")


mlflow.set_experiment(experiment_id="2187665894323267")

# Run the experiments
change_id = "v28"  # could be a git sha or other unique identifier
change_description = "More data enhancements."  # What did you change

parser = argparse.ArgumentParser(description="Run workflow evaluation experiments.")
parser.add_argument(
    "--trial",
    type=int,
    default=1,
    help="Trial number for each model/system combination",
)
parser.add_argument(
    "--ablation_type",
    type=str,
    default=None,
    help="Type of ablation to perform (e.g., 'ablation_1')",
)
args = parser.parse_args()
trial = args.trial
ablation_type = args.ablation_type

if ablation_type:
    change_id += f"_{ablation_type}"
    change_description += (
        f" {ablation_type}: Disable workflow usage in workflow system."
    )

n = data.shape[0]  # data.shape[0] for all data
systems = {
    "reAct": ReActSystem,
    "workflow": WorkflowSystem,
}

if ablation_type:
    systems = {
        "workflow": WorkflowSystem,  # Only run workflow system for ablation studies
    }

models = [
    # "openai:deepseek/deepseek-v3.1-terminus",
    ## Azure OpenAI Models
    # "azure_openai:gpt-4o",
    # "azure_openai:gpt-4o-mini",
    # "azure_openai:gpt-4.1",
    # "azure_openai:gpt-4.1-mini",
    # "azure_openai:gpt-4.1-nano",
    # "openai:gpt-5",
    # "openai:mistralai/mistral-medium-3.1",
    # "openai:grok-4-fast-reasoning",
    # "openai:Llama-4-Maverick-17B-128E-Instruct-FP8",
    # "openai:qwen/qwen3-vl-30b-a3b-thinking",
    # "azure_openai:gpt-5-mini",
    ## Open Source Models hosted on Databricks (REQUIRES OPENAI_ENDPOINT AND OPENAI_API_KEY to be set in env)
    # "openai:databricks-claude-3-7-sonnet",
    # "openai:databricks-claude-sonnet-4",
    # "openai:databricks-llama-4-maverick",  # Does not support jsonSchema additionalProperties... Use extra='forbid' in pydantic model to disable additionalProperties.
    # "openai:databricks-meta-llama-3-1-8b-instruct",  # Does not support jsonSchema additionalProperties... Use extra='forbid' in pydantic model to disable additionalProperties., Takes too long to think, need to increase recursion limit...
    # "openai:databricks-meta-llama-3-3-70b-instruct",  # Does not support jsonSchema additionalProperties... Use extra='forbid' in pydantic model to disable additionalProperties.
    ### Below are incompatible models and their specific issues:
    # "openai:databricks-meta-llama-3-1-405b-instruct",  # unsupported additionalProperties on json schema for tool calling i.e JsonSchema v1 only!, no token limit available.
    # "openai:databricks-gpt-oss-120b",  # No tool use and response format use together.
    # "openai:databricks-gpt-oss-20b",  # No tool use and response format use together.
    # "openai:databricks-gemma-3-12b",  # unsupported additionalProperties on json schema for tool calling i.e JsonSchema v1 only. No multi-turn tool calls...
    # "azure_openai:o1-mini" # No tool use.
]

if ablation_type:
    models = [
        "azure_openai:gpt-5"  # Only run gpt-5 for ablation studies.
    ]

run_evaluations(data, change_id, change_description, trial, models, systems)
