from enum import StrEnum
from typing import Optional

from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import PydanticOutputParser
from openai import BaseModel
from pydantic import ConfigDict, Field

from .docs import KnowledgeSource, SyntheticSource
from .runtime import current_date
from .settings import Settings

settings = Settings()


class ControlLevel(StrEnum):
    GOOD = "GOOD"
    FAIR = "FAIR"
    POOR = "POOR"


class Condition(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(
        ...,
        description="Name of the medical or non medical condition",
        alias="condition_name",
    )
    control_status: Optional[ControlLevel] = Field(
        ...,
        description="Control status of the condition.",
    )
    condition_rating: str = Field(
        ..., description="The rating associated with the condition."
    )
    notes: str = Field(
        None,
        description="Additional notes about the condition and rating.",
    )
    step_by_step_reasoning: list[str] = Field(
        default_factory=list,
        description="Please show your work on how you arrived at the rating. Show debits and credits if applicable.",
    )


class UnderwritingResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")
    rating: str = Field(
        ...,
        description="The overall underwriting rating for the case. You should give me the absolute value for the number or the text ratings specified. No additonal comments.",
        examples=[
            "Standard",
            "Postpone",
            "Decline",
            "0",
            "50",
            "100",
            "200",
            "250",
        ],
    )
    conditions: list[Condition] = Field(
        ...,
        description="List of medical and non-medical conditions with their details.",
    )
    notes: Optional[str] = Field(
        None,
        description="Additional notes or comments about the underwriting decision.",
    )


def get_underwriter(
    model: BaseChatModel,
    source: KnowledgeSource = SyntheticSource(),
):
    parser = PydanticOutputParser(pydantic_object=UnderwritingResponse)

    SYSTEM_PROMPT = (
        (settings.prompts_dir / "SYSTEM.md").read_text()
        + "\n\n"
        + parser.get_format_instructions()
    )
    agent = create_agent(
        model=model,
        tools=[source.list_available_chapters, source.get_chapter, current_date],
        system_prompt=SYSTEM_PROMPT,
        response_format=UnderwritingResponse,
    )
    return agent
