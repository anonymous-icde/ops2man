import typer
from langchain.chat_models import init_chat_model

from .agent import get_underwriter


def print_stream(stream, output_messages_key="llm_input_messages"):
    for chunk in stream:
        for node, update in chunk.items():
            print(f"{node}")
            # output_messages_key for message updates from hooks, otherwise just 'messages'
            messages_key = (
                output_messages_key if node == "pre_model_hook" else "messages"
            )
            for message in update.get(messages_key, []):
                # Tuple fallback for very minimal cases
                if isinstance(message, tuple):
                    print(message)
                else:
                    # Clean print for LangChain messages
                    message.pretty_print()
            print("\n")


def main(scenario: str, model_name: str = "azure_openai:gpt-5"):
    model = init_chat_model(model_name)
    underwriter = get_underwriter(model=model)
    stream = underwriter.stream(
        {"messages": [{"role": "user", "content": scenario}]}, stream_mode="updates"
    )
    print_stream(stream)


if __name__ == "__main__":
    typer.run(main)
