# Import required libararies
import mlflow
import pandas as pd

import os
import sys
from pathlib import Path
import ast
from langchain_core.runnables import RunnableParallel


# Determine the base path
try:
    base_path = Path(__file__).parent.parent.parent / "src"  # When __file__ is available
except NameError:
    base_path = Path(os.getcwd()).parent.parent / "src"  # Fallback for environments like Databricks



# Add the base path to sys.path
sys.path.append(os.path.abspath(base_path))


# Load the evaluation dataset
def parse_workup(workup_str: str) -> dict:
    """Parse JSON strings into actual dictionaries."""
    return ast.literal_eval(workup_str)


def to_evaluation_format(row: pd.Series) -> dict:
    """Convert the DataFrame into the required evaluation format."""
    return {
        "inputs": {"scenario": row["Rephrased"]},
        "expectations": {
            "rating": row["Synthetic_life_rating"],
            "workup": parse_workup(row["Synthetic_life_rating_workup"]),
        },
        "tags": {"id": row["DeID"]},
    }


data = pd.read_csv("../../data/rating_data.csv")


# Define systems to compare
from typing import Any, Protocol


class PredictionSystem(Protocol):
    def predict(self, scenario: str) -> Any: ...

from pydantic import BaseModel, Field
from workflow2reasoning.core.agents.underwriting import UnderwritingAgent



class ConditionRating(BaseModel):
    name: str
    condition_rating: str
    pgraph_rating: str


class WorkflowUWResponse(BaseModel):
    rating: str | None = None
    conditions: list[ConditionRating] = Field(default_factory=list)
    error: str | None = None


class WorkflowSystem(PredictionSystem):
    def __init__(self, model_name: str = "gpt-4o"):
        self.chain = UnderwritingAgent().compile()
        self.n = 2  # Number of parallel trials
        self.model_name = model_name

    @mlflow.trace
    def predict(self, scenario: str) -> dict[str, WorkflowUWResponse]:
        try:
            # response_dict = {}
            # for i in range(self.n):
            #     response = self.chain.invoke(
            #         {"medical_summary": scenario},
            #         config={
            #             "max_concurrency": 4,
            #             "recursion_limit": 300,
            #             "model_name": self.model_name,
            #         },
            #     )
                
            #     response = WorkflowUWResponse(
            #         rating=response["overall_rating"]["life_rating"],
            #         conditions=[
            #             ConditionRating(
            #                 name=impairment,
            #                 condition_rating=trace["rating"]["co-morbidity"],
            #                 pgraph_rating=trace["rating"]["life_rating"],
            #             )
            #             for impairment, trace in response["trace"].items()
            #         ],
            #     )
            #     response_dict[f"trial-{i}"] = response

            rp_dict = {
                f"trial-{i}": self.chain for i in range(2)
            }

            rp_chain = RunnableParallel(**rp_dict)

            output = rp_chain.invoke(
                {"medical_summary": scenario},
                config={
                    "max_concurrency": 4,
                    "recursion_limit": 300,
                    "configurable": {"model_name": self.model_name},
                },
            )
            response_dict = {}
            for trial, response in output.items():
                response = WorkflowUWResponse(
                    rating=response["overall_rating"]["life_rating"],
                    conditions=[
                        ConditionRating(
                            name=impairment,
                            condition_rating=trace["rating"]["co-morbidity"],
                            pgraph_rating=trace["rating"]["life_rating"],
                        )
                        for impairment, trace in response["trace"].items()
                    ],
                )
                response_dict[trial] = response
        except Exception as e:
            response_dict = {
                f"trial-{i}": WorkflowUWResponse(error=str(e)) for i in range(self.n)
            }
        return response_dict



# Define Experiment
import mlflow
import pandas as pd
from evals.scorers import inconsistency_scorer


def run_evaluations(
    data: pd.DataFrame,
    change_id: str,
    change_description: str,
    models: list,
    systems: dict[str, PredictionSystem],
):
    for model_name in models:
        for system_name, system_cls in systems.items():
            # System to evaluate
            system = system_cls(model_name=model_name)
            # Run Name
            provider, model = model_name.split(":")
            run_name = f"{system_name}-{model}-{change_id}"
            with mlflow.start_run(
                run_name=run_name,
                description=f"Evaluating {system_name} with {model} for the following changes: {change_description}",
                nested=True,
            ) as run:
                mlflow.log_table(data, "ground_truth.json")
                mlflow.log_params(
                    {
                        "change_id": change_id,
                        "change_description": change_description,
                        "system": system_name,
                        "model": model,
                        "provider": provider,
                        "num_samples": len(data),
                    }
                )
                mlflow.genai.evaluate(
                    data=data.apply(to_evaluation_format, axis=1).to_list(),
                    predict_fn=system.predict,
                    scorers=[inconsistency_scorer],
                )
                print(f"Completed run: {run.info.run_id} - {run_name}")
    print("All evaluations completed.")



if __name__ == "__main__":
    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan consistency_exp")

    # Run the experiments
    change_id = "v6-fda8032"  # could be a git sha or other unique identifier
    change_description = "Added more examples of not rating in co-morbidity. Commit - fda8032"  # What did you change
    n = data.shape[0]  # data.shape[0] for all data
    systems = {
        # "reAct": ReActSystem,
        "workflow": WorkflowSystem,
    }

    models = [
        "azure_openai:gpt-4o",
        # "azure_openai:gpt-5",
        # "openai:databricks-claude-3-7-sonnet"
    ]

    run_evaluations(
        data=data.tail(25),
        change_id=change_id,
        change_description=change_description,
        models=models,
        systems=systems,
    )