import re
from functools import lru_cache
from logging import log
from pathlib import Path
from typing import Optional

from langchain.chat_models import init_chat_model
from langchain_core.exceptions import OutputParserException
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from mlflow.entities import AssessmentError, Feedback
from openai import InternalServerError, RateLimitError
from pydantic import BaseModel


class RatingEquivalent(BaseModel):
    percent: str | None = None
    text: str | None = None
    table: str | None = None
    absolute: str | None = None


class RatingResponse(BaseModel):
    rating: str
    scale: str
    additional_comments: str | None = None
    equivalent: Optional[RatingEquivalent] = None


def get_normalizing_chain():
    model = init_chat_model("openai:gpt-4o")
    parser = PydanticOutputParser(pydantic_object=RatingResponse)
    prompt = ChatPromptTemplate(
        [
            (
                "system",
                Path(__file__)
                .parent.parent.parent.joinpath("prompts", "RATING_GUIDE.md")
                .read_text()
                + "\n"
                + parser.get_format_instructions(),
            ),
            ("user", "{{rating}}"),
        ],
        template_format="jinja2",
    )
    chain = prompt | model | parser
    chain = chain.with_retry(
        retry_if_exception_type=(
            OutputParserException,
            RateLimitError,
            InternalServerError,
        ),
        stop_after_attempt=6,
        wait_exponential_jitter=True,
    )
    return chain


@lru_cache
def _normalize(rating: str) -> RatingResponse:
    return get_normalizing_chain().invoke({"rating": rating})


def compare(a: str, b: str) -> bool:
    """
    Compares the rating a and b to see if they are a match (Uses LLM as Judge)
    """
    norm_a = _normalize(a)
    norm_b = _normalize(b)

    if norm_a.scale == norm_b.scale and norm_a.rating == norm_b.rating:
        # Scale of the original rating and the value itself matches
        return True

    if norm_a.equivalent is None and norm_b.equivalent is None:
        # No equivalents to compare
        return False

    # Check for cross-equivalent matches when only one side has equivalents
    if norm_a.equivalent is None and norm_b.equivalent is not None:
        # Check if norm_b's equivalent contains a value that matches norm_a's scale and rating
        equiv_dict = norm_b.equivalent.model_dump()
        return (
            norm_a.scale in equiv_dict
            and str(equiv_dict[norm_a.scale]).lower() == str(norm_a.rating).lower()
        )

    if norm_b.equivalent is None and norm_a.equivalent is not None:
        # Check if norm_a's equivalent contains a value that matches norm_b's scale and rating
        equiv_dict = norm_a.equivalent.model_dump()
        return (
            norm_b.scale in equiv_dict
            and str(equiv_dict[norm_b.scale]).lower() == str(norm_b.rating).lower()
        )

    # Both have equivalents, check if any match
    # check to see if any of the equivalents match
    any_pass = any(
        [
            # Check text equivalents
            norm_a.equivalent.text is not None
            and norm_b.equivalent.text is not None
            and norm_a.equivalent.text.lower() == norm_b.equivalent.text.lower(),
            # Check table equivalents
            norm_a.equivalent.table is not None
            and norm_b.equivalent.table is not None
            and norm_a.equivalent.table.lower() == norm_b.equivalent.table.lower(),
            # Check absolute equivalents
            norm_a.equivalent.absolute is not None
            and norm_b.equivalent.absolute is not None
            and norm_a.equivalent.absolute.lower()
            == norm_b.equivalent.absolute.lower(),
            # Check percent equivalents
            norm_a.equivalent.percent is not None
            and norm_b.equivalent.percent is not None
            and norm_a.equivalent.percent.lower() == norm_b.equivalent.percent.lower(),
        ]
    )
    return any_pass

    return False


def is_numeric(s: str) -> bool:
    """
    Checks if the rating is a numeric rating (e.g., "+0", "0", etc.)
    """
    pattern = r"^[+-]?\d+$"
    return bool(re.match(pattern, s.strip())) if s else False


def convert_to_number(s: str) -> str:
    """
    Converts a categorical rating string to a numeric string.
    """
    s = s.strip().lower()
    mappings = {"standard": "0"}
    try:
        return mappings[s]
    except KeyError:
        log.warning(
            f"Could not convert rating {s} to number, returning original string"
        )
        return s


def simple_compare(actual: str, expected: str) -> Feedback:
    """
    Compares the rating a and b to see if they are an exact match (Assumes data is already standard)
    """
    # ensure both are stripped and lowercased
    if actual is None or expected is None:
        return Feedback(
            name="rating_is_exact_match",
            error=AssessmentError(
                f"One or both ratings are None: {actual=},{expected=}"
            ),
            value=False,
        )

    actual_clean = actual.strip().lower()
    expected_clean = expected.strip().lower()

    # check if a_clean and b_clean are exactly the same
    if actual_clean == expected_clean:
        return Feedback(
            name="rating_is_exact_match",
            value=True,
            rationale=f"{actual_clean} matches {expected_clean}",
        )

    # check if both ratings are standard ratings (regardless of representation like "0", "+0", "-0", "standard")
    standard_ratings = ["standard", "0", "+0", "-0"]
    if (actual_clean in standard_ratings) and (expected_clean in standard_ratings):
        return Feedback(
            name="rating_is_exact_match",
            value=True,
            rationale=f"{actual_clean} matches {expected_clean}",
        )

    # Strip the leading '+' or '-' for comparison if both are numeric
    if is_numeric(actual_clean) and is_numeric(expected_clean):
        actual_num = actual_clean.lstrip("+-")
        expected_num = expected_clean.lstrip("+-")
        if actual_num == expected_num:
            return Feedback(
                name="rating_is_exact_match",
                value=True,
                rationale=f"{actual_clean} matches {expected_clean}",
            )

    return Feedback(
        name="rating_is_exact_match",
        value=False,
        rationale=f"Actual '{actual_clean}' but expected '{expected_clean}'",
    )

def number_of_inconsistencies(response1, response2) -> tuple[int, int, int]:
    conditions1 = {cond.name: {"rating": cond.condition_rating, "process_graph": cond.pgraph_rating} for cond in response1.conditions}
    conditions2 = {cond.name: {"rating": cond.condition_rating, "process_graph": cond.pgraph_rating} for cond in response2.conditions}

    all_conditions = set(conditions1.keys()).union(set(conditions2.keys()))

    rating_inconsistencies = 0
    condition_inconsistencies = 0
    process_graph_rating_inconsistencies = 0

    for condition in all_conditions:
        rating1 = conditions1.get(condition)
        rating2 = conditions2.get(condition)

        if rating1 is None or rating2 is None:
            condition_inconsistencies += 1  # Condition missing in one of the responses
        else:
            if not simple_compare(rating1["rating"], rating2["rating"]).value:
                rating_inconsistencies += 1  # Ratings do not match
            if not simple_compare(rating1["process_graph"], rating2["process_graph"]).value:
                process_graph_rating_inconsistencies += 1  # Process graph ratings do not match

    return rating_inconsistencies, condition_inconsistencies, process_graph_rating_inconsistencies


def get_average_inconsistencies(outputs):
    """
    Computes the average number of inconsistencies in condition ratings and the number of missing conditions between all pairs of responses.
    """
    total_rating_inconsistencies = 0
    total_process_graph_rating_inconsistencies = 0
    total_condition_inconsistencies = 0
    count = 0 # Number of pairs compared

    response_list = list(outputs.values())
    n = len(response_list)

    for i in range(n):
        for j in range(i + 1, n):
            rating_inconsistencies, condition_inconsistencies, process_graph_rating_inconsistencies = number_of_inconsistencies(response_list[i], response_list[j])
            total_rating_inconsistencies += rating_inconsistencies
            total_condition_inconsistencies += condition_inconsistencies
            total_process_graph_rating_inconsistencies += process_graph_rating_inconsistencies
            count += 1

    avg_rating_inconsistencies = total_rating_inconsistencies / count if count > 0 else 0
    avg_condition_inconsistencies = total_condition_inconsistencies / count if count > 0 else 0
    avg_process_graph_rating_inconsistencies = total_process_graph_rating_inconsistencies / count if count > 0 else 0

    return avg_rating_inconsistencies, avg_condition_inconsistencies, avg_process_graph_rating_inconsistencies