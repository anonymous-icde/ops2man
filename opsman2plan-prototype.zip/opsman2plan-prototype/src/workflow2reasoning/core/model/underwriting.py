from pydantic import BaseModel


class StepResult(BaseModel):
    step_id: int
    step_description: str
    step_execution: str
    step_outcome: str

class Rating(BaseModel):
    life_rating: str # Life ???
    wp: str # Accronym ??
    adb: str # Accidental Death Benefit
    ltc: str # Long Term Car

class ImpairmentTrace(BaseModel):
    rating: Rating
    steps: list[StepResult]
    comorbidity_steps: list[StepResult] = []
