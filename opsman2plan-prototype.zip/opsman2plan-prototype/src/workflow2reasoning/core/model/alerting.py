from enum import StrEnum, auto
from typing import ClassVar, Optional

from pydantic import BaseModel, model_validator


class AlertTypes(StrEnum):
    RATING_CONSIDERATION = auto()
    RANGE = auto()
    ADDITIONAL_CHARGES = auto()
    ABOVE_STANDARD = auto()
    POSSIBLE_RISK = auto()
    CONFIDENCE = auto()


class Alert(BaseModel):
    type: AlertTypes  # Enum for the type of alert
    source: str
    title: str
    description: Optional[str] = None

    # Define allowed titles for each type of alert
    # This is for situation we want to constrain the allowed_title for contract.
    # E.g., if action path looks at both type and title to decide the action using say if conditions
    # then we both action path and developer will know what are the allowed titles for a given type of alert
    allowed_titles: ClassVar[dict] = {
        AlertTypes.ABOVE_STANDARD: [
            "preferred",
            "standard plus",
            "super preferred",
            "preferred possible",
            "standard plus possible",
            "super preferred possible",
        ],
        AlertTypes.RATING_CONSIDERATION: ["IC", "RMD", "ASSUMPTIONS"],
    }

    # validate the title based on the type of alert
    @model_validator(mode="before")
    def validate_title(cls, values):
        alert_type = values.get("type")
        title = values.get("title")
        if alert_type in cls.allowed_titles:
            if not title:  # Ensure title is present
                raise ValueError(f"Title is required for alert type '{alert_type}'")
            if not any(
                str(title).startswith(prefix)
                for prefix in cls.allowed_titles[alert_type]
            ):
                raise ValueError(
                    f"Invalid title '{title}' for alert type '{alert_type}'"
                )
        return values

    def __str__(self):
        return f"{self.title} ({self.type.value}) - {self.source} - {self.description}"

    def __eq__(self, value):
        # Compare the type and title of the alert as those are the key information
        return (
            self.type == value.type
            and self.title == value.title
            and self.source == value.source
            and self.description == value.description
        )

    def __hash__(self):
        return hash(str(self))
