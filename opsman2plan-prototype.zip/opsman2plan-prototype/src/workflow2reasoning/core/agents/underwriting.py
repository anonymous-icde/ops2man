from typing import Literal

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Command
import os
import sys
from pathlib import Path

try:
    base_path = Path(__file__).parents[4] / "src"  # When __file__ is available
except NameError:
    base_path = Path(os.getcwd()).parents[3] / "src"  # Fallback for environments like Databricks

# Add the base path to sys.path
sys.path.append(os.path.abspath(base_path))

from workflow2reasoning.core.agents import (
    BaseAgent,
    ComorbidityAgent,
    ComorbidityAgentNoKnowledgeGraph,
    ProcessGraphOrchestratorAgent,
    RiskFactorAgent,
    aggregated_rating_agent,
    aggregated_rating_agent_without_knowledge_graph,
    profiling_agent,
    output_generation_agent,
)
from workflow2reasoning.core.config import AgentConfig
from workflow2reasoning.core.model.state import (
    AgentState,
)
from workflow2reasoning.logger import log


class UnderwritingAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            "Underwriter",
            "Underwriter agent for the underwriting process",
            state_schema=AgentState,
            config_schema=AgentConfig,
        )

        # Workflow
        self.workflow.add_edge(START, "underwriting_manager")
        self.workflow.add_node("underwriting_manager", self.underwriting_manager)

        risk_factor_agent = RiskFactorAgent()
        process_graph_agent = ProcessGraphOrchestratorAgent()
        comorbidity_graph_orchestrator = ComorbidityAgent()
        comorbidity_graph_no_kg = ComorbidityAgentNoKnowledgeGraph()
        worker_agents = {
            "profiling_agent": profiling_agent,
            "risk_factor_agent": risk_factor_agent.compile(),
            "process_graph_orchestrator": process_graph_agent.compile(),
            "comorbidity_graph_executor_agent": comorbidity_graph_orchestrator.compile(),
            "comorbidity_graph_no_kg": comorbidity_graph_no_kg.compile(),
            "aggregated_rating_agent": aggregated_rating_agent,
            "aggregated_rating_agent_without_knowledge_graph": aggregated_rating_agent_without_knowledge_graph,
        }

        for agent_name, agent in worker_agents.items():
            self.workflow.add_node(agent_name, agent)
            self.workflow.add_edge(
                agent_name, "underwriting_manager"
            )  # Add edge to underwriting_manager for all agents
        
        self.workflow.add_node("output_generation_agent", output_generation_agent)
        self.workflow.add_edge("output_generation_agent", END)

    def _get_missing_comorbidity_impairments(self, state: AgentState) -> list[str]:
        """Get the impairments that are missing comorbidity information."""
        missing_comorbidity_runs = []
        for i, v in state.trace.items():
            if "co-morbidity" not in v["rating"]:
                missing_comorbidity_runs.append(i)
        return missing_comorbidity_runs


    def underwriting_manager(
        self, state: AgentState, config: RunnableConfig
    ) -> Command[
        Literal[
            "__end__",
            "profiling_agent",
            "risk_factor_agent",
            "process_graph_orchestrator",
            "comorbidity_graph_executor_agent",
            "comorbidity_graph_no_kg",
            "aggregated_rating_agent",
        ]
    ]:
        """Underwriting manager decides the next best action to take based on the state of the conversation.

        This agent is responsible for deciding the next agent to be called based on the state of the conversation, Please note, this agent is sequential and the order of operations is very important.
        This should be a very light agent and should not contain any heavy computation as it will be called for every message and every transition.
        """
        if not state.profile:
            log.info("Calling profiling agent to get patient profiling information")
            return Command(goto="profiling_agent")

        if not state.impairments:
            log.info("Calling impairment agent to get patient impairments")
            return Command(goto="risk_factor_agent")

        if state.impairments and state.impairments[0] == 'No impairments detected':
            log.info("No impairments detected, ending the workflow")
            return Command(goto="output_generation_agent")
        
        if len(state.impairments) > len(state.trace.keys()):
            missing_graph_runs = set(state.impairments) - set(state.trace.keys())
            log.info(
                f"Calling process graph orchestrator to run graph(s): {missing_graph_runs}"
            )
            return Command(goto="process_graph_orchestrator")
        
        ablation_type = config.get("configurable").get("ablation_type", None)
            
        # Assuming the comorbidity graph is called when none of the trace, items have a comorbidity key in them.
        missing_comorbidity_runs = self._get_missing_comorbidity_impairments(state)
        if missing_comorbidity_runs:
            if ablation_type is None or ablation_type == "ablation_1":
                log.info(
                    f"Calling comorbidity graph executor agent to run graph(s): {missing_comorbidity_runs}"
                )
                return Command(goto="comorbidity_graph_executor_agent")
            elif ablation_type in ["ablation_2", "ablation_3"]:
                log.info(
                    f"Calling comorbidity graph no knowledge graph agent to run graph(s): {missing_comorbidity_runs}"
                )
                return Command(goto="comorbidity_graph_no_kg")

        if not state.overall_rating:
            if ablation_type is None or ablation_type in ["ablation_1", "ablation_2"]:
                log.info("Calling aggregated rating agent to get overall rating")
                return Command(goto="aggregated_rating_agent")
            elif ablation_type == "ablation_3":
                log.info("Calling aggregated rating agent without knowledge graph to get overall rating")
                return Command(goto="aggregated_rating_agent_without_knowledge_graph")
            
        if not state.reasoning_summary:
            log.info("Calling output generation agent to get final output")
            return Command(goto="output_generation_agent")


if __name__ == "__main__":
    # quick test to view results on mlflow
    import os
    import mlflow
    from langchain_core.runnables import RunnableParallel

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan end to end single case")
    # S075
    # medical_summary = """
    # A 36-year-old male, non-smoker, height 5'9", weight 175 lbs, was diagnosed with epilepsy in July 2020. His last seizure was in June this year. He experiences grand mal seizures 1-2 times per year, controlled with Keppra 750 mg twice daily. No other health issues are reported.
    # """
    trials = 2

    medical_summary = """57-year-old male is seeking a 10-year term policy for $2,000,000. He has never used tobacco. He was diagnosed with sleep apnea in 2009 and uses CPAP daily. He has a history of kidney stones (passed naturally in 2016), astigmatism (diagnosed 15 years ago, last follow-up 01/2024), and back pain from scoliosis (diagnosed within the last 5-10 years, managed with stretching). He also has mild thrombocytopenia (diagnosed 09/2021, stable, no bleeding concerns), and hypercholesterolemia (not currently on medication, cholesterol 245 in 09/2024)."""

    with mlflow.start_run() as run:
        with mlflow.start_span(name="Underwriting Agent"):
            chain = UnderwritingAgent().compile()

            rp_dict = {
                f"trial-{i}" : chain
                for i in range(trials)
            }
            
            rp_chain = RunnableParallel(
                **rp_dict,
            )

            input_state = AgentState(
                medical_summary=medical_summary,
            )

            output = rp_chain.invoke(
                input_state,
                config={
                    "max_concurrency": 4,
                    "recursion_limit": 300,
                    "configurable": {
                        "model_name": "azure_openai:gpt-5",
                        "ablation_type": "ablation_3",
                    }
                }
            )
        log.info(output)  
        mlflow.flush_trace_async_logging()
