import datetime

from langchain_core.exceptions import OutputParserException
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.runnables.config import RunnableConfig
from openai import InternalServerError, RateLimitError

from workflow2reasoning.constant import PROMPT_DIR
from workflow2reasoning.core.config import MAX_RETRIES_FOR_CHAINS
from workflow2reasoning.core.model.state import (
    Profile,
    ProfilingAgentInput,
    ProfilingAgentOutput,
)
from workflow2reasoning.core.utils.llm import get_llm_model
from workflow2reasoning.core.utils.prompt import read_template


def calculate_age(dob: datetime.date) -> int:
    """Calculate age from date of birth.

    This function calculates the age in years based on the provided date of birth.

    Args:
        dob (str): Date of birth in YYYY-MM-DD format.

    Returns:
        int: Age in years.
    """
    today = datetime.date.today()
    age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return age


def calculate_bmi(weight: int, height: int) -> float:
    """Calculate BMI from weight and height.

    Args:
        weight (int): Weight in pounds.
        height (int): Height in inches.

    Returns:
        float: Calculated BMI.
    """
    bmi = (weight / (height**2)) * 703
    return round(bmi, 2)


def profiling_agent(
    state: ProfilingAgentInput, config: RunnableConfig
) -> ProfilingAgentOutput:
    """Profiling agent for underwriting will help profile the customer and extract neccesary information.

    Profiling agent:  This agent for underwriting can help "profile" or "summarize" information we think should be shared with model.
    Here are couple of things, this agent can do:
    - Extract basic patient profile like, Date of Birth, Age, Weight, Height and other basic information.
    - Perform basic Normalization of data like, converting all the data into standard formats (eg. Date of Birth to ISO format, weight to Pounds).
    """
    model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")
    medical_summary = state.medical_summary
    model = get_llm_model(deployment_name=model_name, temperature=0, seed=1234)
    prompt_template_profiling = read_template(
        template_path=PROMPT_DIR.joinpath("profiling.jinja2")
    )
    parser = PydanticOutputParser(pydantic_object=Profile)
    chain = prompt_template_profiling | model | parser

    chain = chain.with_retry(
        retry_if_exception_type=(
            OutputParserException,
            RateLimitError,
            InternalServerError,
        ),
        stop_after_attempt=MAX_RETRIES_FOR_CHAINS,
        wait_exponential_jitter=True,
    )
    profiling_result = chain.invoke(
        {
            "medical_summary": medical_summary,
            "pydantic_instructions": parser.get_format_instructions(),
        }
    )

    profiling_json_dict = profiling_result.model_dump()
    # TODO: MOVE TO FUNCTION CALLING FOR CALCULATING AGE AND BMI!!!
    if (
        profiling_json_dict.get("age", None) == None
        and profiling_json_dict.get("date_of_birth", None) != None
    ):
        profiling_json_dict["age"] = calculate_age(profiling_json_dict["date_of_birth"])
    if (
        profiling_json_dict.get("BMI", None) == None
        and profiling_json_dict.get("weight") != None
        and profiling_json_dict.get("height") != None
    ):
        profiling_json_dict["BMI"] = calculate_bmi(
            profiling_json_dict["weight"], profiling_json_dict["height"]
        )

    return ProfilingAgentOutput(
        profile={
            "age": profiling_json_dict["age"],
            "date_of_birth": profiling_json_dict["date_of_birth"],
            "gender": profiling_json_dict["gender"],
            "height": profiling_json_dict["height"],
            "weight": profiling_json_dict["weight"],
            "BMI": profiling_json_dict["BMI"],
            "smoking_status": profiling_json_dict["smoking_status"],
        }
    )
