import json

# from langchain_openai import AzureChatOpenAI
# from pymongo import MongoClient
import os
from typing import Annotated, List

from langchain_core.runnables.config import RunnableConfig

# from langchain_openai import AzureOpenAIEmbeddings,OpenAIEmbeddings, ChatOpenAI
from langgraph.graph import END, START
from pydantic import BaseModel

from workflow2reasoning.constant import PROMPT_DIR, STD_NAMES_MAPPING_TO_GRAPH_FILEPATH
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.utils.llm import get_chain_with_retry

# from azure.identity import DefaultAzureCredential, get_bearer_token_provider
# from azure.core.exceptions import ServiceResponseError
# from utils import get_llm, get_embedding_model,load_jinja_prompt
from workflow2reasoning.core.utils.reducers import add_unique
from workflow2reasoning.logger import log

# from config import Settings


# Define state type
class RiskFactorState(BaseModel):
    medical_summary: str


# Define output
class RiskFactorAgentOutput(BaseModel):
    impairments: Annotated[list[str], add_unique] = []


class ImpairmentOutput(BaseModel):
    snippet: str
    reasoning: str
    matched_standard_name: str | list[str] | None = None


class AllImpairmentsOutput(BaseModel):
    impairment_relevant_snippets: List[str] = []
    extracted_impairments: List[ImpairmentOutput] = []


# Initialize tools
# embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
# llm = ChatOpenAI(model="gpt-4")


class RiskFactorAgent(Agent):
    def __init__(self):
        super().__init__(
            "RiskFactorAgent",
            "An agent that maps extracted medical impairments to a standardized list using vector search and LLMs.",
            state_schema=RiskFactorState,
            output=RiskFactorAgentOutput,
        )
        self.workflow.add_node("extract_impairments", self.extract_impairments_node)
        self.workflow.add_edge(START, "extract_impairments")
        self.workflow.add_edge("extract_impairments", END)

    def extract_impairments_node(
        self, state: RiskFactorState, config: RunnableConfig
    ) -> RiskFactorState:
        log.info(
            "[extract_impairments_node] Starting extraction of impairments from medical summary."
        )
        completion_chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "extract_impairments.jinja2",
            output_format=AllImpairmentsOutput,
            model_name=config.get("configurable").get(
                "model_name", "azure_openai:gpt-4o"
            ),
        )

        mapping = json.load(open(STD_NAMES_MAPPING_TO_GRAPH_FILEPATH))

        standard_impairment_names = list(mapping.keys())

        output = completion_chain.invoke(
            {
                "medical_summary": state.medical_summary,
                "standard_impairment_names": standard_impairment_names,
            }
        )

        log.info(
            f"Output from extract_impairments_node: {json.dumps(output.model_dump(), indent=2)}"
        )

        extracted_impairments = []
        for extracted_impairments_info in output.extracted_impairments:
            if extracted_impairments_info.matched_standard_name:
                if isinstance(extracted_impairments_info.matched_standard_name, list):
                    for name in extracted_impairments_info.matched_standard_name:
                        if name in standard_impairment_names:  # only add if it's in the standard list
                            extracted_impairments.append(name)
                else:
                    if extracted_impairments_info.matched_standard_name in standard_impairment_names: # only add if it's in the standard list
                        extracted_impairments.append(
                            extracted_impairments_info.matched_standard_name
                        )

        if len(extracted_impairments) == 0:
            extracted_impairments.append("No impairments detected")

        return {"impairments": extracted_impairments}


if __name__ == "__main__":
    # quick test to view results on mlflow
    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = RiskFactorAgent().compile()
        input_state = RiskFactorState(
            medical_summary="A 57-year-old male, height 5'9\", weight 198 lbs, blood pressure 129/65, is seeking term or permanent coverage. Cholesterol is 412, cholesterol/HDL ratio is 6.1, and triglycerides are elevated at 639. He reports monthly marijuana use (smoked and edible) for back pain.",
        )

        output = agent.invoke(
            {
                "medical_summary": input_state.medical_summary,
            }
        )

    mlflow.flush_trace_async_logging()
