import json
import os
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Send
from networkx.readwrite import json_graph
from pydantic import BaseModel

from workflow2reasoning.constant import KNOWLEDGE_GRAPH_FILEPATH, PROMPT_DIR, DATA_DIR, STD_NAMES_MAPPING_TO_CHAPTER_FILEPATH
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.config import (
    AgentConfig,
)
from workflow2reasoning.core.model.alerting import Alert
from workflow2reasoning.core.model.state import (
    AgentState,
)
from workflow2reasoning.core.utils.llm import get_chain_with_retry
from workflow2reasoning.core.utils.reducers import merge, update_list
from workflow2reasoning.core.utils.chapters import get_page_contents
from workflow2reasoning.logger import log


class SingleImpairmentComorbidityAgentOutputNoKnowledgeGraph(BaseModel):
    trace: Annotated[dict[str, dict[str, Any]], merge]


class SingleImpairmentComorbidityAgentStateNoKnowledgeGraph(BaseModel):
    # passed from parent state
    impairment: str
    medical_summary: str
    profile: dict[str, Any]
    trace_local: dict[str, dict[str, Any]]  # local copy of the state
    impairments_local: list[str] | None = None
    current_rating: str


class AdditionalConsiderationsOutput(BaseModel):
    reasoning: str
    life_rating: str


class SingleImpairmentComorbidityAgentNoKnowledgeGraph(Agent):
    def __init__(self):
        super().__init__(
            "SingleImpairmentComorbidityAgentNoKnowledgeGraph",
            "Agent to handle single impairment comorbidity analysis without knowledge graph",
            output=SingleImpairmentComorbidityAgentOutputNoKnowledgeGraph,
            state_schema=SingleImpairmentComorbidityAgentStateNoKnowledgeGraph,
            config_schema=AgentConfig,
        )
        self.workflow.add_node("get_comorbidity_rating", self.get_comorbidity_rating)
        self.workflow.add_edge(START, "get_comorbidity_rating")
        self.workflow.add_edge("get_comorbidity_rating", END)


    def get_comorbidity_rating(
        self, state: SingleImpairmentComorbidityAgentStateNoKnowledgeGraph, config: RunnableConfig
    ):
        """Execute all edges for the current impairment."""
        log.info("Executing node: get_comorbidity_rating")
    
        contents = get_page_contents(std_name=state.impairment)

        additional_considerations = contents.get("additional_considerations", None)

        if not additional_considerations:
            log.info(
                f"No additional considerations found for impairment: {state.impairment}"
            )
            original_impairment_trace = state.trace_local[state.impairment]
            original_impairment_trace["comorbidity_steps"] = []
            original_impairment_trace["rating"]["co-morbidity"] = state.current_rating
            return {
                "trace": {state.impairment: original_impairment_trace},
            }
        
        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")

        completion_chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "execute_additional_considerations.jinja2",
            output_format=AdditionalConsiderationsOutput,
            model_name=model_name,
        )

        output: AdditionalConsiderationsOutput = completion_chain.invoke(
            {
                "primary_impairment": state.impairment,
                "medical_summary": state.medical_summary,
                "profile": state.profile,
                "current_date": datetime.now().strftime("%B %Y"),
                "current_rating": state.current_rating,
                "all_impairments_trace": state.trace_local,
                "additional_considerations": additional_considerations,
            }
        )

        original_impairment_trace = state.trace_local[state.impairment]
        original_impairment_trace["rating"]["co-morbidity"] = (
            output.life_rating
        )

        # Append all relevant edges execution to the trace for state.impairment
        original_impairment_trace["comorbidity_steps"] = []

        # add the final combining step as well
        original_impairment_trace["comorbidity_steps"].append(
            {
                "step_id": 1,
                "step_description": f"Apply additional considerations for impairment: {state.impairment}",
                "step_execution": f"Reasoning...{output.reasoning}",
                "step_outcome": output.life_rating,
            }
        )

        return {
            "trace": {state.impairment: original_impairment_trace},
        }


class ComorbidityAgentNoKnowledgeGraph(Agent):
    def __init__(self):
        super().__init__(
            "ComorbidityAgent",
            "Agent to handle comorbidity analysis",
            state_schema=AgentState,
            config_schema=AgentConfig,
        )

        comorbidity_runner = SingleImpairmentComorbidityAgentNoKnowledgeGraph().compile()

        self.workflow.add_node("comorbidity_runner", comorbidity_runner)
        self.workflow.add_node(
            "block_for_batch_completion_comorbidity",
            self.block_for_batch_completion_comorbidity,
        )

        self.workflow.add_conditional_edges(
            START, self.run_batch_of_comorbidity_analysis
        )
        self.workflow.add_edge(
            "comorbidity_runner", "block_for_batch_completion_comorbidity"
        )
        self.workflow.add_edge("block_for_batch_completion_comorbidity", END)

    def run_batch_of_comorbidity_analysis(
        self, state: AgentState, config: RunnableConfig
    ) -> list[Send]:
        """Run the comorbidity analysis for all impairments in the input."""
        log.info("Executing node: run_batch_of_comorbidity_analysis")
        return [
            Send(
                "comorbidity_runner",
                SingleImpairmentComorbidityAgentStateNoKnowledgeGraph(
                    trace_local=state.trace,
                    medical_summary=state.medical_summary,
                    impairment=imp,
                    current_rating=state.trace[imp]["rating"]["life_rating"],
                    profile=state.profile,
                    impairments_local=state.impairments,
                ),
            )
            for imp in state.impairments
        ]

    def block_for_batch_completion_comorbidity(
        self, state: AgentState, config: RunnableConfig
    ):
        """Block until all comorbidity analysis is complete."""
        log.info("Executing node: block_for_batch_completion_comorbidity")
        return {}


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = ComorbidityAgentNoKnowledgeGraph().compile()
        input_state = AgentState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5 and a normal build.",
            impairments=["Diabetes Mellitus", "Depression"],
            profile={
                "age": "30",
                "BMI": "25",
            },
            trace={
                "Diabetes Mellitus": {
                    "rating": {
                        "life_rating": "+40",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Initial assessment of diabetes status",
                            "step_execution": "Reviewed patient's medical history and recent A1C levels.",
                            "step_outcome": "Identified that the patient has type 2 diabetes with an A1C of 8.5.",
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate risk factors associated with diabetes",
                            "step_execution": "Considered age, BMI, lifestyle, and family history.",
                            "step_outcome": "Patient is 30 years old with a normal BMI of 25, which is a positive factor.",
                        },
                        {
                            "step_id": 3,
                            "step_description": "Determine overall life rating based on current health status",
                            "step_execution": "Used clinical guidelines to assess the impact of diabetes on life expectancy.",
                            "step_outcome": "Assigned a life rating of Moderate due to the presence of diabetes and elevated A1C.",
                        },
                    ],
                },
                "Depression": {
                    "rating": {
                        "life_rating": "+0",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Assess patient's medical history and current mental health status",
                            "step_execution": "Reviewed patient's medical history and current medications.",
                            "step_outcome": "Identified that the patient has no relevant history of depression.",
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate lifestyle factors influencing build",
                            "step_execution": "Reviewed dietary habits and physical activity levels.",
                            "step_outcome": "Patient maintains a balanced diet and exercises regularly.",
                        },
                    ],
                },
            },
        )
        output = agent.invoke(input_state)

    log.info(json.dumps(output, indent=2))

    mlflow.flush_trace_async_logging()
