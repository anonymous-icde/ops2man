import json
from typing import Any
from langchain_core.runnables.config import RunnableConfig
from networkx.readwrite import json_graph
from workflow2reasoning.constant import KNOWLEDGE_GRAPH_FILEPATH, DATA_DIR, PROMPT_DIR
from workflow2reasoning.core.model.state import AgentState
from workflow2reasoning.core.utils.chapters import get_page_contents
from workflow2reasoning.core.utils.llm import get_chain_with_retry
from workflow2reasoning.logger import log
import os
from pydantic import BaseModel


class RatingAgregationInputKnowledgeGraph(BaseModel):
    trace: dict[str, dict[str, Any]]


class RatingAgregationOutputKnowledgeGraph(BaseModel):
    overall_rating: dict[str, str] = {}
    aggregation_reasoning: str = ""

class AdditionalConsiderationsOutput(BaseModel):
    reasoning: str
    life_rating: str

def aggregated_rating_agent_without_knowledge_graph(
    state: RatingAgregationInputKnowledgeGraph, config: RunnableConfig
) -> RatingAgregationOutputKnowledgeGraph:
    """
    Agreegated Rating agent applies the rating aggregation logic to compute the final LIFE rating and rider ratings. 
    """
    log.info("Starting aggregated rating agent without knowledge graph...")

    all_additional_considerations = {}
    for impairment in state.trace.keys():
        all_additional_considerations[impairment] = get_page_contents(std_name=impairment).get("additional_considerations", "")

    model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")

    completion_chain = get_chain_with_retry(
        prompt_path=PROMPT_DIR / "rating_aggregation.jinja2",
        output_format=AdditionalConsiderationsOutput,
        model_name=model_name,
    )

    output: AdditionalConsiderationsOutput = completion_chain.invoke(
        {
            "trace": state.trace,
            "all_additional_considerations": all_additional_considerations,
        }
    )

    return {
        "overall_rating": {
            "life_rating": output.life_rating,
        },
        "aggregation_reasoning": output.reasoning,
    }


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = aggregated_rating_agent_without_knowledge_graph
        input_state = AgentState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5 and a normal build.",
            impairments=["Diabetes Mellitus", "Depression"],
            profile={
                "age": "30",
                "BMI": "25",
            },
            trace={
                "Diabetes Mellitus": {
                    "rating": {
                        "life_rating": "+40",
                        "co-morbidity": "+40",
                        "ltc": "+20",
                        "wp": "+10",
                        "adb": "+10",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Initial assessment of diabetes status",
                            "step_execution": "Reviewed patient's medical history and recent A1C levels.",
                            "step_outcome": "Identified that the patient has type 2 diabetes with an A1C of 8.5."
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate risk factors associated with diabetes",
                            "step_execution": "Considered age, BMI, lifestyle, and family history.",
                            "step_outcome": "Patient is 30 years old with a normal BMI of 25, which is a positive factor."
                        },
                        {
                            "step_id": 3,
                            "step_description": "Determine overall life rating based on current health status",
                            "step_execution": "Used clinical guidelines to assess the impact of diabetes on life expectancy.",
                            "step_outcome": "Assigned a life rating of Moderate due to the presence of diabetes and elevated A1C."
                        }
                    ]
                },
                "Depression": {
                    "rating": {
                        "life_rating": "+0",
                        "co-morbidity": "+10",
                        "ltc": "+10",
                        "wp": "+10",
                        "adb": "+10",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Assess patient's medical history and current mental health status",
                            "step_execution": "Reviewed patient's medical history and current medications.",
                            "step_outcome": "Identified that the patient has no relevant history of depression."
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate lifestyle factors influencing build",
                            "step_execution": "Reviewed dietary habits and physical activity levels.",
                            "step_outcome": "Patient maintains a balanced diet and exercises regularly."
                        }
                    ]
                }
            }
        )
        output = agent(input_state, RunnableConfig(configurable={"model_name": "azure_openai:gpt-4o"}))
    
    log.info(json.dumps(output, indent=2))
