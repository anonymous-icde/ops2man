import json
import os
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any
from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from pydantic import BaseModel
from workflow2reasoning.constant import (
    PROMPT_DIR,
    DATA_DIR,
    STD_NAMES_MAPPING_TO_CHAPTER_FILEPATH,
)
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.model.state import (
    merge,
)
from workflow2reasoning.core.utils.llm import get_chain_with_retry
from workflow2reasoning.core.utils.reducers import add_unique
from workflow2reasoning.core.utils.chapters import get_page_contents
from workflow2reasoning.logger import log


class SingleChapterRunnerOutput(BaseModel):
    # Represents the output of the subgraph.
    # - `trace`: A dictionary where the key is the impairment, and the value contains the final ratings and execution trace.
    # - `impairments`: A list of any new impairments to be processed.
    trace: Annotated[dict[str, dict[str, Any]], merge]
    impairments: Annotated[list[str], add_unique] = []


# Model for the overall state of the subgraph
class SingleChapterRunnerState(BaseModel):
    # read from the parent state (AgentState)
    medical_summary: str
    profile: dict[str, Any]

    # inputs
    impairment: str


# endregion

class ChapterExecution(BaseModel):
    reasoning: str
    life_rating: str
    ltc: str
    wp: str
    adb: str


# region: SingleChapterRunner agent
# This is the agent that will be responsible for running a single process graph for a given impairment. It is defined as an Langgraph subgraph.
class SingleChapterRunner(Agent):
    def __init__(self):
        super().__init__(
            "SingleChapterRunner",
            "Single Chapter Runner agent for to rate single impairment",
            state_schema=SingleChapterRunnerState,
            output=SingleChapterRunnerOutput,
        )

        # Add all the nodes in the graph
        self.workflow.add_node("get_impairment_ratings", self.get_impairment_ratings)

        # Add all the edges in the graph
        self.workflow.add_edge(START, "get_impairment_ratings")
        self.workflow.add_edge("get_impairment_ratings", END)


    def get_impairment_ratings(
        self, state: SingleChapterRunnerState, config: RunnableConfig
    ):
        """Execute the next step in the graph and return the raw rating and reasoning."""
        log.info("Executing node: get_impairment_ratings")
        
        contents = get_page_contents(std_name=state.impairment)

        # Extract the relevant information from the contents
        general_info = contents.get("general_information", "")
        rating_info = contents.get("rating", "")

        chapter = f"General Information:\n{general_info}\n\nRating Information:\n{rating_info}"

        # Execute the step and get the output
        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")

        completion_chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "execute_chapter.jinja2",
            output_format=ChapterExecution,
            model_name=model_name,
        )

        output: ChapterExecution = completion_chain.invoke(
            {
                "impairment": state.impairment,
                "medical_summary": state.medical_summary,
                "applicant_profile": state.profile,
                "chapter": chapter,
                "current_date": datetime.now().strftime("%B %Y"),
            }
        )

        log.info(f"Output: {output}")

        # trace
        trace = []
        
        trace.append(
            {
                "step_id": 1,
                "step_description": f"Ran the complete chapter for impairment:  {state.impairment}",
                "step_outcome": output.life_rating,
                "step_execution": f"Reasoning...{output.reasoning}",
            }
        )

        return {
            "trace": {
                state.impairment: {
                    "rating": {k:v for k,v in output.model_dump().items() if k != "reasoning"},
                    "steps": trace,
                }
            },
        }


# endregion


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = SingleChapterRunner().compile()
        input_state = SingleChapterRunnerState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5.",
            impairment="Diabetes Mellitus",
            profile={
                "age": "30",
                "BMI": "25",
            },
        )

        output = agent.invoke(input_state)

    log.info(json.dumps(output, indent=2))

    mlflow.flush_trace_async_logging()
