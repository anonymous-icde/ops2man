from langchain_core.runnables.graph import CurveStyle, MermaidDrawMethod, NodeStyles
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledStateGraph


class Agent:
    def __init__(self, name: str, description: str, **kwargs):
        self.name = name
        self.description = description
        self.workflow = StateGraph(**kwargs)

    def compile(self, *args, **kwargs) -> CompiledStateGraph:
        """Compile the workflow into a runnable graph."""
        return self.workflow.compile(*args, **kwargs)

    def draw(self, destination: str):
        """Draw the workflow graph to a file."""
        self.compile().get_graph().draw_mermaid_png(
            curve_style=CurveStyle.CARDINAL,
            node_colors=NodeStyles(),
            draw_method=MermaidDrawMethod.PYPPETEER,
            output_file_path=destination,
        )
