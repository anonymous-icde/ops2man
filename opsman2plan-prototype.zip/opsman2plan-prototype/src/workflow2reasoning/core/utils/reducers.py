import functools
from typing import TypeVar


def add(a: list, b: list) -> list:
    return a + b


def add_unique(a: list, b: list) -> list:
    """
    Add unique elements to a list
    """
    return list(set(a + b))


class Add[T]:
    def __init__(self, item: T):
        self.item = item


class Remove[T]:
    def __init__(self, item: T):
        self.item = item


class Replace[T]:
    def __init__(self, old: T, new: T):
        self.old = old
        self.new = new

    def in_list(self, a: list[T], reraise: bool = False) -> list[T]:
        try:
            index = a.index(self.old)
            a[index] = self.new
            return a
        except ValueError:
            if reraise:
                raise ValueError(f"{self.old} not found in list")
            a.append(self.new)
            return a


T = TypeVar("T")
type AnyAction[T] = Add[T] | Remove[T] | Replace[T] | list[T] | T


def update_list(a: list[T], b: AnyAction[T]) -> list[T]:
    if isinstance(b, Remove):
        # find the item in the list and remove it
        return [i for i in a if i != b.item]
    elif isinstance(b, Add):
        # add the item to the list
        return add_unique(a, [b.item])
    elif isinstance(b, Replace):
        # find the old item in the list and replace it with the new item
        return b.in_list(a)
    elif isinstance(b, list):
        # Append the list to the existing list
        return functools.reduce(update_list, b, a)
    else:
        return add_unique(a, [b])


def merge(original: dict, new: dict) -> dict:
    return original | new


def add_dict_list(
    current: dict[str, list[str]], update: dict[str, list[str]]
) -> dict[str, list[str]]:
    """Merge two dictionary of lists.

    If a key is present in both dictionaries, merge their values and use unique as final values.
    """
    result = current.copy()
    for key, value in update.items():
        if key in result:
            result[key] = add_unique(result[key], value)
        else:
            result[key] = value
    return result
