"""Provide functions to read and parse jinja2 template files.

#! jinja2 template must be in the following format:
'''
system: |
  You are a helpful AI bot who can tell the number of digits in a number.

few_shot_examples:
    -   input: |
            Tell me the number of digits in 1341, 3515315, and 114
        output: |
            The number of digits are 4, 7, 3
    -   input: |
            Tell me the number of digits in 8
        output: |
            The number of digits are 1
user: |
    Tell me the number of digits in {{ numbers | join(', ') }}
'''

"""

from pathlib import Path
from typing import Literal

import yaml
from langchain_core.prompts import (
    AIMessagePromptTemplate,
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)


# define function to read jinja2 template
def read_template(
    template_path: Path, template_format: Literal["jinja2", "f-string"] = "jinja2"
) -> ChatPromptTemplate:
    """Read template file and return ChatPromptTemplate object.

    Args:
        template_path (Path): Path to the template file
        template_format (Literal['jinja2', 'f-string'], optional): Defaults to 'jinja2'.

    Returns:
        ChatPromptTemplate: ChatPromptTemplate object

    Raises:
        FileNotFoundError: If template file not found.
    """
    if not template_path.is_file():
        raise FileNotFoundError(
            f"Promp file not found: {template_path}Please check the path and try again"
        )

    # read template file
    data_dict = yaml.safe_load(template_path.read_text(encoding="utf-8"))
    return _parse_jinja2_template(data_dict, template_format=template_format)


# deffine function to parse data from jinja2 template
def _parse_jinja2_template(
    data_dict: dict, template_format: Literal["jinja2", "f-string"] = "jinja2"
) -> ChatPromptTemplate:
    """Parse data from jinja2 template and return ChatPromptTemplate object.

    Args:
        data_dict (dict): Data dictionary
        template_format (Literal["jinja2", "f-string"]) : Defaults to 'jinja2'.

    Raises:
        ValueError: If data_dict is not a dictionary

    Returns:
        ChatPromptTemplate: ChatPromptTemplate object
    """
    # check if data_dict is dictionary
    if not isinstance(data_dict, dict):
        raise ValueError("Invalid data type, expected dictionary")

    # check if dictionary has required keys , few_shot_examples is optional
    if not all(key in data_dict for key in ["system", "user"]):
        raise ValueError(
            "Data dictionary must have 'system' and 'user' keys, "
            "'few_shot_examples' is optional"
        )
    else:
        # initiate dict
        messages = []

        # read system message
        messages.append(
            SystemMessagePromptTemplate.from_template(
                data_dict["system"], template_format=template_format
            )
        )

        # read few shot examples
        if "few_shot_examples" in data_dict:
            for rows in data_dict["few_shot_examples"]:
                messages.append(
                    HumanMessagePromptTemplate.from_template(
                        rows["input"], template_format=template_format
                    )
                )
                messages.append(
                    AIMessagePromptTemplate.from_template(
                        rows["output"], template_format=template_format
                    )
                )

        # read user message
        messages.append(
            HumanMessagePromptTemplate.from_template(
                data_dict["user"], template_format=template_format
            )
        )

        return ChatPromptTemplate(messages)
    
def load_jinja_prompt(template_name: str) -> ChatPromptTemplate:
 
    """
    Load a Jinja prompt template from a file.

    Args:
        template_name (str): Name of the template file without extension.



    Returns:
        ChatPromptTemplate: ChatPromptTemplate object
    """
    #prompt_dir = Path(__file__).parent / "prompts"
    prompt_dir = (Path(__file__).parent.parent.parent / "prompts").resolve()
    prompt = prompt_dir.joinpath(f"{template_name}.jinja2")
    
    # Create a ChatPromptTemplate with system and human messages
    return ChatPromptTemplate.from_messages([
        ("system", prompt.read_text()),
        ("human", "{{input}}")
    ], template_format="jinja2")

