import json
import re
from pathlib import Path

from workflow2reasoning.constant import STD_NAMES_MAPPING_TO_CHAPTER_FILEPATH, DATA_DIR

def extract_contents(page, content) -> dict:
    pattern = r"(?:###|##) \d+\. General Information(.*?)(?:###|##) \d+\. Rating(.*?)(?:(?:###|##) \d+\. Additional Considerations(.*?))?$"
    matches = re.search(pattern, content, re.DOTALL)

    try:
        general_info = matches.group(1).strip()
        rating_info = matches.group(2).strip()
    except AttributeError:
        raise ValueError(f"Failed to parse content for page '{page}'. Please check the markdown format.")
    additional_info = matches.group(3).strip() if matches.lastindex >= 3 else None

    return dict(
        page_name=page.replace("(", "\\(").replace(")", "\\)"),
        general_information=general_info,
        rating=rating_info,
        additional_considerations=additional_info
    )


def get_page_contents(std_name: str) -> dict:
    # get the impairment page
    mapping = json.load(open(STD_NAMES_MAPPING_TO_CHAPTER_FILEPATH))
    if std_name not in mapping:
        raise ValueError(
            f"Impairment {std_name} not found in mapping file."
        )

    chapter_text = Path(DATA_DIR / "chapters" / mapping[std_name]).read_text()

    return extract_contents(page=std_name, content=chapter_text)

