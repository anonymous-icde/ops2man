import os
from dataclasses import fields
from typing import Any, Optional

from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel, Field

MAX_RETRIES_FOR_CHAINS = 8

class RedactionAgentConfig(BaseModel):
    max_retries: int = 3


class AgentConfig(BaseModel):
    max_retries: int = 3

    redaction: RedactionAgentConfig = Field(default_factory=RedactionAgentConfig)

    @classmethod
    def from_runnable_config(
        cls, config: Optional[RunnableConfig] = None
    ) -> "AgentConfig":
        """Create a Configuration instance from a RunnableConfig."""
        configurable = (
            config["configurable"] if config and "configurable" in config else {}
        )
        values: dict[str, Any] = {
            f.name: os.environ.get(f.name.upper(), configurable.get(f.name))
            for f in fields(cls)
            if f.init
        }
        return cls(**{k: v for k, v in values.items() if v})
