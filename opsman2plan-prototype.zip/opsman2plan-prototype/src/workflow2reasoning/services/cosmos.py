import os
from datetime import datetime
from typing import Any

from bson.objectid import ObjectId
from pymongo import DESCENDING, MongoClient

from workflow2reasoning.core.model.graph import Graph, GraphState
from workflow2reasoning.utils import require

APP_COSMOS_CONNECTION_STRING = require("APP_COSMOS_CONNECTION_STRING")
APP_COSMOS_DATABASE = require("APP_COSMOS_DATABASE")


def get_client() -> MongoClient:
    return MongoClient(APP_COSMOS_CONNECTION_STRING)


def get_collection(collection_name: str):
    return (
        get_client().get_database(APP_COSMOS_DATABASE).get_collection(collection_name)
    )


class CaseRepository:
    def __init__(self, collection_name: str = "case"):
        self.collection = get_collection(collection_name)

    def create_case(self, case: dict):
        return self.collection.insert_one(case)

    def get_case(self, case_name: str):
        return self.collection.find_one({"case_name": case_name})

    def update_case(self, case_name, case: dict):
        return self.collection.update_one({"case_name": case_name}, {"$set": case})

    def delete_case(self, case_name: str):
        return self.collection.delete_one({"case_name": case_name})

    def update_case_feedback(self, case_name, feedback: dict):
        """Update the feedback for a case in the database if one exists. Raise an error if the case doesn't exists."""
        # Update if case exists
        result = self.collection.update_one(
            {"case_name": case_name},
            {
                "$set": {
                    "feedback": {
                        "helpful": feedback.get("helpful"),
                        "comment": feedback.get("comment"),
                    },
                }
            },
        )
        # If the case doesn't exist, raise an error
        if result.matched_count == 0:
            raise Exception(f"Case {case_name} not found in the database.")
        return result

    def search_case(self, case_id):
        return list(
            self.collection.find({"case_name": {"$regex": case_id, "$options": "i"}})
        )

    def search(self, query, projection: dict = {"_id": False}):
        return list(self.collection.find(query, projection))

    def query(self, query: dict, projection: dict = None):
        return self.collection.find(query, projection)

    def has_existing_case(self, case_name: str) -> bool:
        """Check if a case exists in the database by its case_name."""
        return self.collection.count_documents({"case_name": case_name}) > 0


class GraphRepository:
    def __init__(self, collection_name: str = "graphs"):
        self.collection_name = collection_name
        self.revision_collection = f"{collection_name}_revision"

        self.collection = get_collection(collection_name)
        self.revision = get_collection(self.revision_collection)

    def get_graph_with_default_state(self, impairment_name: str):
        # @ani: most places where we call get_graph we are passing the state; so I created a default one here.
        state = (
            GraphState.PUBLISHED
            if os.getenv("ENV", "").lower() == "prod"
            else GraphState.IN_REVIEW
        )
        return self.get_graph(impairment_name, state)

    def get_graph(self, impairment_name: str, state: GraphState):
        # search the collection for the graph where impairment_name is equal to the page_name field or it maybe one of the strings in keywords field(array type field).
        with_page_name = self.collection.find_one(
            {"page_name": impairment_name, "state": state.value}
        )
        if with_page_name:
            return with_page_name

        return self.collection.find_one(
            {
                "keywords": impairment_name,
                "state": state.value,
            },
        )

    def get_graph_by_id(self, graph_id: str, state: GraphState):
        return self.collection.find_one({"id": graph_id, "state": state.value})

    def get_partial_match(self, impairment_name: str) -> list[dict]:
        return list(
            self.collection.find(
                {
                    "$or": [
                        {"page_name": {"$regex": impairment_name, "$options": "i"}},
                        {"keywords": {"$regex": impairment_name, "$options": "i"}},
                    ]
                }
            )
        )

    def add_graph(self, graph: Graph, state: GraphState):
        result = self.collection.insert_one(
            {
                **graph.model_dump(),
                "state": state.value,
                "revision": 1,
                "last_updated": datetime.now(),
            }
        )
        if result.acknowledged:
            self.revision.insert_one(
                {
                    **graph.model_dump(),
                    "state": state.value,
                    "revision": 1,
                    "last_updated": datetime.now(),
                }
            )
            return True
        else:
            raise Exception("Unable to upload the graph")

    def get_graph_versions(self, graph_id: str, state: GraphState):
        query = {"id": graph_id, "state": state.value}
        sort_order = [("revision", DESCENDING)]
        result = self.revision.find(query).sort(sort_order)
        return list(result)

    def update_graph(self, graph_id: str, state: GraphState, graph: Graph):
        self.collection.update_one(
            {"id": graph_id, "state": state.value},
            {
                "$inc": {"revision": 1},
                "$set": {**graph.model_dump(), "last_updated": datetime.now()},
            },
        )
        # This code snippet is performing an aggregation operation using MongoDB's aggregation
        # framework. Here's a breakdown of what each stage is doing:
        self.collection.aggregate(
            [
                {
                    "$match": {"id": graph_id, "state": state.value},
                },
                {"$set": {"_id": ObjectId()}},
                {
                    "$merge": {
                        "into": {
                            "db": APP_COSMOS_DATABASE,
                            "coll": self.revision_collection,
                        },
                        "on": "_id",
                        "whenNotMatched": "insert",
                    }
                },
            ]
        )
        return True

    def get_all_impairments(self, state: GraphState):
        # for all the graphs in the collection, return the page_name and keywords fields.
        pages = [
            x["page_name"]
            for x in self.collection.find({"state": state.value}, {"page_name": 1})
        ]
        return pages

    def get_all_impairments_by_module(
        self, state: GraphState, module_name: str = "Medical"
    ):
        """Return all page titles under Medical or Non-Medical."""
        pages = [
            x["page_name"]
            for x in self.collection.find(
                {"state": state.value, "metadata.module_name": module_name},
                {"page_name": 1},
            )
        ]
        return pages

    def get_all_impairments_with_keywords(self, state: GraphState):
        outputs = list()
        for x in self.collection.find(
            {"state": state.value}, {"page_name": 1, "keywords": 1}
        ):
            outputs.append(x.get("page_name"))
            outputs.extend(x.get("keywords"))
        return outputs

    def get_all_impairments_with_keywords_seperated(self, state: GraphState):
        impairments = list()
        keywords = list()
        for x in self.collection.find(
            {"state": state.value}, {"page_name": 1, "keywords": 1}
        ):
            impairments.append(x.get("page_name"))
            keywords.extend(x.get("keywords"))
        return impairments, keywords

    def query(self, query: dict, projection: dict = None):
        return self.collection.find(query, projection)


def get_verified_impairments(impairments: dict[str, Any]):
    """Get a list of verified impairments from the given dictionary."""
    graph_repo = GraphRepository()
    i = list(impairments.keys()) if impairments is not None else []
    verified = list(
        map(
            lambda x: x["page_name"],  # type: ignore
            filter(
                lambda x: x is not None,
                [graph_repo.get_graph(imp, GraphState.PUBLISHED) for imp in i],
            ),
        )
    )
    return verified
