from workflow2reasoning.logger import init_logger

init_logger()
