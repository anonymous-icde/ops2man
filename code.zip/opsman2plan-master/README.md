# opsman2plan
A repo to analyze operational manuals like UW manual and reasonon them
