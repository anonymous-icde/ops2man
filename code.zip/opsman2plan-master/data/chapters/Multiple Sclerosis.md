# Multiple Sclerosis  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Multiple Sclerosis (MS) is a chronic, immune-mediated demyelinating disease of the central nervous system, characterized by episodes of neurological dysfunction and progressive disability.

**Typical Signs and Symptoms:**
- Visual disturbances (optic neuritis, blurred vision)
- Muscle weakness, spasticity
- Numbness, tingling, sensory loss
- Fatigue
- Gait and balance problems
- Bladder or bowel dysfunction
- Cognitive impairment
- Depression

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Early age at onset
- Frequent relapses
- Progressive disease course (primary or secondary)
- Incomplete recovery from relapses
- Motor, cerebellar, or brainstem involvement
- Male sex
- Smoking
- Poor compliance with treatment

**Protective Factors:**
- Female sex
- Relapsing-remitting course
- Long remission periods
- Good recovery from relapses
- No disability after 5 years
- Compliance with disease-modifying therapy
- Healthy lifestyle (no smoking, regular exercise)

#### 1c. Classification of Severity

| Severity         | Expanded Disability Status Scale (EDSS) | Description                                  |
|------------------|-----------------------------------------|----------------------------------------------|
| Mild             | 0–2.5                                   | Minimal symptoms, fully ambulatory           |
| Moderate         | 3–4.5                                   | Some disability, ambulatory without aid      |
| Severe           | 5–6.5                                   | Significant disability, may need assistance  |
| Extreme          | 7+                                      | Wheelchair or bed-bound                      |

#### 1d. Diagnostic Tests

- MRI brain and spinal cord (lesions, progression)
- Lumbar puncture (oligoclonal bands)
- Evoked potentials (visual, sensory)
- Neurological examination (EDSS scoring)
- Blood tests (to rule out other causes)

#### 1e. Treatments

- **Disease-modifying therapies:** interferon beta, glatiramer acetate, fingolimod, natalizumab, ocrelizumab, dimethyl fumarate
- **Acute relapse:** corticosteroids (methylprednisolone)
- **Symptom management:** baclofen, tizanidine (spasticity), modafinil (fatigue), antidepressants
- **Physical and occupational therapy**
- **Stem cell transplant** (select cases)

---

### 2. Underwriting Focus

- Age at onset and current age
- Disease course (relapsing-remitting, primary/secondary progressive)
- Frequency and severity of relapses
- EDSS or functional status
- MRI findings (number and progression of lesions)
- Treatment compliance and response
- Presence of cognitive, bowel/bladder, or brainstem involvement
- Smoking and other comorbidities
- Duration since diagnosis and since last relapse

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent neurologist report  | Diagnosis, course, EDSS, MRI findings    |
| MRI brain/spine            | Within last 2 years                      |
| Medication list            | Current and past 12 months               |
| Functional assessment      | EDSS or equivalent                       |
| Cognitive assessment       | If cognitive symptoms present            |
| Psychiatric evaluation     | If depression or suicidal risk           |

---

### 4. Rating

#### Clinically Isolated Syndrome (CIS)
*Includes optic neuritis, first episode only*

| Time Since Episode | MRI/Neuro Findings           | Life   | WP      | ADB     | LTC     |
|--------------------|-----------------------------|--------|---------|---------|---------|
| 0–1 year           | Negative MRI, no deficits   | +70    | Decline | N/A     | Decline |
| 1–2 years          | Negative MRI, no deficits   | +10    | Decline | N/A     | Decline |
| >2 years           | Negative MRI, no deficits   | +0     | Decline | N/A     | Decline |
| 0–1 year           | Equivocal MRI, no deficits  | +120   | Decline | N/A     | Decline |
| 1–2 years          | Equivocal MRI, no deficits  | +70    | Decline | N/A     | Decline |
| >2 years           | Equivocal MRI, no deficits  | +10    | Decline | N/A     | Decline |
| Any time           | Positive MRI or deficits    | Rate as MS Relapsing-Remitting |

#### Relapsing-Remitting MS (Diagnosis Established)

| Severity (EDSS) | Time Since Onset | Life   | WP      | ADB     | LTC     |
|-----------------|------------------|--------|---------|---------|---------|
| Mild (0–2)      | 0–1 year         | Postpone| Decline | N/A     | Decline |
|                 | 1–2 years        | +120   | Decline | N/A     | Decline |
|                 | >2–5 years       | +90    | Decline | N/A     | Decline |
|                 | >5 years         | +60    | Decline | N/A     | Decline |
| Moderate (3–4)  | 0–1 year         | Postpone| Decline | N/A     | Decline |
|                 | 1–2 years        | Postpone| Decline | N/A     | Decline |
|                 | >2–5 years       | +180   | Decline | N/A     | Decline |
|                 | >5 years         | +120   | Decline | N/A     | Decline |
| Severe (5–6)    | 0–2 years        | Decline | Postpone| N/A     | Decline |
|                 | >2–5 years       | Postpone| Decline | N/A     | Decline |
|                 | >5 years         | +300   | Decline | N/A     | Decline |
| Extreme (7+)    | Any time         | Decline | Decline | N/A     | Decline |

*If no progression for 10+ years and stable MRI: Credit -60 to -120.*

#### Primary or Secondary Progressive MS

| Severity (EDSS) | Time Since Onset | Life   | WP      | ADB     | LTC     |
|-----------------|------------------|--------|---------|---------|---------|
| Mild (0–2)      | 0–2 years        | Postpone| Decline | N/A     | Decline |
|                 | >2 years         | +220   | Decline | N/A     | Decline |
| Moderate (3–4)  | 0–2 years        | Postpone| Decline | N/A     | Decline |
|                 | >2 years         | +340   | Decline | N/A     | Decline |
| Severe/Extreme  | Any time         | Decline | Decline | N/A     | Decline |

#### Other MS Variants

| Variant                        | Life   | WP      | ADB     | LTC     |
|--------------------------------|--------|---------|---------|---------|
| Devic disease                  | IC     | IC      | IC      | IC      |
| Marburg variant                | IC     | IC      | IC      | IC      |
| Schilder disease               | IC     | IC      | IC      | IC      |
| Balo concentric sclerosis      | IC     | IC      | IC      | IC      |
| Myelitis                       | IC     | IC      | IC      | IC      |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Condition/Factor                        | Adjustment      |
|-----------------------------------------|-----------------|
| Bowel or bladder involvement            | Decline         |
| Brainstem involvement                   | Decline         |
| Cognitive deficits or dementia          | Decline         |
| Renal insufficiency                     | Decline         |
| Severe disability with frequent infections | Decline      |
| Rapidly progressive disease             | Decline         |
| Depression                              | IC, usually +40 |
| Smoking                                 | Consider +30    |
| Suicidal ideation or gestures           | Decline         |
| Alcohol or drug abuse                   | Decline         |
| Significant medication side effects     | IC              |
| Stem cell transplant                    | IC              |

#### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| No progression for 10+ years, stable MRI  | -60 to -120 |
| Excellent compliance, no relapses         | -30         |
| No disability after 5 years               | -30         |

---

**Legend:**
- IC = Individual Consideration
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- Std = Standard
- N/A = Not Applicable

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
