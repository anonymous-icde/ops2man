# Bipolar Disorder  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Bipolar Disorder is a chronic psychiatric condition characterized by recurrent episodes of mania/hypomania and depression, leading to significant impairment in functioning.

**Typical Signs and Symptoms:**
- Periods of elevated or irritable mood, increased energy, decreased need for sleep (mania/hypomania)
- Periods of depressed mood, loss of interest, fatigue, and suicidal ideation (depression)
- Impulsivity, poor judgment, and risky behaviors during manic episodes
- Psychotic symptoms in severe cases

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Early age of onset
- Frequent or severe episodes
- Poor compliance with treatment
- Substance abuse
- Family history of mood disorders
- History of suicide attempts
- Presence of psychotic symptoms

**Protective Factors:**
- Good compliance with medications and follow-up
- Stable mood for several years
- Strong social support
- Absence of substance abuse
- Regular employment and stable relationships

#### 1c. Classification of Severity

| Severity Level | Criteria (DSM-5)                                                                       |
|----------------|-------------------------------------------------------------------------------------------|
| Mild           | Bipolar II or cyclothymic disorder, infrequent episodes, minimal functional impairment     |
| Moderate       | Bipolar I, moderate frequency/severity, some functional impairment                         |
| Severe         | Bipolar I, frequent/severe episodes, marked impairment, psychosis, or suicide risk         |

#### 1d. Diagnostic Tests

- Clinical interview and mental status examination
- Standardized rating scales (e.g., Young Mania Rating Scale, Mood Disorder Questionnaire)
- Screening for comorbid psychiatric and substance use disorders
- No specific laboratory or imaging tests unless indicated

#### 1e. Treatments

- **Medications:** Mood stabilizers (lithium, valproate, lamotrigine), antipsychotics (quetiapine, olanzapine), antidepressants (with caution)
- **Psychotherapy:** Cognitive Behavioral Therapy (CBT), psychoeducation
- **Lifestyle:** Sleep hygiene, stress management
- **Other:** Hospitalization for severe episodes, ECT for refractory cases

---

### 2. Underwriting Focus

- Severity and frequency of episodes
- Duration of stability and compliance with treatment
- Functional impairment (work, social, daily activities)
- History of hospitalizations or suicide attempts
- Presence of psychotic symptoms
- Substance abuse or other psychiatric comorbidities
- Age at onset and current age

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, compliance      |
| Mental health questionnaire   | Symptom severity, functional impact   |
| Medication list               | Current and past 12 months            |
| Hospitalization history       | Last 10 years                         |
| Screening for comorbidities   | Substance use, psychosis, other mood disorders |

---

### 4. Rating

#### Bipolar and Cyclothymic Disorder – Synthetic Data (Revised)

**Mild (usually Bipolar II, includes Cyclothymic Disorder, stable, compliant with therapy)**

| Age Group   | 0–1 years | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | +150      | +75      |
| 21–39       | Postpone  | +75       | +50       | Std      |
| 40–69       | Postpone  | +50       | Std       | Std      |
| 70+         | Postpone  | Std       | Std       | Std      |

- Recurrent mild exacerbations: No additional debit (rate from last exacerbation)

**Moderate (usually Bipolar I, stable, compliant with therapy)**

| Age Group   | 0–1 years | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | Postpone  | +120     |
| 21–39       | Postpone  | +120      | +75       | +50      |
| 40–69       | Postpone  | +75       | +50       | Std      |
| 70+         | Postpone  | +50       | Std       | Std      |

- Recurrent mild exacerbations: No additional debit
- Recurrent moderate exacerbations: Postpone 1 year from last exacerbation, consider adding +25

**Severe (usually Bipolar I, stable, compliant with therapy)**

| Age Group   | 0–1 years | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | Postpone  | +200     |
| 21–39       | Postpone  | Postpone  | +120      | +75      |
| 40–69       | Postpone  | Postpone  | +75       | +50      |
| 70+         | Postpone  | Postpone  | +50       | Std      |

- Recurrent mild exacerbations: No additional debit
- Recurrent moderate exacerbations: Postpone 2 years from last exacerbation, consider adding +50
- Recurrent severe exacerbations: Decline


#### WP and ADB

| LIFE         | WP      | ADB    |
|--------------|---------|--------|
| Std          | Std     | Std    |
| +25 to +50   | Decline | 1.5x   |
| >+50         | Decline | Decline|

#### LTC

| LIFE Rating (Mild, Std to +50, stable ≥12 months) | LIFE Rating (min +25) |
|---------------------------------------------------|----------------------|
| Moderate, Std to +50, stable ≥2 years             | LIFE Rating          |
| Not stable for minimum periods above              | Decline              |
| >+50                                              | Decline              |
| Any of the following: New onset/severe, hospitalization, disabling, >3 meds, non-compliance, psychosis, suicide attempt | Decline |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Revised)

| Condition/Factor                        | Rating Adjustment         |
|-----------------------------------------|--------------------------|
| Substance abuse (current)               | Decline                  |
| Substance abuse (within 2 years)        | Postpone                 |
| Substance abuse (2–5 years)             | Add +75 to +25           |
| Substance abuse (>5 years)              | Add +10 to Std           |
| Anxiety (mild/moderate/severe)          | Std / Std / Postpone or +25|
| Antisocial personality                  | Decline                  |
| Associated eating disorder              | IC                       |
| Associated chronic debilitating disorder| IC, rate for cause       |
| Associated dementia                     | Decline                  |
| History of suicide ideation/attempt     | See Suicide section      |

#### 5b. Credits for Protective Factors (Revised)

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -15         |
| Stable employment and relationships      | -15         |
| Stable >10 years without serious complications | -25    |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes
