# Chronic Obstructive Pulmonary Disease (COPD)  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Chronic Obstructive Pulmonary Disease (COPD) is a progressive, irreversible lung disease characterized by airflow limitation, usually caused by chronic bronchitis and/or emphysema.

**Typical Signs and Symptoms:**
- Chronic cough
- Sputum production
- Shortness of breath (dyspnea), especially on exertion
- Wheezing
- Frequent respiratory infections
- Fatigue
- Cyanosis (in advanced cases)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Smoking (current or former)
- Advanced age
- Frequent exacerbations
- Low FEV1% predicted
- Continued exposure to lung irritants (e.g., occupational dust, pollution)
- Poor medication compliance
- Comorbidities (heart disease, diabetes, etc.)
- History of hospitalizations for COPD

**Protective Factors:**
- Smoking cessation
- Good compliance with medications and follow-up
- Regular exercise and pulmonary rehabilitation
- Vaccinations (influenza, pneumococcal)
- Early detection and management of exacerbations
- Healthy weight and nutrition

#### 1c. Classification of Severity

**GOLD Criteria (Global Initiative for Chronic Obstructive Lung Disease):**

| GOLD Grade      | FEV1 % Predicted | Description           |
|-----------------|------------------|-----------------------|
| Mild (Grade A)  | ≥80%             | Minimal symptoms      |
| Moderate (B)    | 50–79%           | Some limitation       |
| Severe (C)      | 30–49%           | Marked limitation     |
| Very Severe (D) | <30%             | Severe limitation     |

*FEV1 = Forced Expiratory Volume in 1 second, post-bronchodilator*

#### 1d. Diagnostic Tests

- Spirometry (FEV1, FVC, FEV1/FVC ratio)
- Chest X-ray or CT scan
- Pulse oximetry and arterial blood gases (ABG)
- 6-minute walk test or exercise tolerance test
- Alpha-1 antitrypsin level (if early onset or family history)
- Sputum culture (if frequent infections)

#### 1e. Treatments

- **Bronchodilators:** albuterol, salmeterol, tiotropium
- **Inhaled corticosteroids:** fluticasone, budesonide
- **Combination inhalers:** fluticasone/salmeterol, budesonide/formoterol
- **Phosphodiesterase-4 inhibitors:** roflumilast
- **Oxygen therapy** (for hypoxemia)
- **Pulmonary rehabilitation**
- **Vaccinations:** influenza, pneumococcal
- **Smoking cessation support**
- **Surgical options:** lung volume reduction, transplant (severe cases)

---

### 2. Underwriting Focus

- Age at diagnosis and current age
- Smoking status (current, former, never)
- FEV1 % predicted and GOLD grade
- Frequency and severity of exacerbations/hospitalizations
- Oxygen use at home
- Comorbidities (heart failure, pulmonary hypertension, etc.)
- Medication compliance and follow-up
- Weight and nutritional status
- History of lung surgery or transplant

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent pulmonary function test (PFT) | FEV1, FVC, FEV1/FVC, within 1 year |
| Chest X-ray or CT scan     | Within 2 years                           |
| Smoking history            | Current and past                         |
| Medication list            | Current and past 12 months               |
| Oxygen use                 | Home oxygen, frequency                   |
| Hospitalization history    | Last 2 years                             |
| Comorbidity assessment     | Cardiac, metabolic, other lung diseases  |

---

### 4. Rating

#### COPD Rating Table (Synthetic, Revised)

| GOLD Severity & Classification | Sub-class | FEV1%      | Age <40      | Age 41–69      | Age 70+        |
|-------------------------------|-----------|------------|--------------|----------------|----------------|
| Mild: Grade A                 |           | >80%       | +0           | +0             | +0             |
| Moderate: Grade B             | I         | 70–79%     | +25          | +0             | +0             |
| Moderate: Grade B             | II        | 60–69%     | +60          | +25            | +0             |
| Moderate: Grade B             | III       | 50–59%     | IC           | +90            | +25            |
| Severe: Grade C               | I         | 40–49%     | Decline      | +160           | +110           |
| Severe: Grade C               | II        | 30–39%     | Decline      | Decline        | +160           |
| Very Severe: Grade D          |           | <30%       | Decline      | Decline        | Decline        |

**Other Factors:**
- Rapid deterioration of FEV1: May require Decline
- Continued tobacco use:
  - Mild & Moderate I, all ages, <1 pack/day: Add +30
  - Mild & Moderate I, all ages, >1 pack/day: Decline
  - Moderate II or worse, all ages, any tobacco: Decline

*Note: Ratings within ranges should be adjusted depending on age.*

#### LIFE, WP, ADB

| LIFE           | WP      | ADB      |
|----------------|---------|----------|
| +0             | +0      | +0       |
| +25 to +60     | Decline | 1.3x     |
| +90 to +110    | Decline | 1.7x     |
| >+110          | Decline | Decline  |

#### LTC

| Severity                | LTC Rating                |
|-------------------------|---------------------------|
| Mild: Grade A           | +0                        |
| Moderate: Grade B       | Follow LIFE Rating, STD   |
| Others                  | Decline                   |
| Smokers                 | Decline                   |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Synthetic, Revised)

| Condition/Factor                | Adjustment         |
|---------------------------------|--------------------|
| Steroid complications           | +30 up             |
| Alpha-1 Antitrypsin Deficiency  | See Alpha-1 section|
| Pulmonary Hypertension          | Decline            |
| Cor Pulmonale                   | Decline            |
| Home O2 use                     | Decline            |
| History of Lung Cancer (Mild)   | Sum debits         |
| History of Lung Cancer (Mod)    | IC                 |
| History of Lung Cancer (Severe) | Decline            |
| Congestive Heart Failure        | Decline            |
| Coronary Artery Disease (>50yr) | Sum debits         |
| Coronary Artery Disease (<50yr) | Decline            |
| OSA (Mild)                      | Sum debits         |
| OSA (Mod/Severe)                | Decline            |
| Recurrent Pulmonary Embolus     | Decline            |
| Non-compliance with therapy     | Decline            |
| Lung Volume Reduction Surgery   | Decline            |
| Lung Transplant                 | Decline            |
| Underweight (>15%)              | IC                 |
| Unexplained Weight Loss (>5lb/yr)| IC                |

#### 5b. Credits for Protective Factors (Synthetic, Revised)

| Protective Factor                                               | Credit      |
|-----------------------------------------------------------------|-------------|
| Negative exercise study (Stage III/>9 mins/>10 METS, or >6 METS if >70yr) | IC, reconsider severity |
| No progression over 5 years by PFTs (non-smoker only)           | -10         |
| Normal CXR or whole body CT within 2 years                      | -5          |

---

**Legend:**
- IC = Individual Consideration
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- STD = Standard
- Decline = Not eligible for coverage

---

**Note:**
All values and tables above are synthetic and
