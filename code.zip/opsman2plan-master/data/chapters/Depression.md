# Depression  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Depression is a mood disorder characterized by persistent feelings of sadness, hopelessness, and loss of interest or pleasure in most activities, often accompanied by physical and cognitive symptoms.

**Typical Signs and Symptoms:**
- Depressed mood most of the day, nearly every day
- Markedly diminished interest or pleasure in activities
- Significant weight loss or gain, or change in appetite
- Insomnia or hypersomnia
- Fatigue or loss of energy
- Feelings of worthlessness or excessive guilt
- Diminished ability to think or concentrate
- Recurrent thoughts of death or suicide

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Family history of depression or other mood disorders
- Previous depressive episodes
- Co-morbid psychiatric or medical conditions
- Substance or alcohol abuse
- Poor social support
- Non-compliance with treatment
- Recent stressful life events

**Protective Factors:**
- Good response to therapy
- Compliance with medications and follow-up
- Strong social support
- Absence of comorbid psychiatric or substance use disorders
- Stable employment and relationships

#### 1c. Classification of Severity

| Severity Level | Criteria (DSM-5)                                                                 |
|----------------|-------------------------------------------------------------------------------------------|
| Mild           | Few, if any, symptoms in excess of those required to make the diagnosis; minor functional impairment |
| Moderate       | Symptoms or functional impairment between mild and severe                                  |
| Severe         | Many symptoms in excess of those required to make the diagnosis, marked interference with functioning, possible psychotic features or suicidality |

#### 1d. Diagnostic Tests

- Clinical interview and mental status examination
- Standardized rating scales (e.g., PHQ-9, Hamilton Depression Rating Scale)
- Screening for comorbid psychiatric conditions
- No specific laboratory or imaging tests required unless indicated by history

#### 1e. Treatments

- **Medications:** SSRIs (sertraline, fluoxetine), SNRIs (venlafaxine, duloxetine), bupropion, mirtazapine, tricyclics
- **Psychotherapy:** Cognitive Behavioral Therapy (CBT), interpersonal therapy
- **Lifestyle:** Exercise, sleep hygiene, social engagement
- **Other:** Electroconvulsive therapy (ECT) for severe or refractory cases

---

### 2. Underwriting Focus

- Severity and duration of symptoms
- Functional impairment (work, social, daily activities)
- History of hospitalizations or suicide attempts
- Compliance with treatment and follow-up
- Presence of comorbid psychiatric or substance use disorders
- Stability of employment and relationships
- Age at onset and current age

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, compliance      |
| Mental health questionnaire   | Symptom severity, functional impact   |
| Medication list               | Current and past 12 months            |
| Hospitalization history       | Last 10 years                         |
| Screening for comorbidities   | Anxiety, substance use, other mood disorders |

---

### 4. Rating

#### Major Depression – Synthetic Data (Revised)

**Mild Major Depression (Stable, compliant with therapy)**

| Age Group   | 0–1 years | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | +80       | +40      |
| 21–39       | +60       | Std–+40   | Std       | Std      |
| 40–69       | Std–+30   | Std       | Std       | Std      |
| 70+         | +20–+40   | Std       | Std       | Std      |

**Moderate Major Depression (Stable, compliant with therapy)**

| Age Group   | 0–1 years | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | +120      | +80      |
| 21–39       | Postpone  | +80       | +60       | +40      |
| 40–69       | Postpone  | +60       | +40       | Std      |
| 70+         | Postpone  | +40       | Std       | Std      |

**Severe Major Depression (Stable, compliant with therapy)**

| Age Group   | 0–1 year  | 1–2 years | 2–5 years | >5 years |
|-------------|-----------|-----------|-----------|----------|
| <21         | Postpone  | Postpone  | Postpone  | +80      |
| 21–39       | Postpone  | Postpone  | +80       | +60      |
| 40–69       | Postpone  | Postpone  | +60       | +40      |
| 70+         | Postpone  | +60       | +40       | Std      |

**Recurrence:**
- Mild increase: No additional debit
- Moderate increase: Postpone 1 year from last exacerbation, then consider adding +20
- Severe increase: IC, consider Decline

**Any suicide ideation or attempt:**
- Add suicide rating in addition to depression rating (see Suicide section)

**Any hospitalization in past 10 years:**
- Consider adding +30

#### Depression Other Than Major Depression

| Diagnosis                                      | Rating Guidance                        |
|------------------------------------------------|----------------------------------------|
| Adjustment disorder with depressed mood/stress | Rate as Mild Major Depression, credit up to +30 if no major depression features |
| Atypical depression (mild/moderate/severe)     | Std / Std to +30 / Rate as Major Depression |
| Depression due to medical condition            | Rate as Major Depression plus rating for medical condition |
| Depression with catatonia/melancholic/psychotic features | Rate as Severe Major Depression |
| Disruptive mood dysregulation disorder         | IC                                     |
| Dysthymic disorder/persistent depressive disorder | Rate as Mild Major Depression         |
| Minor depression                              | Rate as Mild Major Depression, credit up to +30 |
| Premenstrual dysphoric disorder (controlled)   | Std                                    |
| Postpartum depression (mild/significant)       | Std/Postpone if <1 year since delivery; possibly Std if >1 year and resolved |
| Reactive depression                           | Rate as Major Depression               |
| Seasonal affective disorder (controlled)       | Std                                    |
| Vascular depression                           | IC, likely Decline                     |
| Other types (drug-induced, etc.)              | IC                                     |

#### WP, ADB, LTC

| Life Rating | WP   | ADB  | LTC  |
|-------------|------|------|------|
| Std         | Std  | Std  | Std  |
| >Std        | Decline | Decline | Decline |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Revised)

| Condition/Factor                        | Rating Adjustment         |
|-----------------------------------------|--------------------------|
| Alcohol abuse (current)                 | Decline                  |
| Alcohol abuse (within 2 years)          | Postpone                 |
| Alcohol abuse (2–5 years)               | Add +60 to +30           |
| Alcohol abuse (>5 years)                | Add +10 to Std           |
| Anxiety (mild/moderate/severe)          | Std / Std / Postpone or +30|
| Antisocial personality                  | Decline                  |
| Associated eating disorder              | IC                       |
| Associated chronic debilitating disorder| IC, rate for cause       |
| Associated dementia                     | Decline                  |
| Aviation                               | Consider excluding aviation|
| Bipolar disorder                        | See Bipolar section      |
| Coronary artery disease                 | See CAD section          |
| Cyclothymic disorder                    | See Bipolar section      |
| Depression age <18                      | IC                       |
| Diabetes                                | See Diabetes section     |
| Driving infractions, multiple           | Consider adding +30      |
| Gambling disorder (current/within 2 years/2–5 years/>5 years) | Decline/Postpone/+60 to +30/+10 to Std |
| Hazardous activity                      | Consider excluding activity if moderate/severe depression |
| Pregnant, history of postpartum depression | See Postpartum depression|
| Pregnant, currently treated for depression | IC                      |
| Substance abuse (current/within 2 years/2–5 years/>5 years) | Decline/Postpone/+30 to +60/Std to +10 |
| Suicide (any history)                   | See Suicide section      |

#### 5b. Credits for Protective Factors (Revised)

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -20         |
| Stable employment and relationships      | -20         |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
