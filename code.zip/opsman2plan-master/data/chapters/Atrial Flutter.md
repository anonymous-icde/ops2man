# Atrial Flutter  
## Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Atrial flutter is a type of supraventricular tachycardia characterized by a rapid, regular atrial rhythm, usually with a characteristic "sawtooth" pattern on ECG. It is closely related to atrial fibrillation but tends to be more organized.

**Typical Signs and Symptoms:**
- Palpitations
- Fatigue
- Shortness of breath
- Dizziness or lightheadedness
- Chest discomfort
- May be asymptomatic

### 1b. Risk and Protective Factors

**Risk Factors:**
- Underlying heart disease (especially valvular or ischemic)
- Hypertension
- Heart failure
- Advanced age
- Diabetes mellitus
- Obesity
- Hyperthyroidism
- Chronic lung disease
- Excessive alcohol use

**Protective Factors:**
- Good control of blood pressure and heart failure
- Anticoagulation when indicated
- Rate/rhythm control
- Compliance with medications
- Abstinence from alcohol
- Regular follow-up

### 1c. Classification of Severity

| Severity Type      | Description                                                                                  |
|--------------------|---------------------------------------------------------------------------------------------|
| Paroxysmal         | Self-terminating, episodes last <7 days, usually <24 hours                                  |
| Persistent         | Lasts >7 days, requires intervention to restore sinus rhythm                                 |
| Permanent          | Continuous, cannot be restored to sinus rhythm                                              |
| Lone Flutter       | Flutter in individuals <60 years, no structural heart disease or risk factors               |
| With underlying disease | Flutter with structural heart disease, heart failure, or other significant comorbidities|


### 1d. Diagnostic Tests

- 12-lead ECG
- Holter monitor or event recorder
- Echocardiogram
- Thyroid function tests
- Renal and liver function tests
- CBC, electrolytes
- Cardiac stress testing (if indicated)

### 1e. Treatments

- **Rate control:** Beta-blockers (metoprolol), calcium channel blockers (diltiazem), digoxin
- **Rhythm control:** Antiarrhythmics (amiodarone, flecainide), electrical cardioversion
- **Anticoagulation:** Warfarin, apixaban, rivaroxaban, dabigatran
- **Ablation:** Catheter ablation (often curative for typical flutter)
- **Lifestyle:** Weight loss, alcohol moderation, sleep apnea management
- **Treat underlying causes:** e.g., hyperthyroidism

---

## 2. Underwriting Focus

- Age at diagnosis and at application
- Type of flutter (paroxysmal, persistent, permanent)
- Frequency and duration of episodes
- Underlying heart or valvular disease
- Left ventricular function (EF)
- Presence of heart failure, CAD, or stroke/TIA
- Blood pressure and diabetes control
- Anticoagulation status and compliance
- Results of cardiac investigations (echo, stress test)
- Treatment history (medications, ablation)
- Smoking and alcohol use
- Other comorbidities (renal, pulmonary, hepatic)

---

## 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent ECG                 | Confirm diagnosis and rhythm             |
| Echocardiogram             | Assess structure and function            |
| Holter/Event monitor       | If paroxysmal or unclear diagnosis       |
| Cardiac stress test        | If CAD suspected or age >50              |
| Thyroid function           | Rule out hyperthyroidism                 |
| Lab tests                  | CBC, renal, liver, electrolytes          |
| Physician’s statement      | For all persistent/permanent or with comorbidities |

---

## 4. Rating

#### Atrial Flutter Rating Table (Synthetic Example)

| Scenario         | LIFE         | WP           | ADB          | LTC         |
|------------------|--------------|--------------|--------------|-------------|
| Atrial Flutter   | Rate as Atrial Fibrillation | Rate as Atrial Fibrillation | Rate as Atrial Fibrillation | Rate as Atrial Fibrillation |

*See Atrial Fibrillation chapter for detailed rating tables.*

---

## 5. Additional Considerations

### 5a. Co-morbid Conditions and Risk Factors

| Condition/Factor                | LIFE         | WP      | ADB     | LTC         |
|---------------------------------|-------------|---------|---------|-------------|
| Underlying cardiac disease      | Rate as Atrial Fibrillation, usually higher rating |
| Heart failure                   | Rate as Atrial Fibrillation, usually higher rating |
| Valvular disease                | Rate as Atrial Fibrillation, usually higher rating |
| Diabetes, hypertension, COPD    | Add debits as per Atrial Fibrillation chapter      |
| Alcohol abuse                   | Decline      | Decline | Decline | Decline     |

### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| Anticoagulation >6 months, compliant      | -25         |
| Well-controlled BP and lipids >2 years    | -25         |
| No symptoms, stable for >3 years          | -25         |
| Successful ablation, no recurrence >1 year| -25         |
| Non-smoker, healthy BMI                   | -25         |

---

**Legend:**
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- CAD = Coronary Artery Disease
- TIA = Transient Ischemic Attack
- COPD = Chronic Obstructive Pulmonary Disease

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
For detailed rating, refer to the Atrial
