# Underwriting Manual: Ulcerative Colitis

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Ulcerative colitis (UC) is a chronic inflammatory bowel disease (IBD) characterized by continuous inflammation of the mucosal lining of the colon and rectum. It presents with relapsing and remitting episodes.

**Typical Signs and Symptoms:**
- Chronic or recurrent diarrhea, often bloody
- Abdominal pain and cramping
- Urgency and tenesmus
- Fatigue
- Weight loss
- Extra-intestinal manifestations (arthritis, skin, ocular involvement)

---

### 1b. Risk Factors Affecting Prognosis and Protective Factors

**Risk Factors:**
- Early age at onset (<20 years)
- Extensive colonic involvement (pancolitis)
- Frequent or severe flares
- Poor response to first-line therapy
- Presence of extra-intestinal complications
- History of dysplasia or colorectal cancer
- Non-compliance with treatment
- Co-morbidities (e.g., liver disease, malnutrition)

**Protective Factors:**
- Onset after age 20
- Limited disease (proctitis or proctosigmoiditis)
- Long periods of remission
- Good response to first-line therapy
- Compliance with medication and regular follow-up
- Absence of extra-intestinal complications
- Regular colonoscopic surveillance

---

### 1c. Classification of Severity

Severity is classified based on clinical, laboratory, and endoscopic findings.

| Severity   | Clinical Features (Synthetic Data) |
|------------|------------------------------------|
| Mild       | <4 stools/day, mild bleeding, no systemic symptoms, normal ESR/CRP |
| Moderate   | 4–6 stools/day, moderate bleeding, mild systemic symptoms, mild anemia |
| Severe     | >6 stools/day, severe bleeding, fever, tachycardia, anemia, elevated ESR/CRP |
| Fulminant  | >10 stools/day, continuous bleeding, toxicity, need for hospitalization |

---

### 1d. Diagnostic Tests

- Colonoscopy with biopsy (gold standard for diagnosis and assessment of extent/severity)
- Fecal calprotectin (marker of intestinal inflammation)
- CBC (to assess anemia)
- CRP/ESR (inflammatory markers)
- Liver function tests (to assess for primary sclerosing cholangitis)
- Stool studies (to rule out infection)
- Imaging (CT/MRI) for complications or unclear diagnosis

---

### 1e. Treatments

**Mild Disease:**
- 5-aminosalicylic acid (5-ASA) agents (mesalamine, sulfasalazine)
- Topical steroids (rectal enemas)

**Moderate Disease:**
- Oral corticosteroids (prednisone)
- Immunomodulators (azathioprine, 6-mercaptopurine)
- Biologics (infliximab, adalimumab) for steroid-dependent cases

**Severe Disease:**
- IV corticosteroids
- Biologics (vedolizumab, ustekinumab)
- Hospitalization for supportive care

**Surgical:**
- Colectomy (curative for UC), with or without ileal pouch-anal anastomosis

---

## 2. Underwriting Focus

Underwriters should focus on:
- Extent and location of disease (proctitis, left-sided, pancolitis)
- Frequency and severity of flares
- Number of stools per day and presence of blood
- Weight loss and nutritional status
- Hospitalizations and surgeries
- Medication history and compliance
- Presence of complications (strictures, perforation, dysplasia, cancer)
- Extra-intestinal manifestations (arthritis, skin, ocular, liver)
- Surveillance colonoscopy and biopsy results
- Co-morbidities (e.g., liver disease, depression, malnutrition)

---

## 3. Requirements

- Recent colonoscopy report with biopsy (within 2 years)
- Physician’s statement detailing disease course, treatment, and compliance
- CBC, ESR/CRP, and liver function tests (within 6 months)
- Documentation of hospitalizations, surgeries, and complications
- Details of extra-intestinal manifestations
- Surveillance for dysplasia/cancer (if >10 years since diagnosis)

---

## 4. Rating

**Ulcerative Colitis Severity and Underwriting Rating Table**

| Severity  | Extent/Location         | Symptoms                | Stools/Day | Weight Loss      | Flares         | Hospitalization | Rating   |
|-----------|------------------------|-------------------------|------------|------------------|----------------|-----------------|----------|
| Mild      | Rectum/sigmoid, descending colon | None or minimal pain/bleeding | <5         | None            | Infrequent     | None           | +0 to +50|
| Moderate  | 1/3–1/2 transverse colon        | Occasional pain/bleeding      | >5         | 5–10%           | ≤4/year        | Occasional      | +75 to +100|
| Severe    | Pancolitis                      | Frequent pain/bleeding        | Profuse, liquid | 10–20%      | Continuous      | Frequent        | +150 or Decline|
| Fulminant    | Pancolitis with severe complications | Severe pain/bleeding    | Profuse, liquid, dehydration | >20% | Deteriorating | Current/pending surgery | Decline |

**Additional Rating Considerations by Age and Time Since Last Attack**

| Current Age | Last Attack 0–12 mo | Last Attack 12–24 mo | Last Attack 2–5 yrs | Last Attack >5 yrs |
|-------------|---------------------|----------------------|---------------------|--------------------|
| <20         | IC/Postpone         | +100                 | +75                 | +50                |
| 20–45       | +75 to +150         | +50 to +125          | +50 to +100         | Standard to +50    |
| >45         | +50 to +100         | Standard to +75      | Standard to +50     | +0                 |

**Surgical Treatment Ratings**

| Surgery Type                        | 0–6 mo | 6–12 mo | >12 mo         |
|-------------------------------------|--------|---------|---------------|
| Partial colectomy, no symptoms      | Postpone | IC      | Rate as mild  |
| Partial colectomy, with symptoms    | Postpone | IC      | Rate as moderate or higher |
| Complete colectomy with pouch       | Postpone | $5/mil x year | Standard/IC |
| Permanent ileostomy                 | Postpone | IC      | Standard/IC   |
| Strictureplasty, fistula            | Postpone | IC      | Rate as per severity chart |

**WP, ADB, and LTC Rider Ratings**

| LIFE Rating   | WP      | ADB     | LTC (if LIFE > +100) |
|---------------|---------|---------|----------------------|
| <+50          | 1.5x    | 1.5x    | Standard             |
| +50 to +75    | 2x      | 2x      | LIFE Rating          |
| +100          | 2x      | 2x      | Decline              |
| >+100         | Decline | Decline | Decline              |

---

## 5. Additional Considerations

### 5a. Co-morbid Conditions and Risk Factor-Based Table

| Co-morbid Condition         | Rating Adjustment      |
|----------------------------|-----------------------|
| Alcohol abuse              | Decline               |
| Amyloidosis                | Decline               |
| Anemia                     | See severity chart    |
| Arthritis                  | LIFE = +0, WP/LTC = Decline |
| Chronic Active Hepatitis   | Decline (biopsy proven), IC (not proven) |
| Depression                 | Add debits per severity |
| Elevated CEA               | IC                    |
| Fulminant colitis          | Postpone x 2 years, then rate as severe |
| High grade dysplasia       | Postpone              |
| Inadequate surveillance    | Decline               |
| LFTs >2x normal            | IC, usually decline   |
| Low serum albumin (<3 mg)  | IC                    |
| Ocular lesions             | LIFE = +0, WP/LTC = Decline |
| Parenteral alimentation    | Decline               |
| Sclerosing cholangitis     | Decline               |
| Skin lesions               | LIFE = +0, WP/LTC = Standard |
| Surgery pending            | Postpone              |
| Underweight (5–10%)        | Rate as moderate      |
| Underweight (10–20%)       | Rate as severe        |
| Underweight (>20%)         | Decline               |

### 5b. Credits for Protective Factors

| Protective Factor                  | Credit Applied |
|------------------------------------|---------------|
| Excellent compliance               | -25           |
| Long remission (>2 years)          | -25           |
| No extra-intestinal complications  | -25           |
| Regular colonoscopic surveillance  | -50           |
| Onset after age 20                 | -25           |

---

**Note to Underwriters:**
Always classify severity based on symptoms and signs, not solely on treatment. Consider all risk and protective factors, and apply credits/debits as indicated. For applicants with long-standing disease, ensure adequate cancer
