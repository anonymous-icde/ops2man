# Atrial Fibrillation – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Atrial fibrillation (AF) is a common cardiac arrhythmia characterized by rapid, irregular beating of the atria. It may be paroxysmal (intermittent), persistent, or permanent.

**Typical Signs and Symptoms:**  
- Palpitations
- Fatigue
- Shortness of breath
- Dizziness or lightheadedness
- Chest discomfort
- May be asymptomatic

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Older age
- Hypertension
- Heart failure
- Valvular heart disease
- Coronary artery disease
- Diabetes mellitus
- Obesity
- Sleep apnea
- Chronic kidney disease
- Excessive alcohol use
- Hyperthyroidism

**Protective Factors:**  
- Good control of blood pressure and diabetes
- Maintenance of sinus rhythm
- Use of anticoagulation when indicated
- Healthy weight and regular exercise
- Abstinence from alcohol and smoking
- Compliance with medications and follow-up

---

### 1c. Classification of Severity

**Severity is classified by:**
- Frequency and duration of episodes (paroxysmal, persistent, permanent)
- Presence of symptoms
- Underlying cardiac or systemic disease
- Risk of stroke (CHA₂DS₂-VASc score)
- Left ventricular function

---

### 1d. Diagnostic Tests

- **Electrocardiogram (ECG):** Confirms diagnosis
- **Holter monitor or event recorder:** Detects paroxysmal AF
- **Echocardiogram:** Assesses cardiac structure and function
- **Thyroid function tests:** Rules out hyperthyroidism
- **Renal and liver function tests**
- **Sleep study:** If sleep apnea suspected

---

### 1e. Treatments

- **Rate control:** Beta-blockers (metoprolol), calcium channel blockers (diltiazem), digoxin
- **Rhythm control:** Antiarrhythmics (flecainide, amiodarone), electrical cardioversion, catheter ablation
- **Anticoagulation:** Warfarin, DOACs (apixaban, rivaroxaban, dabigatran)
- **Treatment of underlying conditions:** Hypertension, heart failure, thyroid disease
- **Lifestyle modification:** Weight loss, exercise, alcohol reduction

---

## 2. Underwriting Focus

- Age at diagnosis and at application
- Frequency and duration of AF episodes
- Presence and control of symptoms
- Underlying heart or systemic disease
- Results of cardiac investigations (ECG, echo, stress test)
- Use and duration of anticoagulation
- Control of risk factors (BP, diabetes, sleep apnea)
- Compliance with treatment and follow-up
- History of stroke, TIA, or embolic events

---

## 3. Requirements

- Attending physician statement (APS) with details of diagnosis, treatment, and follow-up
- Recent ECG and echocardiogram reports
- Holter monitor or event recorder results (if available)
- Cardiac investigations (stress test, perfusion study, catheterization if indicated)
- Laboratory results (renal, liver, thyroid function)
- Details of anticoagulation and medication compliance

---

## 4. Rating

**Atrial flutter is underwritten in the same way as atrial fibrillation, but underlying cardiac disease is more common in atrial flutter. "Lone" atrial flutter is uncommon.** Only one of the following scenario/conditions are applicable.

| Scenario/Condition                                                                 | LIFE      | WP      | ADB     | LTC         |
|------------------------------------------------------------------------------------|-----------|---------|---------|-------------|
| Newly discovered on insurance exam or EKG                                          | Postpone for investigations | Postpone | Postpone | Postpone    |
| Single/multiple episodes due to acute illness (e.g., hyperthyroidism), resolved    | Rate for cause              | Rate for cause | Rate for cause | Rate for cause |
| Single/multiple episodes due to acute illness, not resolved                        | Rate for cause + Chronic AF rating | Rate for cause + Chronic AF rating | Rate for cause + Chronic AF rating | Rate for cause + Chronic AF rating |
| Paroxysmal AF, fully investigated, <4 short attacks/year, no underlying disease    | +10       | +0      | +0      | +0          |
| Paroxysmal AF, fully investigated, >4 short attacks/year, no underlying disease    | +65       | 1.6x    | 1.6x    | LIFE Ratings|
| Paroxysmal AF, uninvestigated, <4 attacks/year, age <60                            | IC        | IC      | IC      | IC          |
| Paroxysmal AF, uninvestigated, <4 attacks/year, age ≥60                            | +70       | 1.6x    | 1.6x    | LIFE Ratings|
| Paroxysmal AF, uninvestigated, >4 attacks/year                                     | Postpone for investigations | Postpone | Postpone | Postpone    |
| Anticoagulant use <6 months                                                        | +0        | +0      | +0      | LIFE Rating |
| Anticoagulant use >6 months                                                        | Credit -28 | +0      | +0      | LIFE Rating |
| Chronic AF, fully investigated, age <60                                            | +120 (min +90*) | 2.1x    | 2.1x    | LIFE Rating |
| Chronic AF, fully investigated, age 60-85                                          | +85 (min +65*) | 2.1x    | 2.1x    | LIFE Rating |
| Chronic AF, fully investigated, age >85                                            | +65 (min +35*) | Decline | Decline | LIFE Rating |
| Chronic AF, uninvestigated, age <60                                                | Postpone  | Postpone| Postpone| Postpone    |
| Chronic AF, uninvestigated, age >60, AF <2 years                                   | Postpone  | Postpone| Postpone| Postpone    |
| Chronic AF, uninvestigated, age >60, AF >2 years                                   | +120      | Decline | Decline | Decline     |
| Treated with ablation, 0-6 months                                                  | Rate as without ablation    | Rate as without ablation | Rate as without ablation | Rate as without ablation |
| Treated with ablation, >6 months                                                   | +0        | +0      | +0      | LIFE Rating |

*Consider reducing rating if AF is present and controlled >3 years.

---

## 5. Additional Considerations

| Condition/Factor                        | LIFE      | WP      | ADB     | LTC         |
|-----------------------------------------|-----------|---------|---------|-------------|
| Alcohol abuse, currently drinking       | Decline   | Decline | Decline | Decline     |
| Alcohol abuse, abstinent ≥2 years       | Add to AF rating | 1.6x up | 1.6x up | LIFE Rating up to +85, otherwise Decline |
| Blood pressure +0 to +65                | Sum Debits| 1.6x up | 1.6x up | LIFE Rating up to +85, otherwise Decline |
| Blood pressure +65 to +120              | IC, add +65 | Decline | Decline | Decline     |
| Blood pressure >+120                    | Decline   | Decline | Decline | Decline     |
| Build rating +0 to +120                 | Sum Rating| LIFE Rating up to +85, otherwise Decline | LIFE Rating up to +85, otherwise Decline | LIFE Rating up to +85, otherwise Decline |
| Build rating >+120                      | IC/Decline| Decline | Decline | Decline     |
| Cardiomyopathy, current                 | Postpone  | Postpone| Postpone| Decline     |
| Cardiomyopathy, resolved                | Rate as above | Rate as above | Rate as above | Rate as above |
| Chronic renal failure                   | Decline   | Decline | Decline | Decline     |
| Coagulation disorder                    | IC        | IC      | IC      | IC          |
| Congestive heart failure                | Decline   | Decline | Decline | Decline     |
| COPD, mild                              | +0        | 1.6x up | 1.6x up | LIFE Rating up to +85, otherwise Decline |
| COPD, moderate                          | Add +65   | Decline | Decline | Decline     |
| COPD, severe                            | Decline   | Decline | Decline | Decline     |
| Coronary artery disease                 | See CAD section | Decline | Decline | Decline  |
| Diabetes, fully investigated, PAF       | No additional rating | No additional rating | No additional rating | No additional rating |
| Diabetes, fully investigated, CAF       | Sum debits | Decline | Decline | LIFE Rating up to +85, otherwise Decline |
| Diabetes, uninvestigated                | Postpone for investigations | Postpone | Postpone | Postpone    |
| Echocardiogram, abnormal                | See Echo section | See Echo section | See Echo section | See Echo section |
| GI bleed, history of                    | IC        | IC      | IC      | IC          |
| Heart rate >100 at rest                 | IC        | IC      | IC      | IC          |
| Ischemic stroke, history of             | See Stroke section | Decline | Decline | Decline |
| Pacemaker, CAD complication             | Decline   | Decline | Decline | Decline     |
| Pacemaker, other                        | See Pacemaker section | See Pacemaker section | See Pacemaker section | See Pacemaker section |
| PAD, CAD ruled out                      | See PAD section | Decline | Decline | Decline  |
| PAD, CAD not investigated               | Postpone for investigations | Decline | Decline | Decline     |
| TIA, history of                         | See Stroke section | Decline | Decline | Decline |
| TST positive                            | Postpone for cardiac investigations | Decline | Decline | Decline |
| WPW syndrome, treated with ablation     | Rate as ablation above | Rate as ablation above | Rate as ablation above | Rate as ablation above |
| WPW syndrome, others                    | Rate as PAF or CAF | Rate as PAF or CAF | Rate as PAF or CAF | Rate as PAF or CAF |
| Ventricular tachycardia                 | Decline   | Decline | Decline | Decline     |

---

**Note:**  
All values and tables above are synthetic, further altered, and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.
