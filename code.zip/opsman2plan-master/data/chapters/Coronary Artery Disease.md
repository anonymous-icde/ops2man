# Coronary Artery Disease (CAD) – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Coronary artery disease (CAD) is a condition where the coronary arteries supplying blood to the heart muscle become narrowed or blocked due to atherosclerosis (plaque buildup). This can lead to reduced blood flow, chest pain (angina), heart attacks (myocardial infarction), and other complications.

**Typical Signs and Symptoms:**  
- Chest pain or discomfort (angina)
- Shortness of breath
- Fatigue with exertion
- Palpitations or irregular heartbeat
- Heart attack (acute chest pain, sweating, nausea)

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Age (older age increases risk)
- Male sex
- Family history of CAD
- Smoking
- Hypertension
- Diabetes mellitus
- High cholesterol (LDL)
- Obesity and sedentary lifestyle
- Poor diet
- Excessive alcohol use

**Protective Factors:**  
- Smoking cessation
- Good control of blood pressure, cholesterol, and diabetes
- Regular exercise and healthy diet
- Compliance with prescribed medications (e.g., statins, antiplatelets)
- Cardiac rehabilitation and regular follow-up

---

### 1c. Classification of Severity


- **Group 1:** Single vessel or no MI or normal EF
- **Group 2:** Two vessel or prior MI or mild LV dysfunction
- **Group 3:** Three vessel or left main or recurrent MI or significant LV dysfunction
- **Group 4:** Severe or unstable or uninsurable

Important Note: number of stents typically correspond to number of vessels.

---

### 1d. Diagnostic Tests

- Electrocardiogram (ECG)
- Exercise stress test
- Echocardiogram (assess ejection fraction)
- Cardiac catheterization/angiography
- CT coronary angiogram
- Blood tests (lipid profile, troponin, BNP)

---

### 1e. Treatments

- **Medications:** Statins, beta-blockers, ACE inhibitors, antiplatelets (aspirin, clopidogrel), nitrates
- **Procedures:** Percutaneous coronary intervention (PCI/angioplasty), coronary artery bypass grafting (CABG)
- **Lifestyle:** Diet, exercise, smoking cessation
- **Cardiac rehabilitation**

---

## 2. Underwriting Focus

Underwriters should focus on the following factors:
- Number of vessels involved and location of disease
- History and timing of myocardial infarction or revascularization
- Left ventricular function (ejection fraction)
- Current symptoms and functional status (NYHA class, CCS angina class)
- Control of risk factors (BP, cholesterol, diabetes, smoking)
- Compliance with treatment and follow-up
- Presence of complications (arrhythmia, heart failure, other vascular disease)

---

## 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, complications, control |
| Cardiac investigations        | ECG, stress test, echo, cath/angiogram |
| Recent lipid profile, LFTs    | Within last 12 months                  |
| Smoking and alcohol history   | Required                               |
| Details of procedures (PCI/CABG) | Type, date, outcome                |

---

## 4. Rating

### Human Readable Rating Table (Synthetic Example)

#### Rapid CAD Rating Table

| Age at Application | Group 1 | Group 2 | Group 3 | Group 4 |
|--------------------|---------|---------|---------|---------|
| <35                | IC      | Decline | Decline | Decline |
| 36-39              | +150    | +200    | Decline | Decline |
| 40-45              | +100    | +150    | +200    | Decline |
| 46-49              | +75     | +125    | +150    | Decline |
| 50-69              | +50     | +100    | +125    | Decline |
| 70-79              | +0      | +50     | +100    | Decline |
| 80+                | +0      | +0      | +50     | Decline |

- **Group 1:** Single vessel or no MI or normal EF
- **Group 2:** Two vessel or prior MI or mild LV dysfunction
- **Group 3:** Three vessel or left main or recurrent MI or significant LV dysfunction
- **Group 4:** Severe or unstable or uninsurable

Note: number of stents typically correspond to number of vessels.

#### Age of Onset Debit (Ages 50-69 at Application)

| Age of Onset | Additional Debit |
|--------------|-----------------|
| 36-39        | +75             |
| 40-45        | +50             |
| 46-49        | +25             |
| > 50          | No additional   |

#### Smoking Debits

| Smoking Status         | Age 36-49 | Age 50-69 | Age 70-79 | Age 80+ |
|-----------------------|-----------|-----------|-----------|---------|
| <1 pack/day           | Decline   | +50-100   | +25-50    | +0-25   |
| >1 pack/day           | Decline   | Decline   | Decline   | Decline |

---

## 5. Additional Considerations

### a) Co-morbid Conditions and Risk Factors

| Co-morbid Condition         | Rating Adjustment      |
|----------------------------|-----------------------|
| Mild PAD                    | Add +50 (IC)          |
| Moderate/Severe PAD/Smoker  | Decline               |
| Type 2 DM (age >55, non-smoker, good control) | +50 minimum |
| Type 1 DM                   | Usually decline (IC)  |
| CHF                         | Decline               |
| Moderate/Severe COPD        | Decline               |
| Chronic renal failure (eGFR 30-49) | +50           |
| Chronic renal failure (eGFR <30)   | Decline       |
| Moderate depression         | +50                   |
| Severe depression           | Decline               |
| Sleep Apnea                 | IC                     |

### b) Credits for Protective Factors

| Protective Factor                                  | Credit  |
|----------------------------------------------------|---------|
| BP/Lipids within range (2 years)                   | -15     |
| Negative exercise study (last 2 years, >10 METS)   | -25     |
| No disease progression (5 years)                   | -25     |
| Pro-BNP normal (last 12 months)                    | -10     |
| Use of 2+ cardiac medications                      | -10     |
| 4+ healthy lifestyle criteria                      | -15     |

---

**Note:**  
All values and tables above are synthetic and for
