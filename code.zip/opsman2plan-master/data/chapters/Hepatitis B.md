# Hepatitis B
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Hepatitis B is a viral infection of the liver caused by the hepatitis B virus (HBV). It can present as an acute or chronic infection and may lead to liver inflammation, fibrosis, cirrhosis, or hepatocellular carcinoma.

**Typical Signs and Symptoms:**
- Acute: Fatigue, jaundice, dark urine, abdominal pain, nausea, vomiting, loss of appetite, joint pain
- Chronic: Often asymptomatic, but may progress to liver dysfunction, cirrhosis, or liver cancer

#### 1b. Risk and Protective Factors

**Risk Factors:**
- High viral load (HBV DNA)
- Positive HBeAg
- Abnormal liver function tests (LFTs)
- Co-infection with HCV, HDV, or HIV
- Excessive alcohol use
- Family history of liver cancer
- Male sex, older age, long duration of infection

**Protective Factors:**
- Effective antiviral therapy
- Sustained normal LFTs
- Negative HBeAg and low/undetectable HBV DNA
- No evidence of fibrosis or cirrhosis
- Compliance with follow-up and treatment
- Vaccination (for prevention)

#### 1c. Classification of Severity

| Severity Level | Criteria (US/Canadian Guidelines Reference)                                                                 |
|----------------|------------------------------------------------------------------------------------------------------------|
| Inactive Carrier | HBsAg positive, HBeAg negative, normal LFTs, low/undetectable HBV DNA, no fibrosis                       |
| Mild Chronic    | HBsAg positive, mild LFT elevation, low HBV DNA, minimal fibrosis                                         |
| Moderate Chronic| HBsAg positive, moderate LFT elevation, moderate HBV DNA, moderate fibrosis                               |
| Severe Chronic  | HBsAg positive, high LFTs, high HBV DNA, advanced fibrosis/cirrhosis, or hepatocellular carcinoma         |

*References: AASLD, Canadian Liver Foundation, METAVIR, Ludwig, Knodell scoring systems for biopsy*

#### 1d. Diagnostic Tests

- Hepatitis B surface antigen (HBsAg), e-antigen (HBeAg), and antibodies
- HBV DNA viral load
- Liver function tests (ALT, AST, GGT, bilirubin, albumin, alkaline phosphatase)
- Alpha-fetoprotein (AFP)
- Abdominal ultrasound or CT (for cirrhosis/mass)
- Liver biopsy (for fibrosis/inflammation grading)

#### 1e. Treatments

- **Antiviral medications:** entecavir, tenofovir, lamivudine, adefovir, telbivudine
- **Interferon therapy:** pegylated interferon alfa-2a
- **Supportive care:** monitoring, lifestyle modification (avoid alcohol)
- **Liver transplant:** for end-stage liver disease
- **Vaccination:** for prevention (not treatment)

---

### 2. Underwriting Focus

- Duration and phase of infection (acute vs. chronic)
- LFT trends and HBV DNA levels
- HBeAg status
- Biopsy findings (if available)
- Evidence of cirrhosis, fibrosis, or hepatocellular carcinoma
- Co-infections (HCV, HDV, HIV)
- Alcohol use
- Compliance with treatment and follow-up

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, compliance      |
| LFTs (ALT, AST, GGT, bilirubin, albumin) | Last 6–12 months         |
| HBV serology (HBsAg, HBeAg, anti-HBe)    | Required                  |
| HBV DNA viral load         | Required                                 |
| Liver biopsy report        | If available, for fibrosis/inflammation  |
| Imaging (ultrasound/CT)    | If cirrhosis or mass suspected           |
| Alpha-fetoprotein (AFP)    | For cancer screening                     |
| Screening for co-infections| HCV, HDV, HIV                            |

---

### 4. Rating

#### Acute Infection

| Time Since Diagnosis | LIFE      | WP        | ADB       | LTC       |
|---------------------|-----------|-----------|-----------|-----------|
| 0–6 months          | Postpone  | Postpone  | Postpone  | Decline   |
| >6 months           |           |           |           |           |
| HBsAg negative, LFTs normal | Std | Std | Std | Std |
| HBsAg negative, LFTs abnormal | Rate for LFTs | Decline | Decline | Decline |
| Unknown/Unavailable serology, LFTs normal | Std | Std | Std | Std |
| Unknown/Unavailable serology, LFTs abnormal | Rate as Chronic HBV | Rate as Chronic HBV | Rate as Chronic HBV | Rate as Chronic HBV |

#### Chronic Infection (Without Biopsy, Untreated)

| LFTs / HBV DNA / HBeAg Status | LIFE      | WP        | ADB       | LTC       |
|-------------------------------|-----------|-----------|-----------|-----------|
| LFTs currently normal         | +25       | +50       | +50       | +50       |
| LFTs normal >3 years          | Std       | Std       | Std       | Std       |
| Mild LFT elevation (ALT/AST <1.5x ULN) | +75 | +100 | +75 | +75 |
| Moderate LFT elevation (ALT/AST 1.5–3x ULN), HBV DNA <20,000 | +125 | +150 | +100 | +100 |
| Moderate LFT elevation, HBV DNA >20,000 | +175 | +175 | +125 | +125 |
| Outside above                 | IC        | IC        | IC        | IC        |

#### Chronic Infection (With Biopsy, Untreated)

| Biopsy Findings / LFTs / HBV DNA | LIFE      | WP        | ADB       | LTC       |
|----------------------------------|-----------|-----------|-----------|-----------|
| Normal/mild inflammation/fibrosis, LFTs normal | Std | Std | Std | Std |
| Mild LFT elevation (ALT/AST <1.5x ULN) | +50 | +75 | +50 | +50 |
| Moderate inflammation/fibrosis, LFTs normal | +100 | +125 | +75 | +75 |
| Moderate LFT elevation (ALT/AST <1.5x ULN), HBeAg neg, HBV DNA <20,000 | +100 | +125 | +75 | +75 |
| Moderate LFT elevation, HBeAg neg, HBV DNA >20,000 | +150 | +150 | +100 | +100 |
| Severe inflammation/fibrosis     | Decline   | Decline   | Decline   | Decline   |
| Outside above                    | IC        | IC        | IC        | IC        |

#### Chronic Infection (Treated, With or Without Biopsy)

| Treatment Status / Labs          | LIFE      | WP        | ADB       | LTC       |
|----------------------------------|-----------|-----------|-----------|-----------|
| <1 year on treatment             | Rate as Chronic, Untreated         |
| >1 year, HBV DNA decreased, LFTs normal | Credit -25 from untreated rating |
| >1 year post-treatment, full response (HBV DNA neg, HBsAg neg, anti-HBe pos, LFTs normal) | Credit -50 from untreated rating |
| Others/Relapse                   | IC        | IC        | IC        | IC        |

#### WP, ADB, LTC (Summary Table)

| Condition / Status               | WP        | ADB       | LTC       |
|----------------------------------|-----------|-----------|-----------|
| Acute Infection                  | See Acute Infection Table Above    |
| Chronic, no/short treatment      | Decline   | Decline   | Decline   |
| HBV DNA negative/undetectable    | Std       | Std       | LIFE Rating|
| On long-term maintenance (>1 yr) | IC        | IC        | IC/Decline |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Without Biopsy)

| Condition or Factor                        | Adjustment         |
|--------------------------------------------|--------------------|
| HDV or HCV co-infection                    | Decline            |
| Alcohol use (>1 drink/day)                 | Decline            |
| Elevated alpha-fetoprotein                 | Decline            |
| Abdominal imaging suggestive of cirrhosis/mass | Decline        |
| Clinical findings of chronic liver disease | IC                 |
| Extra-hepatic manifestations               | IC                 |

#### 5b. Co-morbid Conditions and Risk Factors (With Biopsy)

| Condition or Factor                        | Adjustment         |
|--------------------------------------------|--------------------|
| Cirrhosis                                  | Decline            |
| HDV or HCV co-infection                    | Decline            |
| Excess alcohol use (>1 drink/day)          | Decline (IC if only mild biopsy findings) |
| Elevated alpha-fetoprotein                 | Decline            |
| Clinical findings of chronic liver disease | IC                 |
| Extra-hepatic manifestations               | IC                 |
| Liver biopsy >5 years old                  | Rate as no biopsy  |
| Serial biopsies                            | IC (adjust for progression) |

#### 5c. Credits for Protective Factors

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -25         |
| Sustained normal LFTs and low HBV DNA    | -25         |
| Full response to treatment (HBV DNA neg, HBsAg neg, anti-HBe pos, LFTs normal) | -50 |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
IC = Individual Consideration
ULN = Upper Limit of Normal
Std = Standard rates
