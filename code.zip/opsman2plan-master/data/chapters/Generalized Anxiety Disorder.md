# Generalized Anxiety Disorder  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Generalized Anxiety Disorder (GAD) is a chronic mental health condition characterized by excessive, persistent, and difficult-to-control worry about various aspects of daily life.

**Typical Signs and Symptoms:**
- Excessive anxiety and worry occurring more days than not for at least 6 months
- Restlessness or feeling keyed up
- Being easily fatigued
- Difficulty concentrating or mind going blank
- Irritability
- Muscle tension
- Sleep disturbance (difficulty falling or staying asleep, or restless unsatisfying sleep)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Family history of anxiety or mood disorders
- Chronic stress or trauma
- Co-existing psychiatric conditions (e.g., depression, substance use)
- Poor social support
- Non-compliance with treatment

**Protective Factors:**
- Good response to therapy
- Compliance with medications and follow-up
- Strong social support
- Absence of comorbid psychiatric or substance use disorders
- Stable employment and relationships

#### 1c. Classification of Severity

| Severity Level | Criteria (DSM-5)                                                                 |
|----------------|-------------------------------------------------------------------------------------------|
| Mild           | Symptoms present, minimal functional impairment, no hospitalizations                       |
| Moderate       | Symptoms cause some functional impairment, may require medication adjustment               |
| Severe         | Significant functional impairment, frequent work loss, hospitalizations, or comorbidities  |

#### 1d. Diagnostic Tests

- Clinical interview and mental status examination
- Standardized rating scales (e.g., GAD-7, Hamilton Anxiety Rating Scale)
- Screening for comorbid psychiatric conditions
- No specific laboratory or imaging tests required

#### 1e. Treatments

- **Medications:** SSRIs (sertraline, escitalopram), SNRIs (venlafaxine, duloxetine), buspirone, benzodiazepines (short-term)
- **Psychotherapy:** Cognitive Behavioral Therapy (CBT), relaxation techniques
- **Lifestyle:** Stress management, exercise, sleep hygiene
- **Other:** Support groups, mindfulness-based interventions

---

### 2. Underwriting Focus

- Severity and duration of symptoms
- Functional impairment (work, social, daily activities)
- History of hospitalizations or suicide attempts
- Compliance with treatment and follow-up
- Presence of comorbid psychiatric or substance use disorders
- Stability of employment and relationships

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, compliance      |
| Mental health questionnaire   | Symptom severity, functional impact   |
| Medication list               | Current and past 12 months            |
| Hospitalization history       | Last 5 years                          |
| Screening for comorbidities   | Depression, substance use             |

---

### 4. Rating

#### Generalized Anxiety Disorder – Synthetic Data (Revised)

| Severity/Action                                                                 | LIFE   | WP         | ADB        | LTC        |
|---------------------------------------------------------------------------------|--------|------------|------------|------------|
| Mild (no functional impairment, compliant, no other rateable mental disorder)   | Std    | Std        | Std        | Std        |
| Mild (recent diagnosis, <1 year)                                                | +30    | IC         | IC         | IC         |
| Moderate (some functional impairment, stable, compliant)                        | +60    | Decline    | Decline    | Decline    |
| Moderate (recent diagnosis, <1 year)                                            | +90    | Decline    | Decline    | Decline    |
| Severe (significant impairment, work loss, hospitalizations, or comorbidities)  | +120   | Decline    | Decline    | Decline    |
| Severe (recent diagnosis, <1 year)                                              | Postpone| Decline   | Decline    | Decline    |

*Std = Standard rates, IC = Individual Consideration*

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Revised)

| Co-morbid Condition or Factor         | Adjustment         |
|---------------------------------------|--------------------|
| With depression (mild/moderate/severe)| +30 / +60 / +90    |
| With substance use disorder           | Decline            |
| History of suicide attempt            | Decline            |
| Frequent hospitalizations             | Decline            |
| Non-compliance with treatment         | Decline            |
| Bipolar disorder                      | See Bipolar section|
| Eating disorder                       | IC                 |
| Personality disorder                  | IC or Decline      |

#### 5b. Credits for Protective Factors (Revised)

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -20         |
| Stable employment and relationships      | -20         |
| No hospitalizations, no work loss        | -10         |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
