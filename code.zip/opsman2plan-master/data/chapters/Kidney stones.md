# Chapter: Kidney Stone

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

Kidney stones, or renal calculi, are hard deposits of minerals and salts that form inside the kidneys. They can cause severe pain, hematuria (blood in urine), nausea, vomiting, and frequent urination. The most common symptom is intense pain in the back or side, often radiating to the lower abdomen and groin.

### 1b. Risk Factors and Protective Factors

**Risk Factors:**
- Dehydration
- High-sodium diet
- Obesity
- Digestive diseases
- Certain medications

**Protective Factors:**
- Staying well-hydrated
- Maintaining a balanced diet low in salt and animal protein
- Taking prescribed medications to manage underlying conditions

### 1c. Classification of Severity

Severity is typically classified based on the size and location of the stone, recurrence rate, and presence of complications like hydronephrosis or infection. The American Urological Association provides guidelines for classification:

- Small stones (<5 mm) often pass spontaneously.
- Larger stones (>10 mm) may require intervention.
- Recurrent or complicated cases are considered more severe.

### 1d. Diagnostic Tests

- **Imaging:** CT scan (non-contrast helical CT) is the gold standard for diagnosis.
- **Ultrasound:** Used for initial screening.
- **Laboratory Tests:** Urinalysis to check for blood, crystals, or infection; blood tests to assess kidney function.

### 1e. Treatments

- **Medications:** Pain relievers (e.g., ibuprofen), alpha-blockers (e.g., tamsulosin) to relax ureter muscles.
- **Procedures:** Extracorporeal shock wave lithotripsy (ESWL), ureteroscopy, and percutaneous nephrolithotomy for larger stones.
- **Preventive Measures:** Potassium citrate for reducing stone formation.

---

## 2. Underwriting Focus

- **Signs and Symptoms:** Frequency and severity of pain episodes, presence of hematuria.
- **Risk Factors:** Hydration status, dietary habits, recurrence history.
- **Diagnostics:** Results of imaging studies, laboratory test findings.
- **Treatments:** Type of treatment received, recovery status, and ongoing preventive measures.

---

## 3. Requirements

- **Medical Records:** Detailed history of kidney stone episodes, treatment records.
- **Imaging Reports:** CT or ultrasound results for stone size and location.
- **Laboratory Tests:** Recent urinalysis and blood tests for kidney function assessment.

---

## 4. Rating

Below is a synthetic example of rating tables based on severity, age, sex, and smoking status.

| Condition                                                                 | LIFE         | wp           | ADB         | ltc                |
|---------------------------------------------------------------------------|--------------|--------------|-------------|--------------------|
| **Present**                                                               |              |              |             |                    |
| Infrequent attacks, no hydronephrosis, normal renal function, normal urine| +10          | +5           | +0          | +0                 |
| - Unilateral                                                              | +10          | +5           | +0          | +0                 |
| - Bilateral                                                               | +30 to +60   | 1.7x         | +10         | Follow Life Rating  |
| - Others (with mild renal impairment or infection)                        | +70 and up   | IC           | IC          | IC                 |
| **History**                                                               |              |              |             |                    |
| Unoperated, infrequent attacks, urinalysis and renal function normal      | +10          | +10          | +0          | +0                 |
| **Operated (lithotripsy/ESWL, ureteroscopy with stent)**                  |              |              |             |                    |
| - Fully recovered, no hydronephrosis, normal renal function, normal urine | +0           | +0           | +0          | +0                 |
| - Others (recurrent stones, moderate impairment)                          | +80 and up   | IC           | IC          | IC                 |
| **Single Kidney (Congenital)**                                            |              |              |             |                    |
| Present                                                                   | +20          | +10          | +0          | +0                 |
| History                                                                   | +50 to Decline (IC) | IC   | IC          | IC                 |

**Legend:**
- `IC` = Individual Consideration
- `x` = times standard rate
- "Follow Life Rating" = use the LIFE column rating for ltc

---

**Note:** All values above are synthetic and for illustrative purposes only. Adjustments should be made based on actual underwriting guidelines and experience studies.
