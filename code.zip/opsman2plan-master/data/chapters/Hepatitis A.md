# Hepatitis A  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Hepatitis A is an acute viral infection of the liver caused by the hepatitis A virus (HAV), typically transmitted via the fecal-oral route.

**Typical Signs and Symptoms:**
- Sudden onset of fever, fatigue, loss of appetite
- Nausea, vomiting, abdominal pain
- Jaundice (yellowing of skin and eyes)
- Dark urine, pale stools
- Most cases are self-limited and resolve without chronic liver disease

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Older age
- Pre-existing liver disease
- Immunocompromised state
- Poor sanitation or contaminated food/water
- Travel to endemic areas

**Protective Factors:**
- Vaccination against hepatitis A
- Good hygiene and sanitation
- Prompt medical care and compliance with supportive treatment
- Absence of underlying liver disease

#### 1c. Classification of Severity

| Severity Level | Criteria                                                                 |
|----------------|--------------------------------------------------------------------------|
| Mild           | Self-limited, no jaundice, rapid recovery, no residual liver damage      |
| Moderate       | Jaundice present, prolonged symptoms, full recovery, no residual damage  |
| Severe         | Fulminant hepatitis, massive hepatic necrosis, risk of liver failure     |

#### 1d. Diagnostic Tests

- Liver function tests (ALT, AST, bilirubin, alkaline phosphatase)
- Hepatitis A IgM antibody (confirms acute infection)
- Prothrombin time (for severe cases)
- Abdominal ultrasound (if liver failure suspected)

#### 1e. Treatments

- **Supportive care:** hydration, rest, nutritional support
- **Hospitalization:** for severe or fulminant cases
- **No specific antiviral therapy**
- **Vaccination:** for prevention
- **Monitor for complications:** especially in severe cases

---

### 2. Underwriting Focus

- Severity and duration of illness
- Presence or absence of jaundice
- Evidence of residual liver damage
- History of hospitalization or fulminant hepatitis
- Co-existing liver disease or immunosuppression
- Compliance with follow-up and medical care

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, course, and recovery status |
| Liver function tests          | ALT, AST, bilirubin, within last 6 months |
| Hospitalization history       | For severe/fulminant cases             |
| Evidence of residual damage   | Imaging or lab results if indicated    |
| Screening for other liver diseases | Hepatitis B, C, or chronic liver disease |

---

### 4. Rating

#### Hepatitis A – Synthetic Data (Revised)

| Status                                      | LIFE      | WP        | ADB       | LTC       |
|----------------------------------------------|-----------|-----------|-----------|-----------|
| **Current infection (acute phase)**          | Postpone  | Postpone  | Postpone  | Postpone  |
| **Recovered, single mild attack**            | Std       | Std       | Std       | Std       |
| **Recovered, single moderate attack**        | +25       | Std       | Std       | Std       |
| **Recovered, severe episode (no residual damage, >2 years since recovery)** | +50 | +25 | +25 | Std |
| **Recovered, severe episode (no residual damage, 0–2 years since recovery)** | Postpone | Postpone | Postpone | Postpone |
| **Any residual liver damage (any severity)** | IC        | Decline   | Decline   | Decline   |
| **Multiple episodes of hepatitis A**         | +75       | +50       | +50       | Decline   |
| **With history of other sexually transmitted diseases** | IC | Decline | Decline | Decline |

*Std = Standard rates, IC = Individual Consideration*

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Revised)

| Co-morbid Condition or Factor         | Adjustment         |
|---------------------------------------|--------------------|
| Chronic hepatitis B or C              | Rate as per chronic hepatitis section |
| Cirrhosis or chronic liver disease    | Decline            |
| Immunosuppression                     | IC                 |
| Multiple episodes of hepatitis        | +50 to Decline     |
| Alcohol abuse                         | Add +25 to Decline |
| Diabetes                              | Add +25            |

#### 5b. Credits for Protective Factors (Revised)

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Documented vaccination                   | -15         |
| Excellent compliance, regular follow-up  | -15         |
| No underlying liver disease              | -10         |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes
