# Parkinson’s Disease  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Parkinson’s disease is a progressive neurodegenerative disorder characterized by motor and non-motor symptoms due to loss of dopamine-producing neurons in the brain.

**Typical Signs and Symptoms:**
- Resting tremor (often unilateral at onset)
- Bradykinesia (slowness of movement)
- Muscular rigidity
- Postural instability
- Gait disturbances
- Masked facial expression
- Cognitive impairment (in advanced stages)
- Depression, sleep disturbances, hallucinations (in some cases)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Early age of onset
- Rapid progression
- Poor response to medication
- Frequent falls
- Cognitive decline
- Severe motor symptoms
- Presence of hallucinations or psychosis
- Lack of social support

**Protective Factors:**
- Late age of onset
- Slow progression
- Good response to medication
- No cognitive impairment
- No falls
- Strong social support
- Compliance with treatment and follow-up

#### 1c. Classification of Severity

| Criteria/Scale                | Very Mild                | Mild                   | Moderate                | Severe                  |
|-------------------------------|--------------------------|------------------------|-------------------------|-------------------------|
| Schwab and England ADL        | 100%                     | 80–100%                | 50–79%                  | <50%                    |
| Hoehn and Yahr                | Stage I                  | Stage I                | Stage II–III            | Stage IV–V              |
| Activities of Daily Living    | Not affected             | Usually not affected   | OT may help preserve independence | Needs assistance with all ADLs |
| Balance/Gait                  | Not affected             | Usually not affected   | May develop problems, some postural instability | Frequent problems        |
| Cognitive                     | Not affected             | Usually not affected   | Usually not affected    | May be prominent, hallucinations/delusions |
| Falls                         | None                     | Usually none           | Infrequent              | Frequent                |
| Medication/Treatment          | None                     | Works well, suppresses symptoms | May wear off, side effects | Difficult to balance, may have had surgery |
| Movement                      | Mild tremor, fingers only, one side | Often tremor, one side, posture/walking changes | Both sides, slow movement, freezing | Wheelchair/bed most of day |
| Progression                   | Regular                  | Regular                | Regular                 | Rapid                   |

#### 1d. Diagnostic Tests

- Clinical neurological examination
- Unified Parkinson’s Disease Rating Scale (UPDRS)
- Hoehn and Yahr staging
- Schwab and England ADL scale
- Brain MRI (to rule out other causes)
- Response to dopaminergic therapy

#### 1e. Treatments

- **Medications:**
  - Levodopa/carbidopa
  - Dopamine agonists (pramipexole, ropinirole)
  - MAO-B inhibitors (selegiline, rasagiline)
  - COMT inhibitors (entacapone)
  - Amantadine
  - Anticholinergics (benztropine, trihexyphenidyl)
- **Surgical:**
  - Deep brain stimulation (DBS)
- **Supportive:**
  - Physical, occupational, and speech therapy
  - Fall prevention strategies
  - Social support and counseling

---

### 2. Underwriting Focus

- Age at onset and current age
- Rate of progression
- Severity of motor and non-motor symptoms
- Response to medication
- Frequency of falls
- Cognitive impairment or psychiatric symptoms
- Activities of daily living (ADL) independence
- Use of assistive devices or need for care
- Compliance with treatment
- Family history or genetic testing (for early onset/familial cases)

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent neurologist report  | Diagnosis, severity, progression, meds   |
| Functional assessment      | Schwab and England, Hoehn and Yahr, ADL  |
| Medication list            | Current and past 12 months               |
| Imaging (MRI/CT)           | If diagnosis uncertain                   |
| Cognitive assessment       | If cognitive symptoms present            |
| Family/genetic history     | If early onset or familial PD            |

---

### 4. Rating

#### Parkinson’s Disease Severity Chart (Synthetic, Revised)

| Symptoms/Severity | <50 | 50–59 | 60–69 | 70–79 | 80+ | WP | ADB | LTC |
|-------------------|-----|-------|-------|-------|-----|----|-----|-----|
| Very Mild         | +90 | +60   | +35   | +10   | +0  | Decline | Decline | Decline |
| Mild              | +130| +90   | +55   | +25   | Std | Decline | Decline | Decline |
| Moderate          | +210| +130  | +80   | +50   | +25 | Decline | Decline | Decline |
| Severe            | Decline | Decline | Decline | Decline | Decline | Decline | Decline | Decline |

#### Early Onset / Familial Parkinson’s (No Symptoms, Revised)

| Age    | Life  | WP      | ADB     | LTC     |
|--------|-------|---------|---------|---------|
| 18–50  | +60   | Decline | Decline | Decline |
| 51–60  | +35   | Decline | Decline | Decline |
| 61+    | Std   | Std     | Std     | Std     |
| Family history/genetic positive (no test in applicant) | +0 | +0 | +0 | +0 |

#### Other Movement Disorders (Synthetic, Revised)

| Disorder                        | Life    | WP      | ADB     | LTC     |
|----------------------------------|---------|---------|---------|---------|
| Diffuse Lewy-body Disease        | Decline | Decline | Decline | Decline |
| Shy-Drager syndrome             | Decline | Decline | Decline | Decline |
| Multisystem Atrophy              | Decline | Decline | Decline | Decline |
| Olivopontocerebellar Atrophy     | Decline | Decline | Decline | Decline |
| Drug Induced Parkinsonism        | IC      | Decline | Decline | IC      |
| Pugilistic Parkinsonism          | IC      | Decline | Decline | Decline |
| Progressive Supranuclear Palsy   | Decline | Decline | Decline | Decline |
| Essential Tremor                 | Refer to Essential Tremor guidelines |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Synthetic, Revised)

| Condition/Factor                | Rating Adjustment                |
|---------------------------------|----------------------------------|
| Dementia or severe cognitive impairment | Decline                  |
| Frequent falls or fractures     | Decline                         |
| Severe depression or psychosis  | IC or Decline                   |
| Poor compliance with treatment  | Decline                         |
| Severe autonomic dysfunction    | Decline                         |
| Other significant comorbidities | IC                              |
| Mild depression                 | +20                             |
| Moderate depression             | +50                             |
| Severe depression               | Decline                         |
| Recurrent hallucinations        | IC, usually +40                 |

#### 5b. Credits for Protective Factors (Synthetic, Revised)

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| Excellent compliance, slow progression    | -20         |
| No falls, no cognitive impairment         | -20         |
| Strong social support, regular therapy    | -15         |

---

**Legend:**
- IC = Individual Consideration
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- Std = Standard

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
