# Iron Deficiency Anemia  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Iron deficiency anemia is a condition where the body lacks enough iron to produce adequate healthy red blood cells, leading to reduced oxygen delivery to tissues.

**Typical Signs and Symptoms:**
- Fatigue, weakness, pallor
- Shortness of breath, dizziness
- Headache, cold hands and feet
- Brittle nails, hair loss
- Pica (craving for non-food substances)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Chronic blood loss (e.g., heavy menstruation, GI bleeding)
- Poor dietary iron intake
- Increased requirements (pregnancy, lactation)
- Malabsorption syndromes
- Chronic diseases

**Protective Factors:**
- Adequate iron supplementation
- Identification and treatment of underlying cause
- Good compliance with therapy
- Regular monitoring and follow-up

#### 1c. Classification of Severity

| Severity Level | Hemoglobin (g/dL) | Symptoms/Findings                |
|----------------|-------------------|----------------------------------|
| Mild           | 10–12 (women), 10–13 (men) | Often asymptomatic or mild symptoms |
| Moderate       | 8–10              | Moderate symptoms, reduced exercise tolerance |
| Severe         | <8                | Marked symptoms, possible cardiac strain |

#### 1d. Diagnostic Tests

- Complete blood count (CBC)
- Serum ferritin, serum iron, total iron binding capacity (TIBC)
- Reticulocyte count
- Peripheral blood smear
- GI work-up if bleeding suspected (hemoccult/guaiac test, endoscopy/colonoscopy)

#### 1e. Treatments

- **Oral iron supplements:** ferrous sulfate, ferrous gluconate
- **IV iron therapy:** ferric carboxymaltose, iron sucrose (for severe or malabsorption)
- **Treat underlying cause:** e.g., manage GI bleeding, dietary counseling
- **Blood transfusion:** for severe, symptomatic anemia

---

### 2. Underwriting Focus

- Severity of anemia (hemoglobin level)
- Identified cause (menstrual, pregnancy, GI bleeding, unknown)
- Response to treatment and stability
- Presence of underlying or associated conditions
- Completeness of diagnostic work-up
- Compliance with therapy

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, cause, treatment, stability |
| Recent hemoglobin/hematocrit   | Within last 6 months                  |
| Iron studies (ferritin, iron, TIBC) | If available                     |
| GI work-up results             | If GI bleeding suspected               |
| Menstrual/pregnancy history    | For pre-menopausal women               |

---

### 4. Rating

#### Iron Deficiency Anemia – Synthetic Data (Revised, Realistic Table)

| Category                                 | Hemoglobin (g/dL) | Life   | WP      | ADB     | LTC     |
|------------------------------------------ |-------------------|--------|---------|---------|---------|
| **PRE-MENOPAUSAL WOMEN**                 |                   |        |         |         |         |
| Known menstrual loss/pregnancy/lactation | >10               | Std    | Std     | Std     | Std     |
|                                          | 8–10              | +25    | Std     | Std     | Decline |
|                                          | <8                | Postpone| Postpone| Postpone| Decline |
| Cause unknown, no other disorder         | >10               | Std    | Std     | Std     | Std     |
|                                          | <10               | IC     | IC      | IC      | Decline |
| **POST-MENOPAUSAL WOMEN/MALES**          |                   |        |         |         |         |
| Known cause                             | >10               | RFC    | RFC     | RFC     | RFC     |
|                                          | 8–10              | +50    | Decline | Decline | Decline |
|                                          | <8                | Postpone| Postpone| Postpone| Decline |
| Cause unknown, evidence of GI bleeding   | ≥10               | Postpone| Postpone| Postpone| Decline |
|                                          | <10               | Decline | Decline | Decline | Decline |
| Benign upper/lower GI work-up            | Any               | Std    | Std     | Std     | IC      |
| Incomplete work-up, Hgb <10              | <10               | IC     | IC      | IC      | IC      |
| Other unknown cause                      | Any               | IC     | IC      | IC      | IC      |

*IC = Individual Consideration, RFC = Rate for Cause, Std = Standard rates*

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Co-morbid Condition or Factor         | Adjustment         |
|---------------------------------------|--------------------|
| Chronic kidney disease                | Decline            |
| Malignancy                            | Decline            |
| Chronic GI disease (e.g., IBD)        | IC                 |
| Ongoing blood loss                    | IC                 |
| Heart failure                         | IC                 |
| Severe malabsorption                  | IC                 |

#### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -10         |
| Full correction and stable hemoglobin    | -15         |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
