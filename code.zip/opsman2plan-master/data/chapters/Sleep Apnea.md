# Sleep Apnea – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Sleep apnea is a sleep disorder characterized by repeated episodes of partial or complete obstruction of the upper airway during sleep, resulting in reduced or paused breathing. The most common type is obstructive sleep apnea (OSA), but central sleep apnea (CSA) and mixed forms also exist.

**Typical Signs and Symptoms:**  
- Loud snoring  
- Witnessed apneas (breathing pauses) during sleep  
- Excessive daytime sleepiness  
- Morning headaches  
- Difficulty concentrating  
- Irritability  
- Dry mouth or sore throat upon awakening

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Obesity (BMI >30)  
- Male sex  
- Older age  
- Large neck circumference  
- Craniofacial abnormalities  
- Family history of sleep apnea  
- Alcohol or sedative use  
- Smoking  
- Co-morbid conditions (hypertension, diabetes, heart disease)

**Protective Factors:**  
- Weight loss  
- Good adherence to CPAP or other therapy  
- Avoidance of alcohol and sedatives  
- Regular exercise  
- Smoking cessation  
- Effective management of co-morbidities

---

### 1c. Classification of Severity

Severity is classified by the Apnea-Hypopnea Index (AHI), which measures the number of apneas and hypopneas per hour of sleep (per American Academy of Sleep Medicine and Canadian Thoracic Society):

| Severity   | AHI (events/hour) | Oxygen Desaturation | Symptoms/Complications      |
|------------|-------------------|---------------------|-----------------------------|
| Mild       | 5–14              | Minimal             | May have mild symptoms      |
| Moderate   | 15–29             | Moderate            | Daytime sleepiness, HTN     |
| Severe     | ≥30               | Marked              | Marked symptoms, CVD, etc.  |

---

### 1d. Diagnostic Tests

- Overnight polysomnography (sleep study)  
- Home sleep apnea testing (HSAT)  
- Apnea-Hypopnea Index (AHI)  
- Oxygen saturation monitoring  
- Epworth Sleepiness Scale  
- Echocardiogram (if cardiac complications suspected)

---

### 1e. Treatments

- Continuous Positive Airway Pressure (CPAP)  
- Bilevel Positive Airway Pressure (BiPAP)  
- Oral appliances (mandibular advancement devices)  
- Weight loss interventions  
- Surgery (UPPP, maxillomandibular advancement)  
- Positional therapy  
- Medications (limited role; e.g., modafinil for residual sleepiness)

---

## 2. Underwriting Focus

Underwriters should focus on:
- Severity of sleep apnea (AHI, oxygen desaturation)
- Presence and control of symptoms (daytime sleepiness, accidents)
- Compliance with CPAP or other therapy
- Presence of co-morbidities (hypertension, diabetes, heart disease, obesity)
- History of cardiovascular or cerebrovascular events
- Smoking status
- Recent sleep study results and follow-up

---

## 3. Requirements

| Requirement                  | Details / Cut-off                        |
|------------------------------|------------------------------------------|
| Attending physician statement| Diagnosis, treatment, complications      |
| Recent sleep study           | AHI, oxygen saturation, date (within 2 years) |
| CPAP compliance report       | Usage data (hours/night, % nights used)  |
| Details of co-morbidities    | Hypertension, diabetes, CVD, BMI         |
| Driving history              | If excessive daytime sleepiness present  |

---

## 4. Rating

### Sleep Apnea Rating Table (Synthetic Data)

| Severity   | AHI (events/hr) | CPAP Compliance | Age <40 | Age 41–69 | Age 70+ |
|------------|-----------------|-----------------|---------|-----------|---------|
| Mild       | 5–14            | Good            | Standard| Standard  | Standard|
| Mild       | 5–14            | Poor            | +30     | +20       | +10     |
| Moderate   | 15–29           | Good            | +40     | +25       | Standard|
| Moderate   | 15–29           | Poor            | +80     | +60       | +40     |
| Severe     | ≥30             | Good            | +90     | +70       | +50     |
| Severe     | ≥30             | Poor            | +160    | +120      | +80     |
| Any        | Any             | Non-compliant   | Decline | Decline   | Decline |

**Other Factors:**
- History of motor vehicle accident due to sleepiness: Postpone or Decline
- Uncontrolled hypertension or heart failure: Add +40 to +80 or Decline
- BMI >40: Add +40 to +80

---

## 5. Additional Considerations

### a) Co-morbid Conditions and Risk Factors

| Additional Condition                  | Rating Adjustment      |
|---------------------------------------|-----------------------|
| Uncontrolled hypertension             | +40                   |
| Coronary artery disease               | See CAD section       |
| Heart failure                         | Decline               |
| Stroke/TIA                            | +80 or Decline        |
| Diabetes mellitus                     | +20 to +40            |
| Obesity (BMI 35–39.9)                 | +20                   |
| Obesity (BMI ≥40)                     | +40 to +80            |
| Non-compliance with therapy           | Decline               |
| History of arrhythmia                 | +30                   |
| Pulmonary hypertension                | Decline               |

### b) Credits for Protective Factors

| Protective Factor                     | Credit  |
|---------------------------------------|---------|
| Documented CPAP compliance (>4 hrs/night, >70% nights) | -20     |
| Sustained weight loss (>10% body weight)              | -20     |
| No daytime sleepiness, normal Epworth score           | -20     |
| No co-morbidities                                    | -20     |
| Non-smoker                                           | -20     |

---

### LIFE, WP, ADB, and LTC Ratings

| LIFE Rating         | WP      | ADB     | LTC      |
|---------------------|---------|---------|----------|
| Standard            | Standard| Standard| Standard |
| +20 to +40          | Decline | 1.5x    | Decline  |
| +60 to +80          | Decline | 2x      | Decline  |
| >+80                | Decline | Decline | Decline  |
| Non-compliant       | Decline | Decline | Decline  |

---

**Note:**  
All values and tables above are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.
