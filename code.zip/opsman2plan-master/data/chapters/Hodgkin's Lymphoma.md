# Hodgkin's Lymphoma  
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Hodgkin's lymphoma is a malignant lymphoma characterized by the presence of Reed-Sternberg cells, typically presenting with painless lymphadenopathy and systemic symptoms.

**Typical Signs and Symptoms:**
- Painless swelling of lymph nodes (neck, armpit, groin)
- Fever
- Night sweats
- Unintentional weight loss
- Fatigue
- Itching
- Persistent cough or chest pain (if mediastinal nodes involved)

#### 1b. Risk and Protective Factors

**Risk Factors:**
- Advanced stage at diagnosis
- Presence of B symptoms (fever, night sweats, weight loss)
- Bulky disease
- Age >45
- Male sex
- Poor response to initial therapy
- Relapse or recurrence
- Elevated ESR or abnormal blood counts

**Protective Factors:**
- Early stage at diagnosis
- Absence of B symptoms
- Young age
- Female sex
- Complete remission after first-line therapy
- Good performance status
- Compliance with follow-up and treatment

#### 1c. Classification of Severity

| Stage   | Description                                                                 |
|---------|-----------------------------------------------------------------------------|
| I       | Involvement of a single lymph node region or single extralymphatic site     |
| II      | Involvement of two or more lymph node regions on the same side of diaphragm |
| III     | Involvement of lymph node regions on both sides of diaphragm                |
| IV      | Disseminated involvement of one or more extralymphatic organs               |

- **A:** No systemic symptoms
- **B:** Presence of systemic symptoms (fever, night sweats, weight loss)

#### 1d. Diagnostic Tests

- Lymph node biopsy (for diagnosis)
- PET/CT scan (for staging and response)
- CBC, ESR, LDH, liver and renal function tests
- Bone marrow biopsy (if advanced stage)
- Imaging (chest X-ray, CT, MRI as needed)

#### 1e. Treatments

- **Chemotherapy:** ABVD (doxorubicin, bleomycin, vinblastine, dacarbazine), BEACOPP, other regimens
- **Radiation therapy:** Involved-field or involved-site
- **Targeted therapy:** Brentuximab vedotin
- **Immunotherapy:** Checkpoint inhibitors (nivolumab, pembrolizumab)
- **Stem cell or bone marrow transplant:** For relapsed/refractory cases
- **Supportive care:** Growth factors, transfusions, infection prophylaxis

---

### 2. Underwriting Focus

- Stage at diagnosis and current status
- Age at diagnosis and current age
- Presence or absence of B symptoms
- Treatment received and response (remission, relapse, refractory)
- Time since completion of treatment
- Any recurrence or second malignancy
- Current performance status and lab results
- Smoking history
- Compliance with follow-up

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Recent oncology report     | Diagnosis, stage, treatment, remission   |
| PET/CT scan                | Most recent, for remission confirmation  |
| CBC, ESR, LDH              | Within last 6 months                     |
| Treatment summary          | Chemotherapy, radiation, transplant      |
| Smoking history            | Current and past                         |
| Follow-up records          | At least 2 years post-treatment          |

---

### 4. Rating

#### Hodgkin's Lymphoma – Single Episode, Complete Remission, No Recurrence (Synthetic, Revised)

| Stage     | Age 15–44 | Age 45–64 | Age 65+   |
|-----------|-----------|-----------|-----------|
| Stage IA  | +60       | +60       | +80 (IC)  |
| Stage IB  | +90       | +90       | +110 (IC) |
| Stage IIA | +70       | +70       | +120 (IC) |
| Stage IIB | +110      | +110      | IC        |
| Stage IIIA| +90       | +90       | Decline   |
| Stage IIIB| +130      | +130      | Decline   |
| Stage IVA | +140 (IC) | IC        | Decline   |
| Stage IVB | Decline   | Decline   | Decline   |

*IC = Individual Consideration.
If 10 years post-treatment, no recurrence, and no significant complications, consider IC for possible offer if previously declined.*

#### Waiver of Premium (WP) and Accidental Death Benefit (ADB)

| Rider | Rating/Requirement                |
|-------|-----------------------------------|
| WP    | See Tumor Rating Classes          |
| ADB   | See Tumor Rating Classes          |

#### Long-Term Care (LTC)

| Rider | Rating/Requirement |
|-------|--------------------|
| LTC   | Decline all        |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors (Synthetic, Revised)

| Condition/Factor                                 | Adjustment         |
|--------------------------------------------------|--------------------|
| Current age >65                                  | IC all cases       |
| Bone marrow/stem cell transplant (0–5 years)     | Postpone           |
| Bone marrow/stem cell transplant (>5 years, <60) | IC (min. +150)     |
| Bone marrow/stem cell transplant (>5 years, >60) | IC (usually decline)|
| Mild, well-controlled rejection                   | Add minimum +120   |
| Recurrence (one, complete remission)             | Rate from recurrence +70 |
| More than one recurrence                         | Decline            |
| Partial remission only                           | Decline            |
| Unexplained weight loss, fever, night sweats     | Decline            |
| Abnormal labwork (LFT, CBC, ESR, etc.)          | Decline            |
| Smoking, heavy (>1 pack/day)                     | Consider +70       |
| Unexplained lymphadenopathy                      | Postpone           |
| History of life-threatening infections (2 yrs)   | IC                 |
| Post-treatment AML                               | Decline            |
| Post-treatment solid tumor                       | IC, consider decline|
| Remission >10 years, previously declined         | IC for possible offer|

#### 5b. Credits for Protective Factors (Synthetic, Revised)

| Protective Factor                        | Credit      |
|-------------------------------------------|-------------|
| Chemotherapy only, 15 years post-treatment, no leukemia | -70 |
| Excellent compliance, regular follow-up   | -30         |

---

**Legend:**
- IC = Individual Consideration
- WP = Waiver of Premium
- ADB = Accidental Death Benefit
- LTC = Long-Term Care
- Decline = Not eligible for coverage

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
