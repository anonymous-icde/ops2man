# Hepatitis C
## Underwriting Manual Chapter

---

### 1. General Information

#### 1a. Definition and Typical Signs and Symptoms

**Definition:**
Hepatitis C is a viral infection of the liver caused by the hepatitis C virus (HCV), usually transmitted via blood. It can present as an acute or chronic infection and may lead to liver inflammation, fibrosis, cirrhosis, or hepatocellular carcinoma.

**Typical Signs and Symptoms:**
- Acute: Fatigue, jaundice, dark urine, abdominal pain, nausea, vomiting, loss of appetite
- Chronic: Often asymptomatic, but may progress to liver dysfunction, cirrhosis, or liver cancer

#### 1b. Risk and Protective Factors

**Risk Factors:**
- High HCV RNA viral load
- Abnormal liver function tests (LFTs)
- Co-infection with HBV or HIV
- Excessive alcohol use
- Older age, male sex, long duration of infection
- Family history of liver cancer

**Protective Factors:**
- Successful antiviral therapy (SVR)
- Sustained normal LFTs
- Low/undetectable HCV RNA
- No evidence of fibrosis or cirrhosis
- Compliance with follow-up and treatment

#### 1c. Classification of Severity

| Severity Level | Criteria                                                                 |
|----------------|--------------------------------------------------------------------------|
| Mild           | HCV positive, normal LFTs, low/undetectable HCV RNA, no fibrosis         |
| Moderate       | Mild LFT elevation, moderate HCV RNA, minimal fibrosis                   |
| Severe         | Moderate/severe LFT elevation, high HCV RNA, advanced fibrosis/cirrhosis, or hepatocellular carcinoma |

*Reference: AASLD, Canadian Liver Foundation, METAVIR scoring*

#### 1d. Diagnostic Tests

- HCV antibody and RNA viral load
- Liver function tests (ALT, AST, GGT, bilirubin, albumin)
- Alpha-fetoprotein (AFP)
- Abdominal ultrasound or CT (for cirrhosis/mass)
- Liver biopsy or elastography (for fibrosis/inflammation grading)

#### 1e. Treatments

- **Antiviral medications:** direct-acting antivirals (sofosbuvir, ledipasvir, glecaprevir/pibrentasvir, etc.)
- **Supportive care:** monitoring, lifestyle modification (avoid alcohol)
- **Liver transplant:** for end-stage liver disease

---

### 2. Underwriting Focus

- Duration and phase of infection (acute vs. chronic)
- LFT trends and HCV RNA levels
- Biopsy or elastography findings (if available)
- Evidence of cirrhosis, fibrosis, or hepatocellular carcinoma
- Co-infections (HBV, HIV)
- Alcohol use
- Compliance with treatment and follow-up

---

### 3. Requirements

| Requirement                | Details / Cut-off                        |
|----------------------------|------------------------------------------|
| Attending physician statement | Diagnosis, treatment, compliance      |
| LFTs (ALT, AST, GGT, bilirubin, albumin) | Last 6–12 months         |
| HCV serology and RNA viral load         | Required                  |
| Liver biopsy or elastography report     | If available, for fibrosis/inflammation  |
| Imaging (ultrasound/CT)                 | If cirrhosis or mass suspected           |
| Alpha-fetoprotein (AFP)                 | For cancer screening                     |
| Screening for co-infections             | HBV, HIV                                 |

---

### 4. Rating

#### Acute Infection

| Time Since Diagnosis | LIFE      | WP        | ADB       | LTC       |
|---------------------|-----------|-----------|-----------|-----------|
| 0–6 months          | Postpone  | Postpone  | Postpone  | Decline   |
| >6 months           |           |           |           |           |
| HCV RNA negative, LFTs normal | Std | Std | Std | Std |
| HCV RNA negative, LFTs abnormal | Rate for LFTs | Decline | Decline | Decline |
| Unknown/Unavailable serology, LFTs normal | Std | Std | Std | Std |
| Unknown/Unavailable serology, LFTs abnormal | Rate as Chronic HCV | Rate as Chronic HCV | Rate as Chronic HCV | Rate as Chronic HCV |

#### Chronic Infection (Without Biopsy, Untreated)

| LFTs / HCV RNA Status | LIFE      | WP        | ADB       | LTC       |
|-----------------------|-----------|-----------|-----------|-----------|
| LFTs currently normal         | +50       | +75       | +75       | +75       |
| LFTs normal >3 years          | Std       | Std       | Std       | Std       |
| Mild LFT elevation (ALT/AST <1.5x ULN) | +100 | +125 | +100 | +100 |
| Moderate LFT elevation (ALT/AST 1.5–3x ULN), HCV RNA <800,000 | +150 | +175 | +125 | +125 |
| Moderate LFT elevation, HCV RNA >800,000 | +200 | +200 | +150 | +150 |
| Outside above                 | IC        | IC        | IC        | IC        |

#### Chronic Infection (With Biopsy/Elastography, Untreated)

| Biopsy/Elastography Findings / LFTs / HCV RNA | LIFE      | WP        | ADB       | LTC       |
|-----------------------------------------------|-----------|-----------|-----------|-----------|
| Normal/mild inflammation/fibrosis, LFTs normal | Std | Std | Std | Std |
| Mild LFT elevation (ALT/AST <1.5x ULN) | +75 | +100 | +75 | +75 |
| Moderate inflammation/fibrosis, LFTs normal | +125 | +150 | +100 | +100 |
| Moderate LFT elevation (ALT/AST <1.5x ULN), HCV RNA <800,000 | +125 | +150 | +100 | +100 |
| Moderate LFT elevation, HCV RNA >800,000 | +175 | +175 | +125 | +125 |
| Severe inflammation/fibrosis     | Decline   | Decline   | Decline   | Decline   |
| Outside above                    | IC        | IC        | IC        | IC        |

#### Chronic Infection (Treated, With or Without Biopsy)

| Treatment Status / Labs          | LIFE      | WP        | ADB       | LTC       |
|----------------------------------|-----------|-----------|-----------|-----------|
| <1 year post-treatment           | Rate as Chronic, Untreated         |
| >1 year, HCV RNA negative, LFTs normal | Credit -50 from untreated rating |
| >1 year post-treatment, SVR (sustained virologic response), LFTs normal | Credit -75 from untreated rating |
| Others/Relapse                   | IC        | IC        | IC        | IC        |

#### WP, ADB, LTC (Summary Table)

| Condition / Status               | WP        | ADB       | LTC       |
|----------------------------------|-----------|-----------|-----------|
| Acute Infection                  | See Acute Infection Table Above    |
| Chronic, no/short treatment      | Decline   | Decline   | Decline   |
| HCV RNA negative/SVR             | Std       | Std       | LIFE Rating|
| On long-term maintenance (>1 yr) | IC        | IC        | IC/Decline |

---

### 5. Additional Considerations

#### 5a. Co-morbid Conditions and Risk Factors

| Condition or Factor                        | Adjustment         |
|--------------------------------------------|--------------------|
| HBV or HIV co-infection                    | Decline            |
| Alcohol use (>1 drink/day)                 | Decline            |
| Elevated alpha-fetoprotein                 | Decline            |
| Abdominal imaging suggestive of cirrhosis/mass | Decline        |
| Clinical findings of chronic liver disease | IC                 |
| Extra-hepatic manifestations               | IC                 |

#### 5b. Credits for Protective Factors

| Protective Factor                        | Credit      |
|------------------------------------------|-------------|
| Excellent compliance, regular follow-up  | -25         |
| Sustained normal LFTs and low HCV RNA    | -25         |
| SVR (sustained virologic response)       | -75         |

---

**Note:**
All values and tables above are synthetic and for illustrative purposes only.
IC = Individual Consideration
ULN = Upper Limit of Normal
Std = Standard rates
Std = Standard rates
SVR = Sustained Virologic Response
