# Asthma – Underwriting Manual Chapter

---

## 1. General Information

### 1a. Definition and Typical Signs and Symptoms

**Definition:**  
Asthma is a chronic inflammatory disease of the airways, causing variable and recurring symptoms, reversible airflow obstruction, and bronchospasm.

**Typical Signs and Symptoms:**  
- Wheezing  
- Shortness of breath  
- Chest tightness  
- Cough (especially at night or early morning)  
- Symptoms may be episodic or persistent

---

### 1b. Risk and Protective Factors

**Risk Factors Affecting Prognosis:**  
- Poor medication adherence  
- Frequent exacerbations or hospitalizations  
- Smoking or exposure to secondhand smoke  
- Obesity  
- Allergic rhinitis or atopy  
- Occupational exposures  
- Co-morbidities (e.g., COPD, cardiac disease)

**Protective Factors:**  
- Good medication compliance  
- Regular follow-up with healthcare provider  
- Avoidance of triggers (allergens, smoke, pollution)  
- Use of inhaled corticosteroids as prescribed  
- Vaccinations (influenza, pneumococcal)  
- Healthy weight and regular exercise

---

### 1c. Classification of Severity

Severity is classified according to validated criteria (NHLBI or Canadian Thoracic Society), based on symptoms, activity limitation, lung function, and medication use.

| Severity   | Symptoms                  | Activity Limitation         | Hospital/ER Visits | Night Symptoms | FEV1 (% predicted) | Medication Use                  |
|------------|---------------------------|----------------------------|--------------------|----------------|--------------------|---------------------------------|
| Minimal    | Rare                      | None                       | None               | None           | >80%               | None or rare SABA               |
| Mild       | <2/week, none between     | Occasional exacerbations    | Rare               | Monthly        | >80%               | Low-dose ICS, occasional SABA   |
| Moderate   | >2/week to daily          | Frequent exacerbations      | Occasional         | Weekly         | 60–79%             | Low/moderate ICS, SABA, others  |
| Severe     | Continual                 | Limited physical activity   | Frequent           | Frequent       | <60%                | High-dose ICS, SABA, oral meds  |

---

### 1d. Diagnostic Tests

- **Spirometry:** FEV1, FEV1/FVC ratio, reversibility with bronchodilator  
- **Peak Expiratory Flow (PEF):** Variability and response to treatment  
- **Allergy testing:** If allergic triggers suspected  
- **Chest X-ray:** To rule out other causes if indicated

---

### 1e. Treatments

- **Short-acting beta-agonists (SABA):** Salbutamol, albuterol  
- **Inhaled corticosteroids (ICS):** Fluticasone, budesonide  
- **Long-acting beta-agonists (LABA):** Salmeterol, formoterol (with ICS)  
- **Leukotriene receptor antagonists:** Montelukast  
- **Oral corticosteroids:** Prednisone (for severe cases/exacerbations)  
- **Biologics:** Omalizumab, mepolizumab (for severe allergic/eosinophilic asthma)  
- **Lifestyle:** Allergen avoidance, smoking cessation, vaccinations

---

## 2. Underwriting Focus

- Severity and frequency of symptoms  
- Number of exacerbations and hospitalizations  
- Medication use and compliance  
- Lung function (FEV1, PEF)  
- Smoking status  
- Presence of co-morbidities (COPD, cardiac disease, psychiatric disorders)  
- Evidence of near-fatal episodes or ICU admissions  
- Age at onset and duration of disease

---

## 3. Requirements

- Attending physician statement (APS) with details of diagnosis, treatment, and follow-up  
- Recent spirometry or PFT results (with FEV1 and PEF values)  
- Hospital/ER visit records (if any)  
- Details of medication use (including oral steroids or biologics)  
- Smoking history  
- Details of co-morbid conditions

---

## 4. Rating

### Asthma Severity and Rating Table

| Severity   | Age 0–5 yrs | Age 6–16 yrs | Age 17–20 yrs | Age 21–70 yrs | Age >70 yrs | Smoker Adjustment |
|------------|-------------|--------------|---------------|---------------|-------------|-------------------|
| Minimal    | +0          | +0           | +0            | +0            | +0          | +0                |
| Mild       | IC          | +0 to +45    | +0 to +45     | +0 to +45     | +0 to +45   | Standard          |
| Moderate   | Decline     | +90 or Decline| +90 to +140  | +45 to +90    | +45         | Add +45 (decline if <17) |
| Severe     | Decline     | Decline      | Decline       | +140 to Decline| IC         | Decline           |

**Notes:**  
- Best classes (non-smoker or smoker) rates are possible for best cases within minimal and mild severities.  
- Any case of asthma in a smoker over age 50 should be carefully assessed for underlying COPD.  
- Ages <16 cannot be rated over 200%. If >+90, juveniles must be declined.

---

### Long-Term Care (LTC) Rating Table

| Life Rating Category                | LTC Rating                |
|-------------------------------------|---------------------------|
| Minimal or Mild, non-smoker         | Life rating               |
| Moderate, no frequent exacerbations | +45, not better           |
| Frequent exacerbations              | Decline                   |
| Severe                              | Decline                   |
| Smoker, any severity                | Decline                   |
| Oxygen use                          | Decline                   |

---

### Waiver of Premium (WP) and Accidental Death Benefit (ADB) Table

| Life Rating      | WP      | ADB     |
|------------------|---------|---------|
| +0               | +0      | +0      |
| +20 to +45       | Decline | 1.5x    |
| +70 to +90       | Decline | 2x      |
| >+90             | Decline | Decline |

---

## 5. Additional Considerations

### Co-morbidities and Other Risk Factors

| Condition/Factor                  | Rating Impact                  |
|-----------------------------------|-------------------------------|
| Alcohol abuse                     | Decline                       |
| Bronchiectasis (mild)             | +0                            |
| Bronchiectasis (moderate)         | Add +45 to +90                |
| Bronchiectasis (severe)           | IC                            |
| Cardiac asthma                    | Decline                       |
| COPD, minimal/mild asthma         | Rate for COPD                 |
| COPD, moderate/severe asthma      | Rate COPD and add +45 to decline for asthma |
| Coronary artery disease, minimal/mild asthma | +0                |
| Coronary artery disease, moderate/severe asthma | IC             |
| Evidence of non-compliance        | IC                            |
| Life-threatening episode (<2 yrs) | Postpone                      |
| Life-threatening episode (>2 yrs) | Rate as severe                |
| Psychiatric disorder, minimal/mild/moderate asthma | Add +45 to +90 |
| Psychiatric disorder, severe asthma | Decline                      |
| Remote history only (>10 yrs)     | Rate according to last 5 years severity |
| Underweight >15%                  | Add +45                       |

---

**Legend:**  
- **IC** = Individual Consideration  
- **Decline** = Application not accepted  
- **Postpone** = Decision deferred until further information or time has passed

---

**All values are synthetic and for illustrative purposes only. For actual underwriting, refer to internal life tables and current medical guidelines.**
