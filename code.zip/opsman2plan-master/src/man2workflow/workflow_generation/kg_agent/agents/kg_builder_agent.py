import logging
import networkx as nx
import json
from langchain_core.runnables.config import RunnableConfig
from typing import Dict, Any, List

class KGBuilderAgent:
    def __init__(self, current_knowledge_graph=nx.DiGraph()):
        self.logger = logging.getLogger('KGBuilderAgent')
        self.graph = current_knowledge_graph

    def add_impairment(self, impairment):
        if not self.graph.has_node(impairment):
            self.graph.add_node(impairment)

    def add_edge(self, primary, consideration, text):
        if not self.graph.has_node(consideration):
            self.graph.add_node(consideration)
        self.graph.add_edge(primary, consideration, text=text)

    def serialize(self):
        from networkx.readwrite import json_graph
        return json.dumps(json_graph.node_link_data(self.graph))

    def run(self, state, config:RunnableConfig)-> Dict[str, Any]:
        primary_impairment = state.current_page.impairment
        self.add_impairment(primary_impairment)
        for consideration, info in state.node_info.items():
            standardized = state.standardized_considerations[consideration]
            text_from_manual = info if not isinstance(info, dict) else str(info)
            self.add_edge(primary_impairment, standardized, text_from_manual)
        return {
            "knowledge_graph": self.graph
        }