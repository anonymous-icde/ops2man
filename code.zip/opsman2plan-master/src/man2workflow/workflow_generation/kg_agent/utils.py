import pandas as pd
from pathlib import Path
from pydantic import BaseModel
import logging
from typing import Optional
import uuid
import logging
from typing import Any, Dict, List, Optional
import os
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from jinja2 import Environment, FileSystemLoader
from .state import PageContent



def get_relevant_data(local_data_path: str = None) -> list[PageContent]:
    if local_data_path is None:
        raise FileNotFoundError(f"The file {local_data_path} does not exist. Please add it.")
    mum_cleaned = pd.read_csv(local_data_path)
    filtered_df = mum_cleaned[mum_cleaned['component_name'].str.lower() == 'additional considerations'][['page_name', 'content']]
    filtered_df.columns = ['impairment', 'content']
    records = filtered_df.to_dict(orient='records')
    relevant_data = [PageContent(**record) for record in records]
    return relevant_data


def setup_logger(name: str, level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """Set up a logger."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

def load_jinja_prompt(template_name: str) -> ChatPromptTemplate:
    """Load a Jinja prompt template."""
    prompt_dir = Path(__file__).parent / "prompts"
    prompt = prompt_dir.joinpath(f"{template_name}.jinja2")
    
    # Create a ChatPromptTemplate with system and human messages
    return ChatPromptTemplate.from_messages([
        ("system", prompt.read_text()),
        ("human", "{{input}}")
    ], template_format="jinja2")

def get_llm(model_id: str = "gpt-4", api_key: Optional[str] = None):
    """Get an LLM instance."""
    api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
    return AzureChatOpenAI(
        azure_deployment=model_id,
        openai_api_key=api_key,
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        temperature=os.environ.get("AZURE_OPENAI_TEMPERATURE", 0.0),
        default_headers={"Ocp-Apim-Subscription-Key": os.environ.get("AZURE_OPENAI_SUBSCRIPTION_KEY", "")}
    )