import json
import os
from pathlib import Path

def load_config(config_path="../../config/config.json"):
    with open(Path(config_path), 'r') as f:
        config = json.load(f)
    return config
