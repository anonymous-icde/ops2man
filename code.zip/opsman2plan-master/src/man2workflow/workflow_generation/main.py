import argparse
import json
from pathlib import Path


from workflow_agent.utils import save_workflow, setup_logger, extract_contents

from workflow_agent.graph import WorkflowGraph


CHAPTERS_DIR = Path(__file__).resolve().parent.parent.parent.parent / "data" / "chapters"

def create_parser() -> argparse.ArgumentParser:
    """Create the command-line argument parser."""
    parser = argparse.ArgumentParser(description="Generate workflows from operational manual sections")
    parser.add_argument("--page", type=str, help="page name to process", required=False, default=None)
    parser.add_argument("--config_path", type=str, default="config/config.json", 
                       help="Path to the configuration file")
    parser.add_argument("--output_dir", type=str, default="output", 
                       help="Directory to save the generated workflow")
    parser.add_argument("--log_level", type=str, default="INFO", 
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Logging level")
    parser.add_argument("--batch", action="store_true", help="Process all pages in batch mode")
    #parser.add_argument("--api_key", type=str, help="API key for the language model")
    return parser


def main():
    """Main entry point."""
    # Parse arguments
    parser = create_parser()
    args = parser.parse_args()
    
    # Set up logger
    logger = setup_logger("WorkflowGenerator", args.log_level)
    
    
    # Load configuration
    try:
        with open(args.config_path, 'r') as f:
            config = json.load(f)
    except FileNotFoundError:
        logger.warning(f"Config file not found: {args.config_path}. Using default configuration.")
        config = {
            "model_id": "gpt-4o",
            "log_level": args.log_level
        }
    
    # Add command-line arguments to config
    config["log_level"] = args.log_level
    #if args.api_key:
    #    config["api_key"] = args.api_key
    
    # Create and run the workflow graph
    workflow_graph = WorkflowGraph(config)
    if args.batch:
        logger.info(f"running in batch mode for all impairments (pages).")

        all_docs: list[dict] = []
        # first load all the pages in MarkdownDocument format
        for p in CHAPTERS_DIR.glob("*.md"):
            all_docs.append(extract_contents(p.stem, p.read_text()))

        for doc in all_docs:
            logger.info(f"Starting workflow generation for page: {doc['page_name']}")

            with mlflow.start_span(name=f"Processing {doc['page_name']}"):
                final_workflow = workflow_graph.run(doc['page_name'], doc)
                try:
                    output_path = save_workflow(final_workflow, doc['page_name'], args.output_dir)
                    logger.info(f"Workflow for page '{doc['page_name']}' saved to: {output_path}")
                except Exception as e:
                    logger.error(f"Failed to generate workflow for page: {doc['page_name']}")
                logger.info("--------------------------------------------------")
    else:
        doc = extract_contents(args.page, (CHAPTERS_DIR / f"{args.page}.md").read_text())
        logger.info(f"Starting workflow generation for page: {args.page}")
        final_workflow = workflow_graph.run(args.page, doc)
    
        # Save the workflow
        if final_workflow:
            output_path = save_workflow(final_workflow, args.page, args.output_dir)
            logger.info(f"Workflow saved to: {output_path}")
        else:
            logger.error("Failed to generate workflow")

if __name__ == "__main__":
    # for tracking setup mlflow
    import os
    import mlflow
    import json
    
    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan graph generation")

    mlflow.langchain.autolog()
    
    with mlflow.start_run() as run:
        main()
        mlflow.flush_artifact_async_logging()