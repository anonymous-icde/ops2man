import re
import shutil
from pathlib import Path

import pandas as pd
from langchain_chroma import Chroma
from langchain_core.documents import Document

from workflow2reasoning.core.utils.llm import get_embedding_model

df = pd.read_csv("./data/manual_synthetic.csv")


def extract_1a_content(text):
    # Extract only the content inside the 1a header (not the header itself)
    match = re.search(
        r"1a[.):].*?\n(.*?)(?=^####|^###|\Z)", text, re.DOTALL | re.MULTILINE
    )
    if match:
        return match.group(1).strip()
    return ""


df = df.reset_index(drop=True)
filter1 = df["component_name"] == "General Information"
df = df[filter1].copy()

df["1a_content"] = df["content"].apply(extract_1a_content)
df["concept_definitions"] = df.apply(
    lambda row: f"Impairment-name: {row['page_name']}.\nInfo: {row['1a_content']}",
    axis=1,
)

embedding = get_embedding_model()

output_path = Path(__file__).parent.parent / "output" / "rxlookup_chroma_db"

if output_path.exists():
    print("Removing existing directory:", output_path)
    shutil.rmtree(output_path)

vector_store = Chroma(
    collection_name="rxlookup",
    embedding_function=embedding,
    persist_directory=output_path.resolve(),
)
doc_list = []

for idx, row in df.iterrows():
    doc = Document(
        page_content=row["concept_definitions"],
        metadata={"page_name": row["page_name"], "id": idx + 1},
    )
    doc_list.append(doc)

vector_store.add_documents(doc_list, ids=[str(doc.metadata["id"]) for doc in doc_list])

print("Indexing completed and saved to:", output_path)
