
import logging
import networkx as nx
from kg_agent.config import load_config
from kg_agent.utils import get_relevant_data
from kg_agent.state import KGState
from kg_agent.agents.edge_extractor_agent import EdgeExtractorAgent
from kg_agent.agents.standardizer_agent import StandardizerAgent
from kg_agent.agents.kg_builder_agent import KGBuilderAgent
from networkx.readwrite import json_graph
import json
import argparse

from kg_agent.graph import KGGraph


def create_parser() -> argparse.ArgumentParser:
    """Create the command-line argument parser."""
    parser = argparse.ArgumentParser(description="Generate workflows from operational manual sections")
    parser.add_argument("--page", type=str, help="page name to process")
    parser.add_argument("--manual_path", type=str, default="data/operational_manual.csv", 
                       help="Path to the operational manual CSV file")
    parser.add_argument("--config_path", type=str, default="config/config.json", 
                       help="Path to the configuration file")
    parser.add_argument("--output_dir", type=str, default="output", 
                       help="Directory to save the generated workflow")
    parser.add_argument("--log_level", type=str, default="INFO", 
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Logging level")
    parser.add_argument("--batch", action="store_true", help="Process all pages in batch mode")
    #parser.add_argument("--api_key", type=str, help="API key for the language model")
    return parser

def run_kg_pipeline():
    parser = create_parser()
    args = parser.parse_args()
    
    config = load_config(args.config_path)
    relevant_data = get_relevant_data(args.manual_path)
    standard_impairment_names = [r.impairment for r in relevant_data]
    logger = logging.getLogger('KGMain')
    current_knowledge_graph = nx.DiGraph()
    for page in relevant_data:
        KgGraph = KGGraph(config=config, 
                          relevant_data=relevant_data,
                          standard_impairment_names=standard_impairment_names,
                          current_knowledge_graph=current_knowledge_graph)
        single_page_final_state = KgGraph.run(page=page, 
                                              current_knowledge_graph=current_knowledge_graph)
        # update current_knowledge_graph
        current_knowledge_graph = single_page_final_state.knowledge_graph

    # Save to local file as JSON
    
    graph_data = json_graph.node_link_data(current_knowledge_graph)
    with open("knowledge_graph.json", "w") as f:
        json.dump(graph_data, f, indent=2)
    logger.info("Knowledge graph saved to knowledge_graph.json.")

if __name__ == "__main__":
    run_kg_pipeline()