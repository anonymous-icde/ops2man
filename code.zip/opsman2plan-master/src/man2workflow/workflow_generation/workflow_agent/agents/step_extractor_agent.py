import json
from typing import Dict, Any

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, WorkflowStep, Message
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class StepExtractorAgent:
    """Agent that extracts workflow steps from segments."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "StepExtractorAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("step_extractor_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Extract workflow steps from annotated segments."""
        self.logger.info("Extracting workflow steps from segments")
        
        if not state.segments:
            self.logger.warning("No segments available for step extraction")
            return {
                "messages": [
                    Message(
                        from_agent=self.name,
                        to_agent="AnnotatorAgent",
                        content="Need segments before extracting steps"
                    )
                ]
            }
        
        # Check if we're in a refinement loop
        is_refinement = len(state.steps) > 0
        
        # Prepare input with any relevant messages 
        relevant_messages = [
            msg.content for msg in state.messages 
            if msg.to_agent == self.name
        ]
        
        # Get both document contents
        general_info_doc = state.documents.get("general_info", None)
        
        input_data = {
            "manual_section": state.manual_section,
            "segments": [s.model_dump() for s in state.segments],
            "general_info_content": general_info_doc.content if general_info_doc else "",
            "existing_steps": [s.model_dump() for s in state.steps] if is_refinement else [],
            "is_refinement": is_refinement,
            "messages": relevant_messages
        }
        
        # Extract steps
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})

        # Process the extracted steps
        steps = []
        for i, step_data in enumerate(result.get("steps", [])):
            segment_ids = step_data.get("segment_ids")

            content = [s.content for s in state.segments if s.segment_id in segment_ids]

            step = WorkflowStep(
                step_id=i + 1 + (state.steps[-1].step_id if is_refinement and state.steps else 0),
                description=step_data["description"],
                segment_ids=segment_ids,
                text_from_manual=content
            )
            steps.append(step)
        
        self.logger.info(f"Extracted {len(steps)} workflow steps")
        
        # Check if the agent thinks the extraction is complete
        is_complete = result.get("is_complete", False)
        
        # If not, add a message requesting refinement
        messages = []
        if not is_complete:
            messages.append(
                Message(
                    from_agent=self.name,
                    to_agent=self.name,  # Self-message for refinement
                    content=result.get("refinement_needed", "Step extraction needs refinement")
                )
            )
            
        return {
            "steps": steps if not is_refinement else state.steps + steps,
            "extraction_complete": is_complete,
            "extractor_state": {
                "status": "complete" if is_complete else "needs_refinement",
                "iteration": state.extractor_state.get("iteration", 0) + 1,
                
            },
            "messages": messages
        }

    def refine(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Refine the extracted steps."""
        return self.run(state, config)