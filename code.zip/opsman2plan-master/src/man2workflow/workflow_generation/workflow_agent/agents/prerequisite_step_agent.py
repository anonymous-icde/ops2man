from typing import Dict, Any, List

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, Segment, Message, WorkflowStep
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

import json

class PrerequisiteAgent:
    """Agent that determines prerequisite steps for a workflow."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "PrerequisiteAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("prerequisite_step")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Run the annotator agent to segment documents into meaningful parts."""
        self.logger.info("Starting document annotation")
        
        # Check if there are already segments and we're in a refinement loop
        is_refinement = len(state.segments) > 0
        
        # Get the rating document
        rating_doc = state.documents.get("rating")
        general_info_doc = state.documents.get("general_info")
        
        if not rating_doc or not rating_doc.content:
            self.logger.error("Rating documents are required for annotation")
            raise ValueError("Rating documents are required for annotation")
        
        if not general_info_doc or not general_info_doc.content:
            self.logger.error("General Information documents are required for annotation")
            raise ValueError("General Information documents are required for annotation")

        # commenting out the check as anyway the planner agent's updated plan is not being passed down
        # if not rating_doc or not rating_doc.content:
        #     self.logger.warning("No rating document found, cannot annotate")
        #     return {
        #         "messages": [
        #             Message(
        #                 from_agent=self.name,
        #                 to_agent="PlannerAgent",
        #                 content="Cannot annotate: No rating document found"
        #             )
        #         ]
        #     }
        

        input_data = {
            "impairment_name": state.manual_section,
            "steps": [s.model_dump() for s in state.steps],
            "general_info": general_info_doc.content,
        }
        
        # Generate annotations
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})
        
        if result['needs_prerequisite_step']:
            self.logger.info(f"Prerequisite step needed")
            state.steps.insert(0, WorkflowStep(
                step_id=0,
                description=result['prerequisite_step']['description'],
                segment_ids=[],
                text_from_manual=[result['prerequisite_step']['content']]
            ))
        else:
            self.logger.info(f"No prerequisite step needed")

        return {
            "steps": state.steps
        }

    def refine(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Refine the existing segmentation."""
        return self.run(state, config)