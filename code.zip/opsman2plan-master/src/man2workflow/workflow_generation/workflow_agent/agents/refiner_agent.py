from typing import Dict, Any, List

from langchain_core.output_parsers import JsonOutputParser
from langchain_core.runnables.config import RunnableConfig

from workflow_agent.state import WorkflowState, WorkflowStep, Message
from workflow_agent.utils import load_jinja_prompt, get_llm, setup_logger

class RefinerAgent:
    """Agent that refines and improves workflow steps."""
    
    def __init__(self, config: Dict[str, Any]):
        self.name = "RefinerAgent"
        self.config = config
        self.logger = setup_logger(self.name, config.get("log_level", "INFO"))
        self.llm = get_llm(config.get("model_id"), config.get("api_key"))
        self.prompt = load_jinja_prompt("refiner_prompt")
        self.parser = JsonOutputParser()
    
    def run(self, state: WorkflowState, config: RunnableConfig) -> Dict[str, Any]:
        """Refine and improve the workflow steps."""
        self.logger.info("Refining workflow steps")
        
        if not state.steps:
            self.logger.warning("No steps available to refine")
            return {
                "messages": [
                    Message(
                        from_agent=self.name,
                        to_agent="StepExtractorAgent",
                        content="Need workflow steps before refinement"
                    )
                ]
            }
        
        # Get relevant segments for each step
        steps_with_segments = []
        for step in state.steps:
            step_segments = [s for s in state.segments if s.segment_id in step.segment_ids]
            steps_with_segments.append({
                "step": step.dict(),
                "segments": [s.dict() for s in step_segments]
            })
        
        # Prepare input with any relevant messages
        relevant_messages = [msg.content for msg in state.messages if msg.to_agent == self.name]
        
        input_data = {
            "manual_section": state.manual_section,
            "steps_with_segments": steps_with_segments,
            "messages": relevant_messages,
            "iteration": state.refiner_state.get("iteration", 0)
        }
        
        # Refine steps
        chain = self.prompt | self.llm | self.parser
        result = chain.invoke({"input": input_data})
        
        print("*********", result.get("refined_steps", []))
        # Process the refined steps
        refined_steps = []
        for step_data in result.get("refined_steps", []):
            step = WorkflowStep(
                step_id=step_data["id"],
                description=step_data["description"],
                segment_ids=step_data.get("segment_ids", []),
                details=step_data.get("details", ""),
                ratings=step_data.get("ratings", {}),
                references=step_data.get("references", [])
            )
            refined_steps.append(step)
        
        self.logger.info(f"Refined {len(refined_steps)} workflow steps")
        
        # Check if the agent thinks the refinement is complete
        is_complete = result.get("is_complete", False)
        
        # If not, add a message requesting further refinement
        messages = []
        if not is_complete:
            messages.append(
                Message(
                    from_agent=self.name,
                    to_agent=self.name,  # Self-message for further refinement
                    content=result.get("refinement_needed", "Steps need further refinement")
                )
            )
        
        return {
            "steps": refined_steps,  # Replace with refined steps
            "refinement_complete": is_complete,
            "refiner_state": {
                "status": "complete" if is_complete else "needs_refinement",
                "iteration": state.refiner_state.get("iteration", 0) + 1,
                "changes": result.get("changes", [])
            },
            "messages": messages
        }