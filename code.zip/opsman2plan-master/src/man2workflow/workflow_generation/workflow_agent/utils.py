import os
import json
import re
import uuid
import logging
from pathlib import Path
from typing import Dict, Optional

import pandas as pd
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate


def setup_logger(name: str, level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """Set up a logger."""
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Remove all existing handlers safely
    for handler in list(logger.handlers):  # Use a copy of the list to avoid modification during iteration
        logger.removeHandler(handler)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    logger.propagate = False  # Prevent log messages from being propagated to the root logger

    return logger

def load_jinja_prompt(template_name: str) -> ChatPromptTemplate:
    """Load a Jinja prompt template."""
    prompt_dir = Path(__file__).parent / "prompts"
    prompt = prompt_dir.joinpath(f"{template_name}.jinja2")
    
    # Create a ChatPromptTemplate with human messages
    return ChatPromptTemplate.from_messages([
        ("human", prompt.read_text()),
    ], template_format="jinja2")

def get_llm(model_id: str = "gpt-4", api_key: Optional[str] = None):
    """Get an LLM instance."""
    #print(model_id, api_key, os.environ.get("AZURE_OPENAI_ENDPOINT"))
    api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
    return AzureChatOpenAI(
        azure_deployment=model_id,
        openai_api_key=api_key,
        azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        temperature=os.environ.get("AZURE_OPENAI_TEMPERATURE", 0.0) if model_id != 'gpt-5' else 1,
        default_headers={"Ocp-Apim-Subscription-Key": os.environ.get("AZURE_OPENAI_SUBSCRIPTION_KEY", "")}
    )

def extract_contents(page, content) -> dict:
    pattern = r"(?:###|##) \d+\. General Information(.*?)(?:###|##) \d+\. Rating(.*?)(?:(?:###|##) \d+\. Additional Considerations(.*?))?$"
    matches = re.search(pattern, content, re.DOTALL)

    try:
        general_info = matches.group(1).strip()
        rating_info = matches.group(2).strip()
    except AttributeError:
        raise ValueError(f"Failed to parse content for page '{page}'. Please check the markdown format.")
    additional_info = matches.group(3).strip() if matches.lastindex >= 3 else None

    return dict(
        page_name=page.replace("(", "\\(").replace(")", "\\)"),
        general_information=general_info,
        rating=rating_info,
        additional_considerations=additional_info
    )

def load_manual_page(page_name: str, dataframe: pd.DataFrame) -> Dict[str, str]:
    """Load a page from the operational manual."""
    page_df = dataframe[dataframe["page_name"].str.contains(page_name, case=False)]
    
    if page_df.empty:
        raise ValueError(f"page '{page_name}' not found in the operational manual")
    
    result = {}
    
    # Get rating page
    rating_df = page_df[page_df["component_name"] == "Rating"]
    if not rating_df.empty:
        result["rating"] = rating_df.iloc[0]["content"]
    else:
        result["rating"] = ""
    
    # Get general information page
    general_df = page_df[page_df["component_name"] == "General Information"]
    if not general_df.empty:
        result["general_info"] = general_df.iloc[0]["content"]
    else:
        result["general_info"] = ""
    
    return result


def generate_id():
    """Generate a short unique ID."""
    return str(uuid.uuid4())[:8]
    
def save_workflow(workflow, page_name: str, output_dir: str = "output"):
    """Save a workflow to a JSON file."""
    def _extract_workflow_state(state):
        """Extract only the steps and manual_section from WorkflowState."""
        return {
            "manual_section": state.manual_section,
            "steps": [step.model_dump() for step in state.steps]
        }
    
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True, parents=True)
    
    filename = f"{page_name.lower().replace(' ', '_')}_workflow.json"
    file_path = output_path / filename

    
    with open(file_path, "w") as f:
        json.dump(_extract_workflow_state(workflow), f, indent=2)
    
    return file_path