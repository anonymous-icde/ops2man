import functools
import sys
from logging import LogRecord
from pathlib import Path

from loguru import logger as log


def _log_format_selector(record: LogRecord):
    # check if record has extra attribute
    if "extra" in record and len(record["extra"]) > 0:
        parsed_record = " || ".join(
            [f"{key}={value}" for key, value in record["extra"].items()]
        )
        record["extra"] = {"_parsed_rc": parsed_record, **record["extra"]}
        return "<level>{level: <8}</level> | <green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | {extra[_parsed_rc]} | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>\n"
    else:
        return "<level>{level: <8}</level> | <green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>\n"


def init_logger(level: str = "DEBUG", log_file_path: Path = None):
    try:
        log.remove(0)  # Remove the default logger to avoid duplicate logs
    except ValueError:
        pass  # Default logger has already been removed; this happens with pytest as there may be multiple calls to init_logger
    log.add(
        sink=sys.stdout,
        colorize=True,
        format=_log_format_selector,
        backtrace=True,
        diagnose=True,
        level=level,
    )

    if log_file_path is not None:
        log.add(
            sink=log_file_path.as_posix(),
            format=_log_format_selector,
            backtrace=True,
            diagnose=True,
            level=level,
        )
    log.debug(f"Logging has been initialized, log level is set to {level}")


def deprecated(message: str = None):
    """Print a warning message when the function is called that is deprecated.

    Args:
        message (str, optional): message to be included as part of the warning. Defaults to None.
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            log.warning(
                f"{f'{message} ' if message else ''}Function: {func.__name__} is deprecated.",
                DeprecationWarning,
                stacklevel=2,
            )
            return func(*args, **kwargs)

        return wrapper

    return decorator
