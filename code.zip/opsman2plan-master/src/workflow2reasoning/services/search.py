import os

from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient

from workflow2reasoning.utils import require

IMPAIRMENT_INDEX_NAME = require("APP_IMPAIRMENT_INDEX_NAME")


def get_credential():
    """Get the credential for Azure Search."""
    if "AZURE_SEARCH_API_KEY" in os.environ:
        return AzureKeyCredential(os.environ["AZURE_SEARCH_API_KEY"])
    else:
        return DefaultAzureCredential()


def get_client() -> SearchIndexClient:
    """Get the search index client client for Azure Search."""
    if "AZURE_SEARCH_SERVICE_ENDPOINT" not in os.environ:
        raise ValueError(
            "AZURE_SEARCH_SERVICE_ENDPOINT is not set! Please set the environment variable to the right AI Search instance"
        )
    client = SearchIndexClient(
        endpoint=os.environ["AZURE_SEARCH_SERVICE_ENDPOINT"],
        credential=get_credential(),
    )
    return client


def get_search(name: str) -> SearchClient:
    """Get the search client for Azure Search."""
    if "AZURE_SEARCH_SERVICE_ENDPOINT" not in os.environ:
        raise ValueError(
            "AZURE_SEARCH_SERVICE_ENDPOINT is not set! Please set the environment variable to the right AI Search instance"
        )
    client = SearchClient(
        endpoint=os.environ["AZURE_SEARCH_SERVICE_ENDPOINT"],
        credential=get_credential(),
        index_name=name,
    )
    return client
