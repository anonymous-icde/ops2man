import os

from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

AZURE_STORAGE_CONTAINER_NAME = os.getenv(
    "AZURE_STORAGE_CONTAINER_NAME", "underwriting-data"
)
AZURE_STORAGE_ACCOUNT_URL = os.getenv(
    "AZURE_STORAGE_ACCOUNT_URL", "https://ihubuwsynuatadls.blob.core.windows.net"
)


def get_data_from_container(
    filename: str,
    container_name: str = AZURE_STORAGE_CONTAINER_NAME,
    account_url: str = AZURE_STORAGE_ACCOUNT_URL,
):
    """Fetch data from Azure Blob Storage container."""
    credential = DefaultAzureCredential()

    # Create the BlobServiceClient object
    blob_service_client = BlobServiceClient(account_url, credential=credential)
    container_client = blob_service_client.get_container_client(
        container=container_name
    )

    # Download the blob data
    blob_client = container_client.get_blob_client(filename)
    blob_data = blob_client.download_blob().readall()
    blob_data_str = blob_data.decode("utf-8", errors="replace")
    return blob_data_str
