import os
import warnings
from pathlib import Path

from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from langchain.chat_models import init_chat_model
from langchain_core.exceptions import OutputParserException
from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import (
    PydanticOutputParser,
)
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langchain_openai import AzureOpenAIEmbeddings
from openai import InternalServerError, RateLimitError
from pydantic import BaseModel

from workflow2reasoning.core.config import MAX_RETRIES_FOR_CHAINS
from workflow2reasoning.core.utils.prompt import read_template


def get_llm_model(
    deployment_name: str, temperature=0, seed=42, **kwargs
) -> BaseChatModel:
    """Get the LLM model deployment using the deployment_name.

    It will use the provided credentials in the environment variables.

    Args:
        deployment_name (str): deployment model name
        temperature (float, optional): Sampling temperature for the model. Defaults to 0.
        seed (int, optional): Random seed for reproducibility. Defaults to 42.
        **kwargs: additional arguments

    Returns:
        BaseLLM: LLM model object
    """
    if deployment_name == "azure_openai:gpt-5":
        temperature = 1 # it only works with temperature 1
    return init_chat_model(deployment_name, temperature=temperature)


def get_embedding_model(deployment_name: str, **kwargs):
    """Get the embedding model using Azure OpenAI services.

    Args:
        deployment_name (str): The name of the Azure OpenAI deployment to use.
        **kwargs: Additional keyword arguments to pass to the `AzureOpenAIEmbeddings` initializer.

    Returns:
        Embeddings: An instance of the `AzureOpenAIEmbeddings` class configured
        with the specified deployment and authentication method.
    """
    if deployment_name is None:
        deployment_name = os.getenv(
            "AZURE_OPENAI_DEPLOYMENT_NAME_EMBEDDING",
            "text-embedding-ada-002-2-defaultv2-standard",
        )

    if subscription_key := os.getenv("AZURE_OPENAI_SUBSCRIPTION_KEY"):
        warnings.warn(
            "AZURE_OPENAI_SUBSCRIPTION_KEY is not set, will not be setting that as part of ongoing requests."
        )

    if "AZURE_OPENAI_API_KEY" in os.environ:
        # Using the provided API key to authenticate
        return AzureOpenAIEmbeddings(azure_deployment=deployment_name, **kwargs)
    else:
        credential = DefaultAzureCredential()
        token_provider = get_bearer_token_provider(
            credential, "https://cognitiveservices.azure.com/.default"
        )
        return AzureOpenAIEmbeddings(
            azure_deployment=deployment_name,
            azure_ad_token_provider=token_provider,
            default_headers={"Ocp-Apim-Subscription-Key": subscription_key}
            if subscription_key
            else {},
            **kwargs,
        )


def get_chain_with_retry(
    prompt_path: Path,
    output_format: type[BaseModel],
    model_name: str,
    max_retries: int = MAX_RETRIES_FOR_CHAINS,  # so a wait time of 2^8 = 256 seconds at most
) -> Runnable:
    """Create a Runnable from Langchain that retries in case of specific errors that might happen during LLM call and parsing its output.

    Args:
        prompt_path (Path): The file path to the prompt template.
        output_format (BaseModel): The expected output format as a Pydantic model.
        model_name (str, optional): The name of the language model deployment.
            Defaults to MODEL_NAME.
        max_retries (int, optional): The maximum number of retry attempts in case of
            exceptions. Defaults to 6.

    Returns:
        RunnableRetry: A Runnable that retries in case of specific exceptions.
    """
    model = get_llm_model(deployment_name=model_name)
    prompt_template: ChatPromptTemplate = read_template(prompt_path)
    parser = PydanticOutputParser(pydantic_object=output_format)
    completion_chain = prompt_template | model | parser
    completion_chain = completion_chain.with_retry(
        retry_if_exception_type=(
            OutputParserException,
            RateLimitError,
            InternalServerError,
        ),
        stop_after_attempt=max_retries,
        wait_exponential_jitter=True,
    )
    return completion_chain
