from workflow2reasoning.core.model.alerting import Alert, AlertTypes
from workflow2reasoning.core.model.state import (
    AllRatingsIncrement,
    ConstrainedRatingsWithMetaInfo,
    RunningRatings,
)
from workflow2reasoning.logger import log


def get_step_rating_alerts(
    constrained_ratings: list[ConstrainedRatingsWithMetaInfo], source: str
) -> list[Alert]:
    all_alerts = []
    for s in constrained_ratings:
        for (
            field_name,
            field_value,
        ) in s.model_dump().items():
            if (
                (
                    field_name
                    in ["IC", "RMD", "range", "additional_charges", "above_standard"]
                )
                and field_value["applicable"]
                and field_value["alert"]
            ):
                if field_name == "IC":
                    alert = Alert(
                        type=AlertTypes.RATING_CONSIDERATION,
                        title="IC",
                        source=source,
                        description=field_value["alert"],
                    )
                elif field_name == "RMD":
                    alert = Alert(
                        type=AlertTypes.RATING_CONSIDERATION,
                        title="RMD",
                        source=source,
                        description=field_value["alert"],
                    )
                elif field_name == "range":
                    alert = Alert(
                        type=AlertTypes.RANGE,
                        title=field_value["alert"],
                        source=source,
                    )
                elif field_name == "additional_charges":
                    alert = Alert(
                        type=AlertTypes.ADDITIONAL_CHARGES,
                        title=field_value["alert"],
                        source=source,
                    )
                elif field_name == "above_standard":
                    alert = Alert(
                        type=AlertTypes.ABOVE_STANDARD,
                        title=field_value["alert"],
                        source=source,
                    )
                else:
                    log.error(f"Field name '{field_name}' should not be an alert.")

                all_alerts.append(alert)
    return all_alerts


def combine_ratings(ratings: list[AllRatingsIncrement]) -> RunningRatings:
    all_ratings_increments = {
        category: [] for category in ["life_rating", "ltc", "wp", "adb"]
    }

    min_life_rating = None
    for rating_increment in ratings:
        if rating_increment.min_rating != "N/A":
            min_life_rating = rating_increment.min_rating

        for category in all_ratings_increments.keys():
            rating_increment_value = getattr(rating_increment, category)
            rating_increment_value = (
                "0" if rating_increment_value == "STD" else rating_increment_value
            )
            all_ratings_increments[category].append(rating_increment_value)

    final_ratings = {category: "N/A" for category in ["life", "ltc", "wp", "adb"]}
    for category, category_increments in all_ratings_increments.items():
        if any(rating == "Decline" for rating in category_increments):
            final_ratings[category] = "Decline"
        elif any(rating == "Postpone" for rating in category_increments):
            final_ratings[category] = "Postpone"
        elif all(rating == "N/A" for rating in category_increments):
            final_ratings[category] = "N/A"
        elif category == "ltc" and "life" in "".join(category_increments).lower():
            # If LTC rating contains LIFE rating, set LTC to LIFE
            final_ratings[category] = final_ratings["life_rating"]
        else:

            def transform(x):
                return (
                    float(x[:-1])
                    if (x.endswith("x") or x.endswith("X"))
                    else int(float(x))
                )

            final_ratings[category] = str(
                sum(
                    transform(rating)
                    for rating in category_increments
                    if rating != "N/A"
                )
            )

            if min_life_rating is not None and category == "life_rating":
                try:
                    final_ratings[category] = str(
                        max(int(final_ratings[category]), int(min_life_rating))
                    )
                except ValueError:
                    log.error(
                        f"Error converting min life rating to int: {min_life_rating}"
                    )  # do not fail if the conversion fails due to non constrained min life rating

            final_ratings[category] = (
                final_ratings[category] + "x"
                if category in ["wp", "adb"]
                else final_ratings[category]
            )

    return RunningRatings(**final_ratings)


def sum_ratings(ratings: list[str]) -> str:
    """Sum the ratings in the list. If any rating is "Decline" or "Postpone", return that rating.
    If all ratings are "N/A", return "N/A". Otherwise, sum the ratings and return the result.
    """
    if len(ratings) == 0:
        return "0"

    if any(rating == "Decline" for rating in ratings):
        return "Decline"
    elif any(rating == "Postpone" for rating in ratings):
        return "Postpone"
    elif all(rating == "N/A" for rating in ratings):
        return "N/A"
    else:

        def transform(x):
            return float(x[:-1]) if (x.endswith("x") or x.endswith("X")) else int(x)

        return str(sum(transform(rating) for rating in ratings if rating != "N/A"))


def max_ratings(ratings: list[str]) -> str:
    """Max the ratings in the list. If any rating is "Decline" or "Postpone", return that rating.
    If all ratings are "N/A", return "N/A". Otherwise, sum the ratings and return the result.
    """
    if len(ratings) == 0:
        return "0"

    if any(rating == "Decline" for rating in ratings):
        return "Decline"
    elif any(rating == "Postpone" for rating in ratings):
        return "Postpone"
    elif all(rating == "N/A" for rating in ratings):
        return "N/A"
    else:

        def transform(x):
            return float(x[:-1]) if (x.endswith("x") or x.endswith("X")) else int(x)

        return str(max(transform(rating) for rating in ratings if rating != "N/A"))


def num_to_percentage(rating: str) -> str:
    """Convert a rating to a percentage string.
    using formulae: (rating + 100) to nearest mulitple of 25
    """
    if rating == "N/A":
        return "N/A"
    elif rating == "Decline":
        return "Decline"
    elif rating == "Postpone":
        return "Postpone"
    else:
        rating = int(rating)
        if rating > 100:
            return ">200%"
        elif rating < 25:
            return "standard"
        else:
            # Round to the nearest multiple of 25
            rating = rating + 100
            rounded_rating = round(rating / 25) * 25
            return f"{rounded_rating}%"
