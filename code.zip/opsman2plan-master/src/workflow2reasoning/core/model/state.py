import re
from datetime import date
from enum import Enum, StrEnum
from typing import Annotated, Any, Optional

from langchain_core.exceptions import OutputParserException
from pydantic import BaseModel, Field, field_validator

from workflow2reasoning.core.model.alerting import Alert
from workflow2reasoning.core.utils.reducers import add_unique, merge, update_list

# region: Underwriting Agent State


class UnderwritingAgentInputState(BaseModel):
    email: str


class UnderwritingAgentOutputState(BaseModel):
    email: str
    overall_rating: dict[str, str]
    trace: dict[str, dict[str, str]]
    impairments: Annotated[list[str], add_unique] = []
    risk_factor_trace: Annotated[dict[str, Any], merge] = {}
    alerts: Annotated[list[Alert], add_unique] = []
    generated_email: str | None = None


# endregion

# region: Redaction Agent


class RedactionAgentInput(BaseModel):
    email: str


class RedactionAgentOutput(BaseModel):
    redacted_email: str | None
    termination_reason: str | None


# endregion

# region: Profiling Agent


class ProfilingAgentInput(BaseModel):
    medical_summary: str


class ProfilingAgentOutput(BaseModel):
    profile: dict[str, Any]  # TODO: Update this to a more specific type if possible


class SmokingStatus(StrEnum):
    SMOKER = "SMOKER"
    NON_SMOKER = "NON-SMOKER"
    UNKNOWN = "UNKNOWN"


class ProductType(StrEnum):
    TERM = "term"
    PERM = "perm"
    TERM_PERM = "term_perm"


class Profile(BaseModel):
    age: Optional[str] = Field(
        default=None,
        description="""The age of the person if mentioned. If the age is a range, give the range in the format 'min-max',
                    where min and max are the minimum and maximum ages in integer respectively.
                    Consider the following examples: 44/45 converts to 44-45
                    57 or 58 years old converts to 57-58""",
    )
    date_of_birth: Optional[date] = Field(
        default=None,
        description="""The date of birth of the person if mentioned. Format should be YYYY-MM-DD.
        Consider the following examples:
        1. January 1, 2000 converts to 2000-01-01
        2. Feb 1996 converts to 1996-02-01
        3. 1994 converts to 1994-01-01
        """,
    )
    gender: Optional[str] = Field(
        default=None,
        description="""Gender of the person, if mentioned, it should ONLY be output as ```Male```,```Female``` or ```Other```.
        Consider the following examples:
        1) "old gentleman" converts to ```Male```
        2) "young lady" converts to ```Female```
        3) "young person" converts to ```Other```
        """,
    )
    height: Optional[int] = Field(
        default=None,
        description="""Height of the person in INCHES.
        If the height is mentioned in feet <'> and inches <">, Please convert the height into inches
        and output the result in INTEGER only.
        If the height is mentioned in cm, please convert it to inches and output the result in INTEGER only.
        Consider the following examples:
        1.  ```client's height is 5 feet 6 inches``` converts to 66
        2.  ```client's height is 5'``` converts to 60
        3.  ```his height is 5'6"``` converts to 66
        4.  ```his height is 167cm``` converts to 66
        """,
    )
    weight: Optional[int] = Field(
        default=None,
        description="""Weight of the person in POUNDS.
        If the weight is mentioned in kg, please convert it to pounds and output the result in INTEGER only.
        Consider the following examples:
        1. ```150 pounds``` converts to 150
        2. ```145 lbs``` converts to 145
        2. ```70kg``` converts to 154
        """,
    )
    BMI: Optional[float] = Field(
        default=None,
        description="""BMI of the person. If the BMI is mentioned in the text, please output it as a float.""",
    )

    smoking_status: Optional[SmokingStatus] = Field(
        default=None,
        description="""Smoking status of the person. return 3 string ```SMOKER``` or ```NON-SMOKER```, or  ``UNKNOWN``.
        Consider the following GUIDELINES:
        * If the email states that the applicant is a smoker, return ```SMOKER```.
        * If the applicant has only limited cigar or pipe use, or 12 or fewer cigars per year, return ```NON-SMOKER```.
        * If only ``smokeless tobacco`` or ``nicotine product`` is used, such as ``nicotine pouch, gel or Zyn``, set the smoking_status to ```NON-SMOKER```.
        * If the applicant used ``cigarettes`` (including e-cigarettes or vaping), ``water pipe``, or ``hookah`` in the last 12 months, including ``e-cigarettes`` or ``vaping``, set the smoking_status to ```SMOKER```.
        * If the applicant uses ``marijuana`` for recreation by smoking or vaping, smoking_status is ```NON-SMOKER``` if the applicant uses marijuana occasionally, or once per month or less. Set the smoking_status to ```SMOKER``` if the applicant uses marijuana more than once per month.
        * If the applicant uses ``marijuana`` for recreation by ingesting, set the smoking_status to ```NON-SMOKER```.
        * If the applicant uses ``marijuana`` for medical purposes, set the smoking_status to ```NON-SMOKER``` if ingesting, and ```SMOKER``` if smoking or vapping.
        * If smoking is NOT Mentioned in the email, set the smoking_status to ```UNKNOWN```.
        """,
    )

# endregion

# region: Impairment Agent


class RiskFactorAgentInput(BaseModel):
    # TODO: Add fields here (if any)
    redacted_email: str


class RiskFactorAgentOutput(BaseModel):
    impairments: Annotated[list[str], update_list] = []
    alerts: Annotated[list[Alert], update_list]
    mappings: Annotated[dict[str, str], merge] = {}
    risk_factor_trace: dict[str, Any] = {}
    termination_reason: str | None = None


# endregion

# region: models common to process graph and knowledge graph execution


# Model for the `execute_next_step` node.
class StepOutput(BaseModel):
    # Represents the raw output and reasoning for a step.
    step_reasoning: str
    step_raw_rating: str
    is_relevant: bool

    @field_validator("step_raw_rating", mode="before")
    def convert_dict_to_str(cls, value):
        """Convert a dictionary or list to a string if the LLM returns such a format."""
        if isinstance(value, dict):
            return ", ".join(
                f"{key}: {val}" for key, val in value.items()
            )  # Convert dict to string
        if isinstance(value, list):
            return str(value)  # Convert list to string
        return value  # Return as-is if it's already a string


# Model representing the metadata for a rating. For e.g., the reasoning behind why a rating is considered as an IC, range, etc.
class RatingMetaInfo(BaseModel):
    # Represents metadata about a rating, including reasoning, applicability, and any associated alert.
    reasoning: str
    applicable: bool
    alert: str | None

    @classmethod
    def default(cls) -> "RatingMetaInfo":
        """Provide default values for the RatingMetaInfo model."""
        return cls(
            reasoning="N/A",
            applicable=False,
            alert="N/A",
        )


class AllRatingsIncrement(BaseModel):
    # Represents incremental ratings for various categories (e.g., LIFE, LTC, WP, ADB).
    # So after all constraints are applied, each category can only have the following kinds of values:
    # - "Decline"
    # - "Postpone"
    # - "N/A"
    # - "STD"
    # - "x" (float values with an 'x' suffix, e.g., 1.5x or 2.0x) # this is for ADB and WP
    # - "x" (integer values in string form, e.g., "+60") # assumption is LIFE and LTC ratings will always be here

    reasoning: str
    life_rating: str
    ltc: str
    wp: str
    adb: str
    min_rating: str

    @classmethod
    def default(cls) -> "AllRatingsIncrement":
        """Provide default values for the AllRatingsIncrement model."""
        return cls(
            reasoning="N/A",
            life_rating="N/A",
            ltc="N/A",
            wp="N/A",
            adb="N/A",
            min_rating="N/A",
        )

    @field_validator("life_rating", "ltc", "wp", "adb", "min_rating", mode="before")
    def validate_rating(cls, value, info):
        """Validate the rating value to ensure it is in the correct format."""
        if value in ["Decline", "Postpone", "N/A", "STD"]:
            return value

        # Allow float values with an 'x' suffix (e.g., 1.5x or 2.0x).
        if re.fullmatch(r"(\d+(\.\d+)?)[xX]", value):
            return value

        # Allow cases where LTC rating is derived from LIFE rating.
        if info.field_name == "ltc" and "life" in value.lower():
            return value

        # If the value contains any of the keywords as a substring, use the default value
        if any(
            keyword in value.lower() for keyword in ["pref", "std", "standard", "super"]
        ):
            return "+0"  # the constrained rating is +0, but we do add an alert for categories above standard

        try:
            int(float(value))  # Check if the value can be converted to an integer.
            return value
        except OutputParserException:
            raise OutputParserException(
                "Rating must be one of the following: 'STD', 'Decline', 'Postpone', 'N/A', "
                "an integer in string form, or a float in string form with an 'x' suffix."
            )


# Model for the `parse_step_rating` node.
class ConstrainedRatingsWithMetaInfo(BaseModel):
    # Represents constrained ratings with additional metadata for various categories.
    final_constrained_ratings: AllRatingsIncrement
    non_rating: RatingMetaInfo
    regular_rating: RatingMetaInfo
    IC: RatingMetaInfo
    range: RatingMetaInfo
    RFC: RatingMetaInfo
    RMD: RatingMetaInfo
    additional_charges: RatingMetaInfo
    above_standard: RatingMetaInfo
    rate_as_other_impairment: RatingMetaInfo

    @classmethod
    def default(cls) -> "ConstrainedRatingsWithMetaInfo":
        """Provide default values for the ConstrainedRatingsWithMetaInfo model."""
        return cls(
            **{
                field_name: field.annotation.default()
                for field_name, field in cls.model_fields.items()
            }
        )

    def __str__(self) -> str:
        """Return a string representation of the model."""
        applicable_ratings = {
            key: value
            for key, value in self.final_constrained_ratings.model_dump().items()
            if value != "N/A"
        }
        applicable_meta_info = {
            key: value
            for key, value in self.model_dump().items()
            if isinstance(value, RatingMetaInfo) and value.applicable
        }
        return f"Applicable Ratings: {applicable_ratings}, Applicable Meta Info: {applicable_meta_info}"


# Model for the running ratings.
# This model stores the cumulative ratings for the impairment being processed.
# It is updated at each step of the graph execution and is used to generate the final output of the graph.
class RunningRatings(BaseModel):
    life_rating: str = "N/A"
    ltc: str = "N/A"
    wp: str = "N/A"
    adb: str = "N/A"


# endregion

# region: Aggregated Rating Agent


class RatingAgregationInput(BaseModel):
    trace: dict[str, dict[str, Any]]


class RatingAgregationOutput(BaseModel):
    overall_rating: dict[
        str, str
    ]  # TODO: Update this to a more specific type if possible
    aggregation_reasoning: str = ""


# endregion


# region: Process Graph Agent


class ProcessGraphAgentInput(BaseModel):
    """Graph Runner input schema"""

    impairments: Annotated[list[str], add_unique] = []


class ProcessGraphAgentOutput(BaseModel):
    """Graph Runner output schema"""

    impairments: Annotated[list[str], add_unique] = []
    trace: Annotated[dict[str, dict[str, str]], merge] = {}


# endregion


class FinalPath(Enum):
    FINAL_MANUAL = 2
    FINAL_AUTOMATION = 1


class AgentState(BaseModel):
    # Inputs(s)
    medical_summary: str

    # Output(s)
    impairments: Annotated[list[str], add_unique] = []
    overall_rating: dict[str, str] = {}
    trace: Annotated[dict[str, dict[str, Any]], merge] = {}
    aggregation_reasoning: str = ""
    reasoning_summary: str = ""

    # Internal(s)
    profile: dict[str, Any] = {}

