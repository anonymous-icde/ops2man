import re
from enum import Enum
from typing import Optional

from pydantic import BaseModel, field_validator


class GraphState(str, Enum):
    AI_GENERATED = "ai_generated"
    IN_REVIEW = "in_review"
    PUBLISHED = "published"


class GraphStep(BaseModel):
    step: int
    description: str
    text_from_page: str


class GraphComponent(BaseModel):
    component_id: int
    component_name: str
    component_data: Optional[str] = None


class GraphMetadata(BaseModel):
    page_id: int
    page_name: str
    chapter_id: int
    chapter_name: str
    module_id: int
    module_name: str
    components: list[GraphComponent]


class Graph(BaseModel):
    id: str
    page_name: str
    keywords: list[str]
    graph: list[GraphStep]
    metadata: GraphMetadata

    @field_validator("id")
    def validate_id(cls, v):
        """Validate if the ID is in the correct format."""
        # ID should be in the format XXXXX-XXXXX-XXXXX
        # where X is a digit (0-9)
        # and each part can be 1 to 5 digits long
        # Example: 12345-67890-12345
        if not v:
            raise ValueError("ID is required.")
        pattern = r"^\d{1,5}-\d{1,5}-\d{1,5}$"
        if not re.match(pattern, v):
            raise ValueError("ID must be in the format XXXXX-XXXXX-XXXXX")
        return v
