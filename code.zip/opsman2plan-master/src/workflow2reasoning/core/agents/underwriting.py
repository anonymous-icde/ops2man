from typing import Literal

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Command
import os
import sys
from pathlib import Path

try:
    base_path = Path(__file__).parents[4] / "src"  # When __file__ is available
except NameError:
    base_path = Path(os.getcwd()).parents[3] / "src"  # Fallback for environments like Databricks

# Add the base path to sys.path
sys.path.append(os.path.abspath(base_path))

from workflow2reasoning.core.agents import (
    BaseAgent,
    ComorbidityAgent,
    ProcessGraphOrchestratorAgent,
    RiskFactorAgent,
    aggregated_rating_agent,
    profiling_agent,
    output_generation_agent,
)
from workflow2reasoning.core.config import AgentConfig
from workflow2reasoning.core.model.state import (
    AgentState,
)
from workflow2reasoning.logger import log


class UnderwritingAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            "Underwriter",
            "Underwriter agent for the underwriting process",
            state_schema=AgentState,
            config_schema=AgentConfig,
        )

        # Workflow
        self.workflow.add_edge(START, "underwriting_manager")
        self.workflow.add_node("underwriting_manager", self.underwriting_manager)

        risk_factor_agent = RiskFactorAgent()
        process_graph_agent = ProcessGraphOrchestratorAgent()
        comorbidity_graph_orchestrator = ComorbidityAgent()
        worker_agents = {
            "profiling_agent": profiling_agent,
            "risk_factor_agent": risk_factor_agent.compile(),
            "process_graph_orchestrator": process_graph_agent.compile(),
            "comorbidity_graph_executor_agent": comorbidity_graph_orchestrator.compile(),
            "aggregated_rating_agent": aggregated_rating_agent,
        }

        for agent_name, agent in worker_agents.items():
            self.workflow.add_node(agent_name, agent)
            self.workflow.add_edge(
                agent_name, "underwriting_manager"
            )  # Add edge to underwriting_manager for all agents
        
        self.workflow.add_node("output_generation_agent", output_generation_agent)
        self.workflow.add_edge("output_generation_agent", END)

    def _get_missing_comorbidity_impairments(self, state: AgentState) -> list[str]:
        """Get the impairments that are missing comorbidity information."""
        missing_comorbidity_runs = []
        for i, v in state.trace.items():
            if "co-morbidity" not in v["rating"]:
                missing_comorbidity_runs.append(i)
        return missing_comorbidity_runs


    def underwriting_manager(
        self, state: AgentState, config: RunnableConfig
    ) -> Command[
        Literal[
            "__end__",
            "profiling_agent",
            "risk_factor_agent",
            "process_graph_orchestrator",
            "comorbidity_graph_executor_agent",
            "aggregated_rating_agent",
        ]
    ]:
        """Underwriting manager decides the next best action to take based on the state of the conversation.

        This agent is responsible for deciding the next agent to be called based on the state of the conversation, Please note, this agent is sequential and the order of operations is very important.
        This should be a very light agent and should not contain any heavy computation as it will be called for every message and every transition.
        """
        if not state.profile:
            log.info("Calling profiling agent to get patient profiling information")
            return Command(goto="profiling_agent")

        if not state.impairments:
            log.info("Calling impairment agent to get patient impairments")
            return Command(goto="risk_factor_agent")

        if state.impairments and state.impairments[0] == 'No impairments detected':
            log.info("No impairments detected, ending the workflow")
            return Command(goto="output_generation_agent")
        
        if len(state.impairments) > len(state.trace.keys()):
            missing_graph_runs = set(state.impairments) - set(state.trace.keys())
            log.info(
                f"Calling process graph orchestrator to run graph(s): {missing_graph_runs}"
            )
            return Command(goto="process_graph_orchestrator")

        # Assuming the comorbidity graph is called when none of the trace, items have a comorbidity key in them.
        missing_comorbidity_runs = self._get_missing_comorbidity_impairments(state)
        if missing_comorbidity_runs:
            log.info(
                f"Calling comorbidity graph executor agent to run graph(s): {missing_comorbidity_runs}"
            )
            return Command(goto="comorbidity_graph_executor_agent")

        if not state.overall_rating:
            log.info("Calling aggregated rating agent to get overall rating")
            return Command(goto="aggregated_rating_agent")

        if not state.reasoning_summary:
            log.info("Calling output generation agent to get final output")
            return Command(goto="output_generation_agent")


if __name__ == "__main__":
    # quick test to view results on mlflow
    import os
    import mlflow
    import json
    from langchain_core.runnables import RunnableParallel

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan end to end single case")

    medical_summary = """
    A male, born in 1972, is seeking a 20-year term policy for $2,000,000. He is 5'11", 177 lbs, never used tobacco, and his chest exceeds his waist. He has a history of coronary artery disease with angioplasty and two stents placed in June 2017 (LAD and RCA), but no heart attack. He has type 2 diabetes (diagnosed June 2017), takes 2000 mg per day, and is on atorvastatin 40 mg, clopidogrel 75 mg, aspirin 81 mg, and vitamin B12. His most recent A1c was 6.8 (October 2024). Family history includes a father with cardiovascular disease diagnosed at age 82.
    """

    with mlflow.start_run() as run:
        with mlflow.start_span(name="Underwriting Agent"):
            chain = UnderwritingAgent().compile()

            rp_dict = {
                f"trial-{i}" : chain
                for i in range(2)
            }
            
            rp_chain = RunnableParallel(
                **rp_dict,
            )

            input_state = AgentState(
                medical_summary=medical_summary,
            )

            output = rp_chain.invoke(
                input_state,
                config={
                    "max_concurrency": 4,
                    "recursion_limit": 300,
                }
            )
        log.info(output)
        mlflow.flush_trace_async_logging()
