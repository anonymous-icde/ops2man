from typing import Literal

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Send

from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.agents.singlegraphoptimized import SingleGraphRunner, SingleGraphRunnerState
from workflow2reasoning.core.config import AgentConfig
from workflow2reasoning.core.model.state import (
    AgentState,
)
from workflow2reasoning.logger import log

# This is the main orchestrator agent that will be responsible for running all the process graphs.

# the flowchart and details of the process orchestrator can be found here: /docs/agents/proccessgraphorchestrator.md


class ProcessGraphOrchestratorAgent(Agent):
    def __init__(self):
        super().__init__(
            "GraphRunner",
            "Graph Runner agent for the underwriting process",
            state_schema=AgentState,
            config_schema=AgentConfig,
        )

        # create the graph runner subgraph which executes the process graph for single impairment
        # and returns the result
        single_graph_runner_subgraph = SingleGraphRunner().compile()

        self.workflow.add_node("runner", single_graph_runner_subgraph)
        self.workflow.add_node(
            "block_for_batch_completion", self.block_for_batch_completion
        )
        self.workflow.add_node("entry_node", lambda _: {})

        self.workflow.add_edge(START, "entry_node")
        self.workflow.add_conditional_edges(
            "entry_node", self.run_batch_of_process_graphs
        )  # the start node will call the run_batch_of_process_graphs router which runs the next batch of process graphs. It starts with all the graphs in the impairments list
        self.workflow.add_edge(
            "runner", "block_for_batch_completion"
        )  # Once all the the runner nodes finish execution, they will calls the block_for_batch_completion node. This acts like a join node and waits for all the runner nodes to finish.
        self.workflow.add_conditional_edges(
            "block_for_batch_completion", self._router
        )  # decides if there are more impairments to process or not by calling the router function

    def run_batch_of_process_graphs(
        self, state: AgentState, config: RunnableConfig
    ) -> list[Send]:
        """Find the impairments or conditions that haven't yet been processed and send them to the runner.

        It will find all impairments that haven't yet been processed and send them in parallel to the runner.
        """
        log.info("Executing node: run_batch_of_process_graphs")
        unprocessed = set(state.impairments) - set(state.trace.keys())
        assert len(unprocessed) > 0, (
            "This shouldn't be called if there are mo impairments to process"
        )

        log.info(f"Running impairments: {unprocessed}")

        send_node_list = []

        for i in unprocessed:
            send_node_list.append(
                Send(
                    "runner",
                    SingleGraphRunnerState(**state.model_dump(), impairment=i),
                )
            )  # Send doesn't seem to be implicitly sending the state even though send makes the subgraph part of the original graph; so we need to explicitly send it

        return send_node_list

    def block_for_batch_completion(self, state: AgentState, config: RunnableConfig):
        """Block until all the process graphs have completed."""
        log.info("Executing node: block_for_batch_completion")
        log.info(
            f"Impairments remaining:  {set(state.impairments) - set(state.trace.keys())}"
        )
        impairment_ratings = {
            impairment: rating_info["rating"]
            for impairment, rating_info in state.trace.items()
        }
        log.info(f"Trace: {impairment_ratings}")
        return {}

    def _router(
        self, state: AgentState, config: RunnableConfig
    ) -> Literal["entry_node", "__end__"]:
        """Decides if there are more impairments to process or not."""
        if set(state.impairments) - set(state.trace.keys()):
            return "entry_node"
        return END


# endregion
