import json
import networkx as nx
from langchain_core.runnables.config import RunnableConfig
from networkx.readwrite import json_graph
from pydantic import BaseModel
from workflow2reasoning.constant import KNOWLEDGE_GRAPH_FILEPATH
from workflow2reasoning.core.model.state import AgentState, RatingAgregationInput, RatingAgregationOutput
from workflow2reasoning.core.utils.ratings import max_ratings
from workflow2reasoning.logger import log
import os
from workflow2reasoning.constant import PROMPT_DIR, STD_NAMES_MAPPING_TO_GRAPH_FILEPATH
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.utils.llm import get_chain_with_retry


class RatingAdjustment(BaseModel):
    value: str
    rationale: str


class SummarizedOutput(BaseModel):
    reasoning: str
    adjustments: list[RatingAdjustment]


def output_generation_agent(
    state: AgentState, config: RunnableConfig
):
    """
    Create a readable and easy traceable summary of the underwriting decisions for faster triaging. 

    Method:
    1. Generate rating adjustments summary from process graphs. 
    2. Generate rating adjustments summary from knowledge graph.
    3. Copy aggregated rating summary. 
    4. Add risk factor agent analysis in appendix.
    """
    summary = [] # add strings to this list and join them at the end with newlines displayed as markdown eventually

    if len(state.trace) == 0:
        return {
            "reasoning_summary": "## No impairments were found in the medical summary. Hence the model is going with the default rating of Postpone",
            "overall_rating": {"life_rating": "Postpone"}
        }

    summary.append("## Impairments detected")
    summary.append(", ".join(state.impairments) + "\n")

    # Generate the rating adjustments from the process graphs
    chain = get_chain_with_retry(
        prompt_path=PROMPT_DIR / "generate_process_graph_summary.jinja2",
        output_format=SummarizedOutput,
        model_name=config.get("configurable").get("model_name", "azure_openai:gpt-4o")
    )

    batch_inputs = [
        {
            "impairment": impairment,
            "steps": [s for s in state.trace[impairment]["steps"] if s['step_outcome'] != "N/A"]
        }
        for impairment in state.trace.keys()
    ]

    pg_summary: SummarizedOutput = chain.batch(
        batch_inputs, config={"max_concurrency": 4}
    )

    # Generate the rating adjustments from the knowledge graph
    chain = get_chain_with_retry(
        prompt_path=PROMPT_DIR / "generate_knowledge_graph_summary.jinja2",
        output_format=SummarizedOutput,
        model_name=config.get("configurable").get("model_name", "azure_openai:gpt-4o")
    )

    batch_inputs = [
        {
            "impairment": impairment,
            "steps": state.trace[impairment]["comorbidity_steps"]
        }
        for impairment in state.trace.keys()
    ]

    kg_summary: SummarizedOutput = chain.batch(
        batch_inputs, config={"max_concurrency": 4}
    )

    for idx, impairment in enumerate(state.trace.keys()):
        summary.append(f"## Impairment: {impairment}\n")
        summary.append("Rating after process graph execution: " + state.trace[impairment]["rating"]["life_rating"] + "\n")

        if len(pg_summary[idx].adjustments) == 0:
            summary.append("No rating adjustments were made based on the process graph execution.\n")

        for adjustment in pg_summary[idx].adjustments:
            summary.append("Adjustment: " + adjustment.value)
            summary.append("Rationale: " + adjustment.rationale + "\n")
        
        summary.append("### Additional consideration adjustments \n")
        summary.append("Final impairment rating after knowledge graph execution: " + state.trace[impairment]["rating"]["co-morbidity"] + "\n")
        
        if len(kg_summary[idx].adjustments) == 0:
            summary.append("No additional rating adjustments were made based on the knowledge graph.\n")

        for adjustment in kg_summary[idx].adjustments:
            summary.append("Adjustment: " + adjustment.value)
            summary.append("Rationale: " + adjustment.rationale + "\n")
        
    summary.append("## Overall Rating \n")
    summary.append(f"Rating: {state.overall_rating['life_rating']}")
    summary.append("Rationale: " + state.aggregation_reasoning)

    summary_text = "\n".join(summary)

    return {"reasoning_summary": summary_text}


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = output_generation_agent
        input_state = AgentState(
            medical_summary="A 69-year-old male, height 6'0, weight 230 lbs, non-tobacco user, is seeking $1,000,000 of term insurance. He has well-controlled hypertension and type 2 diabetes, with an A1C under 6.",
            impairments=["Diabetes Mellitus"],
            overall_rating={
                "life_rating": "40",
            },
            profile={
                "age": "30",
                "BMI": "25",
            },
            trace={
                "Diabetes Mellitus": {
                    "rating": {
                        "life_rating": "+0",
                        "ltc": "+0",
                        "wp": "+0",
                        "adb": "+0",
                        "co-morbidity": "40"
                    },
                    "steps": [
                        {
                            "step_id": 3,
                            "step_description": "Apply basic rating for Type 2 diabetes based on age at application",
                            "step_outcome": "Type 2 Diabetes basic age-based rating: Standard (Age 60-69).",
                            "step_execution": "The impairment is Type 2 diabetes. The current step requires applying the age-based rating from the manual. The applicant is 69 years old, which falls into the 'Type 2 Diabetes - Age 60-69' bracket. The manual specifies a Standard rating for this age range. The condition is also noted as well-controlled with A1C under 6, which aligns with the Standard outcome."
                        },
                        {
                            "step_id": 4,
                            "step_description": "Assess the control level of diabetes by analyzing HbA1c and fasting glucose levels. Apply credits or debits based on control chart.",
                            "step_outcome": "HbA1c: <6 (meets 'Excellent' HbA1c criterion). Fasting glucose: not provided. Control chart category: indeterminable due to missing fasting glucose. Credit/Debit applied: 0. If fasting glucose <140 mg/dl is documented, apply -40 per 'Excellent' control.",
                            "step_execution": "The applicant has Type 2 diabetes, making this control-level assessment relevant. The manual requires both HbA1c and fasting glucose criteria to determine the control category and apply credits/debits. The applicant’s HbA1c is under 6, which meets the HbA1c threshold for the 'Excellent' category (<7.1). However, fasting glucose is not provided, so the full criteria for any category cannot be confirmed. Per the manual, without both measures meeting the same category, a control credit/debit cannot be applied."
                        },
                        {
                            "step_id": 5,
                            "step_description": "Assess and apply debits for diabetes-specific complications",
                            "step_outcome": "No diabetes-specific complications documented in the medical summary. Debits applied: +0. If later documentation indicates any of the following, apply per manual: Microalbuminuria +30; Macroalbuminuria +80; Retinopathy (background) +0; Retinopathy (proliferative) +60; Neuropathy (mild) +0; Neuropathy (moderate) +40; Neuropathy (severe) Decline; Amputation (due to diabetes) Decline; Renal impairment IC or Decline; Ulcer, lower extremity Decline.",
                            "step_execution": "This step is relevant because it addresses diabetes-specific complications that can add debits or lead to adverse decisions. The UW manual provides explicit debits/decisions for microalbuminuria, retinopathy, neuropathy, amputations, renal impairment, and lower extremity ulcers. The medical summary for this 69-year-old male with well-controlled type 2 diabetes (A1C < 6) does not document any such complications. In the absence of documented complications, no debits are applied at this step."
                        },
                        {
                            "step_id": 6,
                            "step_description": "Read the below Minimum Rating table. Check if the rating is above the minimum rating after credits, if the rating is below the minimum rating after credits, adjust to the minimum rating. Otherwise, keep the rating as is.",
                            "step_outcome": "Minimum rating per table: Preferred (Type 2, age 60-69). Current rating after credits/debits: Standard. Adjustment: Upgrade to Preferred to meet the minimum rating.",
                            "step_execution": "This step enforces the minimum rating floor from the manual. The applicant has Type 2 diabetes and is age 69, which corresponds to the 'Type 2 Diabetes - Age 60-69' minimum rating of Preferred. The current rating after credits/debits is Standard (no control credits were applied due to missing fasting glucose; no complication debits were applied). Because Standard is worse than the minimum allowed Preferred, the rating must be adjusted up to meet the minimum."
                        }
                    ],
                    "comorbidity_steps": [
                        {
                            "step_id": 2,
                            "step_description": "Executing additional consideration: Build-Risk Assessment with instructions: {'BMI 30-34.9': '+20', 'BMI 35-39.9': '+40', 'BMI >=40': '+80 or Decline'}",
                            "step_execution": "The medical summary explicitly provides height (6'0\") and weight (230 lbs), and the applicant profile lists BMI 31.19. The manual instruction for the additional consideration 'Build-Risk Assessment' specifies debits based on BMI ranges; BMI 31.19 falls within 30–34.9, which calls for a +20 debit. Although the general build table showed no surcharge at this height/weight, the diabetes-specific additional consideration uses BMI thresholds, so the +20 debit applies to the diabetes impairment rating. The minimum rating floor from Step 6 is a separate consideration, but the task here is to apply the additional consideration to the primary impairment.",
                            "step_outcome": "BMI 31.19 falls in 30–34.9 per manual; apply +20 debit to the diabetes impairment rating."
                        },
                        {
                            "step_id": 7,
                            "step_description": "Executing additional consideration: Hypertension with instructions: {'controlled': '+20', 'uncontrolled': '+60 or Decline'}",
                            "step_execution": "The additional consideration is Hypertension. The medical summary explicitly states the applicant has well-controlled hypertension, making this consideration relevant. The manual instruction specifies a +20 debit for controlled hypertension. Therefore, a +20 debit should be applied to the primary impairment (Diabetes Mellitus) rating for the presence of controlled hypertension. The 'uncontrolled' pathway (+60 or Decline) does not apply because control is documented as well-controlled.",
                            "step_outcome": "Hypertension is present and well-controlled. Apply +20 debit to the diabetes rating per manual."
                        },
                        {
                            "step_id": 9,
                            "step_description": "Executing additional consideration: Smoking with instructions: {'<=1 pack/day': 'Smoker rates', '>1 pack/day': '+30 to +50'}",
                            "step_execution": "The additional consideration is Smoking. The medical summary explicitly documents the applicant as a non-tobacco user, which satisfies the requirement to consider this factor. The manual’s instruction provides adjustments only for smokers (<=1 pack/day: Smoker rates; >1 pack/day: +30 to +50). Because the applicant is explicitly non-tobacco, these smoker-specific adjustments do not apply. No assumptions were made about any alternative nicotine use or pack/day, as none are documented.",
                            "step_outcome": "Smoking status: non-tobacco user. Manual smoker adjustments do not apply. Adjustment: +0. Rating remains unchanged (Preferred per prior step)."
                        }
                    ]
                }
            },
            aggregation_reasoning="Aggregation string here",
        )
        output = agent(input_state, config={"configurable": {"model_name": "azure_openai:gpt-4o"}})
    
    log.info(output['reasoning_summary'])
