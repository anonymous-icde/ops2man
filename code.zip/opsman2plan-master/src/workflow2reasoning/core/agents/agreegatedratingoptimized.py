import json
import networkx as nx
from langchain_core.runnables.config import RunnableConfig
from networkx.readwrite import json_graph
from workflow2reasoning.constant import KNOWLEDGE_GRAPH_FILEPATH
from workflow2reasoning.core.model.state import AgentState, RatingAgregationInput, RatingAgregationOutput
from workflow2reasoning.core.utils.ratings import max_ratings
from workflow2reasoning.logger import log
import os


def max_ratings(ratings: list[str]) -> str:
    """Max the ratings in the list. If any rating is "Decline" or "Postpone", return that rating.
    If all ratings are "N/A", return "N/A". Otherwise, sum the ratings and return the result.
    """
    if len(ratings) == 0:
        return "0"

    if any(rating == "Decline" for rating in ratings):
        return "Decline"
    elif any(rating == "Postpone" for rating in ratings):
        return "Postpone"
    elif all(rating == "N/A" for rating in ratings):
        return "N/A"
    else:

        def transform(x):
            return float(x[:-1]) if (x.endswith("x") or x.endswith("X")) else int(x)

        return str(max(transform(rating) for rating in ratings if rating != "N/A"))


def sum_ratings(ratings: list[str]) -> str:
    """Sum the ratings in the list. If any rating is "Decline" or "Postpone", return that rating.
    If all ratings are "N/A", return "N/A". Otherwise, sum the ratings and return the result.
    """
    if len(ratings) == 0:
        return "0"

    if any(rating == "Decline" for rating in ratings):
        return "Decline"
    elif any(rating == "Postpone" for rating in ratings):
        return "Postpone"
    elif all(rating == "N/A" for rating in ratings):
        return "N/A"
    else:

        def transform(x):
            try:
                transformed_x = float(x[:-1]) if (x.endswith("x") or x.endswith("X")) else float(x)
            except ValueError: # in case of IC or other non-numeric ratings
                transformed_x = 0
            return transformed_x

        return str(sum(transform(rating) for rating in ratings if rating != "N/A"))


def get_final_life_rating(
    all_comorbidity_ratings: dict[str, str], knowledge_graph: nx.Graph
) -> tuple[str, str]:
    """Get the final LIFE rating based on the comorbidity ratings and the knowledge graph along with a reasoning trace for auditability."""
    reasoning_str = ""
    if len(all_comorbidity_ratings) == 0:
        reasoning_str = "No comorbidity ratings were available."
        return "0", reasoning_str

    final_LIFE_rating = None

    summed_rating = sum_ratings(all_comorbidity_ratings.values())
    if summed_rating in ["Decline", "Postpone", "N/A"]:
        reasoning_str = f"Aggregating the rating to {summed_rating} as one of the ratings was {summed_rating}. \n" if summed_rating != "N/A" else "All ratings were N/A. \n"
        final_LIFE_rating = summed_rating

    if final_LIFE_rating is None:
        subgraph = knowledge_graph.subgraph(all_comorbidity_ratings.keys())
        subgraph = subgraph.to_undirected()

        # add ratings from the nodes in the knowledge graph
        final_LIFE_rating = 0
        for component in nx.connected_components(subgraph):
            component_rating = max_ratings(
                [all_comorbidity_ratings[i] for i in component]
            )
            final_LIFE_rating += (
                int(component_rating) if component_rating != "N/A" else 0
            )
            if len(component) > 1:
                reasoning_str += f"Comorbidity ratings for impairments: {component} were combined to {component_rating} after taking the max.\n"
            else:
                reasoning_str += f"Rating for impairment: {list(component)[0]}, was {component_rating} and it was added.\n"

        # add ratings for the nodes not in the knowledge graph
        non_subgraph_impairments = set(all_comorbidity_ratings.keys()) - set(
            subgraph.nodes
        )  # pages that are not part of the knowledge graph
        non_subgraph_ratings = [
            all_comorbidity_ratings[i] for i in non_subgraph_impairments
        ]
        summed_rating = sum_ratings(non_subgraph_ratings)

        if non_subgraph_impairments:
            reasoning_str += f"Ratings for impairments not part of the knowledge graph: {non_subgraph_impairments} were summed to {summed_rating}.\n"

        final_LIFE_rating += int(summed_rating) if summed_rating != "N/A" else 0

    reasoning_str += f"The final LIFE rating is {final_LIFE_rating}."

    return str(final_LIFE_rating), reasoning_str


def aggregated_rating_agent(
    state: RatingAgregationInput, config: RunnableConfig
) -> RatingAgregationOutput:
    """
    Agreegated Rating agent applies the rating aggregation logic to compute the final LIFE rating and rider ratings. 
    """
    with open(KNOWLEDGE_GRAPH_FILEPATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    knowledge_graph = json_graph.node_link_graph(data)

    all_comorbidity_ratings = {
        i: d["rating"]["co-morbidity"] for i, d in state.trace.items()
    }

    final_LIFE_rating, reasoning_str = get_final_life_rating(all_comorbidity_ratings, knowledge_graph)

    return {"overall_rating": {"life_rating": final_LIFE_rating}, "aggregation_reasoning": reasoning_str}


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = aggregated_rating_agent
        input_state = AgentState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5 and a normal build.",
            impairments=["Diabetes Mellitus", "Depression"],
            profile={
                "age": "30",
                "BMI": "25",
            },
            trace={
                "Diabetes Mellitus": {
                    "rating": {
                        "life_rating": "+40",
                        "co-morbidity": "+40",
                        "ltc": "+20",
                        "wp": "+10",
                        "adb": "+10",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Initial assessment of diabetes status",
                            "step_execution": "Reviewed patient's medical history and recent A1C levels.",
                            "step_outcome": "Identified that the patient has type 2 diabetes with an A1C of 8.5."
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate risk factors associated with diabetes",
                            "step_execution": "Considered age, BMI, lifestyle, and family history.",
                            "step_outcome": "Patient is 30 years old with a normal BMI of 25, which is a positive factor."
                        },
                        {
                            "step_id": 3,
                            "step_description": "Determine overall life rating based on current health status",
                            "step_execution": "Used clinical guidelines to assess the impact of diabetes on life expectancy.",
                            "step_outcome": "Assigned a life rating of Moderate due to the presence of diabetes and elevated A1C."
                        }
                    ]
                },
                "Depression": {
                    "rating": {
                        "life_rating": "+0",
                        "co-morbidity": "+10",
                        "ltc": "+10",
                        "wp": "+10",
                        "adb": "+10",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Assess patient's medical history and current mental health status",
                            "step_execution": "Reviewed patient's medical history and current medications.",
                            "step_outcome": "Identified that the patient has no relevant history of depression."
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate lifestyle factors influencing build",
                            "step_execution": "Reviewed dietary habits and physical activity levels.",
                            "step_outcome": "Patient maintains a balanced diet and exercises regularly."
                        }
                    ]
                }
            }
        )
        output = agent(input_state, config=RunnableConfig())
    
    log.info(json.dumps(output, indent=2))
