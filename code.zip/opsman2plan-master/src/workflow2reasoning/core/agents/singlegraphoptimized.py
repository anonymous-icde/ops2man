import json
import operator
import os
from datetime import datetime
from typing import Annotated, Any, Literal

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Command
from pydantic import BaseModel, field_validator

from workflow2reasoning.constant import (
    GRAPH_DIR,
    PROMPT_DIR,
    STD_NAMES_MAPPING_TO_GRAPH_FILEPATH,
)
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.model.state import (
    merge,
)
from workflow2reasoning.core.utils.llm import get_chain_with_retry
from workflow2reasoning.core.utils.reducers import add_unique
from workflow2reasoning.logger import log


class GraphStep(BaseModel):
    step_description: str
    text_from_manual: Any # can be str or list or dict depending on how the LLM returns it


class Graph(BaseModel):
    page_name: str
    graph: list[GraphStep]


class SingleGraphRunnerOutput(BaseModel):
    # Represents the output of the subgraph.
    # - `trace`: A dictionary where the key is the impairment, and the value contains the final ratings and execution trace.
    # - `impairments`: A list of any new impairments to be processed.
    trace: Annotated[dict[str, dict[str, Any]], merge]
    impairments: Annotated[list[str], add_unique] = []


class StepExecution(BaseModel):
    # Represents the raw output and reasoning for a step.
    step_reasoning: str
    step_output: str
    is_relevant: bool

    @field_validator("step_output", mode="before")
    def convert_dict_to_str(cls, value):
        """Convert a dictionary or list to a string if the LLM returns such a format."""
        if isinstance(value, dict):
            return ", ".join(
                f"{key}: {val}" for key, val in value.items()
            )  # Convert dict to string
        if isinstance(value, list):
            return str(value)  # Convert list to string
        return value  # Return as-is if it's already a string


# Model for the running ratings.
class CombinedRatings(BaseModel):
    step_reasoning: str = "N/A"
    life_rating: str = "N/A"
    ltc: str = "N/A"
    wp: str = "N/A"
    adb: str = "N/A"


# Model for the overall state of the subgraph
class SingleGraphRunnerState(BaseModel):
    # read from the parent state (AgentState)
    medical_summary: str
    profile: dict[str, Any]

    # inputs
    impairment: str

    # set at different stages of the workflow. Basically a StepExecution object for each step in the graph is created and its various fields are updated as the graph execution progresses
    graph: Graph | None = None
    step_executions: Annotated[list[StepExecution], operator.add] = []
    combined_ratings: CombinedRatings | None = None


# endregion


# region: SingleGraphRunner agent
# This is the agent that will be responsible for running a single process graph for a given impairment. It is defined as an Langgraph subgraph.


# implements the flowchart in the documentation: /docs/agents/processgraphorchestrator.md
class SingleGraphRunner(Agent):
    def __init__(self):
        super().__init__(
            "SingleGraphRunner",
            "Single Graph Runner agent for to rate single impairment",
            state_schema=SingleGraphRunnerState,
            output=SingleGraphRunnerOutput,
        )

        # Add all the nodes in the graph
        self.workflow.add_node("add_graph_steps", self.add_graph_steps)
        self.workflow.add_node("execute_next_step", self.execute_next_step)
        self.workflow.add_node("combine_step_ratings", self.combine_step_ratings)
        self.workflow.add_node("generate_graph_output", self.generate_graph_output)

        # Add all the edges in the graph
        self.workflow.add_edge(START, "add_graph_steps")
        self.workflow.add_edge("add_graph_steps", "execute_next_step")
        self.workflow.add_edge("combine_step_ratings", "generate_graph_output")
        # execute_next_step will use Command to call generate graph output or itself till all steps are done
        self.workflow.add_edge("generate_graph_output", END)

    def _get_previous_step_outputs_str(self, state: SingleGraphRunnerState) -> str:
        return "\n".join(
            f"STEP_NO {idx}:\n"
            f"UNDERWRITING_STEP_DESCRIPTION:\n {g.step_description}\n"
            f"STEP_REASONING:\n {m.step_reasoning}\n"
            f"STEP_OUTPUT:\n {m.step_output}\n"
            for idx, (m, g) in enumerate(
                zip(state.step_executions, state.graph.graph), start=1
            )
        )

    def add_graph_steps(self, state: SingleGraphRunnerState, config: RunnableConfig):
        """Add the graph steps to the state after fetching the graph from the database."""
        log.info("Executing node: add_graph_steps")
        mapping = json.load(open(STD_NAMES_MAPPING_TO_GRAPH_FILEPATH))
        if state.impairment not in mapping:
            raise ValueError(
                f"Impairment {state.impairment} not found in mapping file."
            )
        graph_data = json.load(open(GRAPH_DIR / f"{mapping[state.impairment]}"))
        graph = Graph(
            page_name=graph_data["manual_section"],
            graph=[
                GraphStep(
                    step_description=step["description"],
                    text_from_manual=(step["text_from_manual"]),
                )
                for step in graph_data["steps"]
            ],
        )
        return {"graph": graph}

    def execute_next_step(
        self, state: SingleGraphRunnerState, config: RunnableConfig
    ) -> Command[Literal["execute_next_step", "generate_graph_output"]]:
        """Execute the next step in the graph and return the raw rating and reasoning."""
        log.info("Executing node: execute_next_step")

        current_step_idx = len(state.step_executions)

        if current_step_idx == len(state.graph.graph):
            # No more steps to execute
            return Command(goto="combine_step_ratings")

        log.info(f"Current step index: {current_step_idx}")

        # Execute the step and get the output
        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")
        completion_chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "execute_graph_step.jinja2",
            output_format=StepExecution,
            model_name=model_name,
        )

        output: StepExecution = completion_chain.invoke(
            {
                "impairment": state.impairment,
                "medical_summary": state.medical_summary,
                "applicant_profile": state.profile,
                "underwriting_step_description": f"{state.graph.graph[current_step_idx].step_description}",
                "text_from_uw_manual": state.graph.graph[
                    current_step_idx
                ].text_from_manual,
                "previous_steps_executions": self._get_previous_step_outputs_str(state),
                "current_date": datetime.now().strftime("%B %Y"),
            }
        )

        log.info(f"Output: {output}")

        return Command(goto="execute_next_step", update={"step_executions": [output]})

    def combine_step_ratings(
        self, state: SingleGraphRunnerState, config: RunnableConfig
    ):
        """Combine all the step ratings and return the final ratings for the impairment."""
        # combine all the step ratings and return the trace
        log.info("Executing node: combine_step_ratings")

        # combine ratings chain
        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")
        chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "combine_graph_ratings.jinja2",
            output_format=CombinedRatings,
            model_name=model_name,
        )

        combined_ratings: CombinedRatings = chain.invoke(
            {
                "all_steps_executions": self._get_previous_step_outputs_str(state),
            }
        )

        return {"combined_ratings": combined_ratings}

    def generate_graph_output(
        self, state: SingleGraphRunnerState, config: RunnableConfig
    ) -> SingleGraphRunnerOutput:
        """Generate the final output for the graph execution."""
        log.info("Executing node: generate_graph_output")

        # trace
        trace = []
        for idx, (step_execution, graph_step) in enumerate(
            zip(state.step_executions, state.graph.graph), start=1
        ):
            trace.append(
                {
                    "step_id": idx,
                    "step_description": f"{graph_step.step_description}",
                    "step_outcome": step_execution.step_output if step_execution.is_relevant else "N/A",
                    "step_execution": step_execution.step_reasoning,
                }
            )
        
        # also append the combining step
        trace.append(
            {
                "step_id": len(trace) + 1,
                "step_description": f"Get final rating after applying all the adjustments: {state.impairment}",
                "step_outcome": state.combined_ratings.life_rating,
                "step_execution": f"Combining rating logic...{state.combined_ratings.step_reasoning}",
            }
        )

        return {
            "trace": {
                state.impairment: {
                    "rating": {k:v for k,v in state.combined_ratings.model_dump().items() if k != "step_reasoning"},
                    "steps": trace,
                }
            },
        }


# endregion


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = SingleGraphRunner().compile()
        input_state = SingleGraphRunnerState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5.",
            impairment="Diabetes Mellitus",
            profile={
                "age": "30",
                "BMI": "25",
            },
        )

        output = agent.invoke(input_state)

    log.info(json.dumps(output, indent=2))

    mlflow.flush_trace_async_logging()
