import json
import os
from datetime import datetime
from typing import Annotated, Any

from langchain_core.runnables.config import RunnableConfig
from langgraph.graph import END, START
from langgraph.types import Send
from networkx.readwrite import json_graph
from pydantic import BaseModel

from workflow2reasoning.constant import KNOWLEDGE_GRAPH_FILEPATH, PROMPT_DIR
from workflow2reasoning.core.agents.base import Agent
from workflow2reasoning.core.config import (
    AgentConfig,
)
from workflow2reasoning.core.model.alerting import Alert
from workflow2reasoning.core.model.state import (
    AgentState,
)
from workflow2reasoning.core.utils.llm import get_chain_with_retry
from workflow2reasoning.core.utils.reducers import merge, update_list
from workflow2reasoning.logger import log

KNOWLEDGE_GRAPH_FILE_NAME = os.getenv(
    "KNOWLEDGE_GRAPH_FILE_NAME", "knowledge_graph.json"
)


class SingleImpairmentComorbidityAgentOutput(BaseModel):
    trace: Annotated[dict[str, dict[str, Any]], merge]
    alerts: Annotated[list[Alert], update_list]


class EdgeInfo(BaseModel):
    primary_impairment: str
    additional_consideration: str
    edge_text: str


class EdgeOutput(BaseModel):
    reasoning: str
    applicable: bool | None = None
    step_output: str


class CombinedRatings(BaseModel):
    step_reasoning: str
    life_rating: str


class SingleImpairmentComorbidityAgentState(BaseModel):
    # passed from parent state
    impairment: str
    medical_summary: str
    profile: dict[str, Any]
    trace_local: dict[str, dict[str, Any]]  # local copy of the state
    impairments_local: list[str] | None = None
    current_rating: str

    # updated within the agent
    kg_edges: list[EdgeInfo] | None = None
    edges_output: list[EdgeOutput] | None = None


class SingleImpairmentComorbidityAgent(Agent):
    def __init__(self):
        super().__init__(
            "SingleImpairmentComorbidityAgent",
            "Agent to handle single impairment comorbidity analysis",
            output=SingleImpairmentComorbidityAgentOutput,
            state_schema=SingleImpairmentComorbidityAgentState,
            config_schema=AgentConfig,
        )
        self.workflow.add_node("get_edges", self.get_edges)
        self.workflow.add_node("execute_all_edges", self.execute_all_edges)
        self.workflow.add_node("combine_ratings", self.combine_ratings)
        self.workflow.add_edge(START, "get_edges")
        self.workflow.add_edge("get_edges", "execute_all_edges")
        self.workflow.add_edge("execute_all_edges", "combine_ratings")
        self.workflow.add_edge("combine_ratings", END)

    def get_edges(
        self, state: SingleImpairmentComorbidityAgentState, config: RunnableConfig
    ):
        """Get edges for the additional considerations."""
        log.info("Executing node: get_edges")
        with open(KNOWLEDGE_GRAPH_FILEPATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        knowledge_graph = json_graph.node_link_graph(data)

        kg_edges = [
            EdgeInfo(
                primary_impairment=t[0],
                additional_consideration=t[1],
                edge_text=t[2]["text"],
            )
            for t in knowledge_graph.out_edges(state.impairment, data=True)
        ]
        return {"kg_edges": kg_edges}

    def execute_all_edges(
        self, state: SingleImpairmentComorbidityAgentState, config: RunnableConfig
    ):
        """Execute all edges for the current impairment."""
        log.info("Executing node: execute_all_edges")

        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")
        completion_chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "execute_kg_edge.jinja2",
            output_format=EdgeOutput,
            model_name=model_name,
        )

        batch_inputs = [
            {
                "primary_impairment": state.impairment,
                "additional_consideration": edge.additional_consideration,
                "edge_text": edge.edge_text,
                "medical_summary": state.medical_summary,
                "profile": state.profile,
                "primary_impairment_trace": state.trace_local[state.impairment][
                    "steps"
                ],
                "additional_consideration_trace": state.trace_local[
                    edge.additional_consideration
                ]["steps"]
                if edge.additional_consideration in state.trace_local
                else "N/A",
                "current_date": datetime.now().strftime("%B %Y"),
            }
            for edge in state.kg_edges
        ]

        execution_output: list[EdgeOutput] = completion_chain.batch(
            batch_inputs, config={"max_concurrency": 4}
        )

        return {"edges_output": execution_output}

    def combine_ratings(
        self, state: SingleImpairmentComorbidityAgentState, config: RunnableConfig
    ):
        """Combine the ratings of the current impairment with the comorbidity rating."""

        def get_comorbidity_steps(state):
            steps = [
                {
                    "step_id": idx + 1,
                    "step_description": f"Executing additional consideration: {edge.additional_consideration} with instructions: {edge.edge_text}",
                    "step_execution": edge_output.reasoning,
                    "step_outcome": edge_output.step_output,
                }
                for idx, (edge, edge_output) in enumerate(
                    zip(state.kg_edges, state.edges_output)
                )
                if edge_output.applicable
            ]
            return steps

        log.info("Executing node: combine_ratings")

        # Get the current running ratings from the trace
        current_rating = state.trace_local[state.impairment]["rating"]
        model_name = config.get("configurable").get("model_name", "azure_openai:gpt-4o")
        chain = get_chain_with_retry(
            prompt_path=PROMPT_DIR / "combine_edge_ratings.jinja2",
            output_format=CombinedRatings,
            model_name=model_name,
        )

        steps = get_comorbidity_steps(state)
        combined_ratings = (
            chain.invoke({"primary_impairment": state.impairment, "current_rating": current_rating, "edges_output": steps})
            if steps
            else CombinedRatings(
            step_reasoning="No additional considerations were applicable.",
            life_rating=state.current_rating,
            )
        )

        original_impairment_trace = state.trace_local[state.impairment]
        original_impairment_trace["rating"]["co-morbidity"] = (
            combined_ratings.life_rating
        )

        # Append all relevant edges execution to the trace for state.impairment
        original_impairment_trace["comorbidity_steps"] = get_comorbidity_steps(state)

        # add the final combining step as well
        original_impairment_trace["comorbidity_steps"].append(
            {
                "step_id": len(original_impairment_trace["comorbidity_steps"]) + 1,
                "step_description": f"Get final rating after applying all the additional considerations adjustments: {state.impairment}",
                "step_execution": f"Combining rating logic...{combined_ratings.step_reasoning}",
                "step_outcome": combined_ratings.life_rating,
            }
        )

        return {
            "trace": {state.impairment: original_impairment_trace},
        }


class ComorbidityAgent(Agent):
    def __init__(self):
        super().__init__(
            "ComorbidityAgent",
            "Agent to handle comorbidity analysis",
            state_schema=AgentState,
            config_schema=AgentConfig,
        )

        comorbidity_runner = SingleImpairmentComorbidityAgent().compile()

        self.workflow.add_node("comorbidity_runner", comorbidity_runner)
        self.workflow.add_node(
            "block_for_batch_completion_comorbidity",
            self.block_for_batch_completion_comorbidity,
        )

        self.workflow.add_conditional_edges(
            START, self.run_batch_of_comorbidity_analysis
        )
        self.workflow.add_edge(
            "comorbidity_runner", "block_for_batch_completion_comorbidity"
        )
        self.workflow.add_edge("block_for_batch_completion_comorbidity", END)

    def run_batch_of_comorbidity_analysis(
        self, state: AgentState, config: RunnableConfig
    ) -> list[Send]:
        """Run the comorbidity analysis for all impairments in the input."""
        log.info("Executing node: run_batch_of_comorbidity_analysis")
        return [
            Send(
                "comorbidity_runner",
                SingleImpairmentComorbidityAgentState(
                    trace_local=state.trace,
                    medical_summary=state.medical_summary,
                    impairment=imp,
                    current_rating=state.trace[imp]["rating"]["life_rating"],
                    profile=state.profile,
                    impairments_local=state.impairments,
                ),
            )
            for imp in state.impairments
        ]

    def block_for_batch_completion_comorbidity(
        self, state: AgentState, config: RunnableConfig
    ):
        """Block until all comorbidity analysis is complete."""
        log.info("Executing node: block_for_batch_completion_comorbidity")
        return {}


if __name__ == "__main__":
    # quick test to view results on mlflow

    import mlflow

    os.environ.pop("http_proxy", None)
    os.environ.pop("https_proxy", None)

    mlflow.langchain.autolog()

    mlflow.set_experiment("/Users/sonutka@mfcgd.com/opsman2plan test graph agent")

    with mlflow.start_run() as run:
        agent = ComorbidityAgent().compile()
        input_state = AgentState(
            medical_summary="A person aged 30 with type 2 diabetes, and a1c of 8.5 and a normal build.",
            impairments=["Diabetes Mellitus", "Depression"],
            profile={
                "age": "30",
                "BMI": "25",
            },
            trace={
                "Diabetes Mellitus": {
                    "rating": {
                        "life_rating": "+40",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Initial assessment of diabetes status",
                            "step_execution": "Reviewed patient's medical history and recent A1C levels.",
                            "step_outcome": "Identified that the patient has type 2 diabetes with an A1C of 8.5.",
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate risk factors associated with diabetes",
                            "step_execution": "Considered age, BMI, lifestyle, and family history.",
                            "step_outcome": "Patient is 30 years old with a normal BMI of 25, which is a positive factor.",
                        },
                        {
                            "step_id": 3,
                            "step_description": "Determine overall life rating based on current health status",
                            "step_execution": "Used clinical guidelines to assess the impact of diabetes on life expectancy.",
                            "step_outcome": "Assigned a life rating of Moderate due to the presence of diabetes and elevated A1C.",
                        },
                    ],
                },
                "Depression": {
                    "rating": {
                        "life_rating": "+0",
                    },
                    "steps": [
                        {
                            "step_id": 1,
                            "step_description": "Assess patient's medical history and current mental health status",
                            "step_execution": "Reviewed patient's medical history and current medications.",
                            "step_outcome": "Identified that the patient has no relevant history of depression.",
                        },
                        {
                            "step_id": 2,
                            "step_description": "Evaluate lifestyle factors influencing build",
                            "step_execution": "Reviewed dietary habits and physical activity levels.",
                            "step_outcome": "Patient maintains a balanced diet and exercises regularly.",
                        },
                    ],
                },
            },
        )
        output = agent.invoke(input_state)

    log.info(json.dumps(output, indent=2))

    mlflow.flush_trace_async_logging()
