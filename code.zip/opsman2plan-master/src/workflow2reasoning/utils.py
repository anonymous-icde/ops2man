import os


def require(env_name: str) -> str:
    """Check if the environment variable is set and return its value.

    Args:
        env_name (str): Name of the environment variable to check.

    Raises:
        ValueError: If the environment variable is not set or is empty.

    Returns:
        str: Value of the environment variable.
    """
    if env_name not in os.environ or not os.getenv(env_name):
        raise ValueError(
            f"{env_name} is not set! Please set the environment variable and then start the server!"
        )
    return os.environ[env_name]
