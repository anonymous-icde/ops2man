from pathlib import Path

PROMPT_DIR = (Path(__file__).parent / "prompts").resolve()
STD_NAMES_MAPPING_TO_GRAPH_FILEPATH = (
    Path(__file__).parent.parent
    / "man2workflow"
    / "maps"
    / "std_impairment_to_filename.json"
).resolve()
GRAPH_DIR = (
    Path(__file__).parent.parent / "man2workflow" / "workflow_generation" / "output"
).resolve()
KNOWLEDGE_GRAPH_FILEPATH = (
    Path(__file__).parent.parent
    / "man2workflow"
    / "workflow_generation"
    / "output"
    / "knowledge_graph.json"
).resolve()
RXLOOKUP_CHROMA_DB_DIR = (
    Path(__file__).parent.parent
    / "man2workflow"
    / "workflow_generation"
    / "output"
    / "rxlookup_chroma_db"
).resolve()
