from dataclasses import dataclass
from typing import Protocol

import pandas as pd

from .settings import Settings

settings = Settings()

CHAPTERS_DIR = settings.data_dir / "chapters"
SUPPORTED_EXTENSIONS = [".md", ".txt"]


@dataclass
class Chapter:
    name: str
    content: str


class KnowledgeSource(Protocol):
    def list_available_chapters(self) -> list[str]: ...

    def get_chapter(self, name: str) -> Chapter | str: ...


class SyntheticSource:
    def list_available_chapters(self) -> list[str]:
        """
        Provides a list of chapters available in the underwriting manual.
        The chapters are named after medical or non medical conditions relevant to underwriting that condition.
        """
        if CHAPTERS_DIR.exists() and CHAPTERS_DIR.is_dir():
            return [
                f.name.rsplit(".", 1)[0]
                for f in CHAPTERS_DIR.iterdir()
                if f.suffix in SUPPORTED_EXTENSIONS and f.is_file()
            ]
        return []

    def get_chapter(self, name: str) -> Chapter | str:
        """
        Provides an underwriting chapter given the name.
        """
        chapter_path = CHAPTERS_DIR / f"{name}.md"
        if chapter_path.exists() and chapter_path.is_file():
            with open(chapter_path, "r") as f:
                return Chapter(name=name, content=f.read())

        return f"Chapter '{name}' is not available."


class RealSource:
    def __init__(self):
        self.df = pd.read_csv(settings.data_dir / "uw_manual.csv")

    def list_available_chapters(self) -> list[str]:
        """
        Provides a list of chapters available in the underwriting manual.
        The chapters are named after medical or non medical conditions relevant to underwriting that condition.
        """
        return self.df["page_name"].unique().tolist()

    def get_chapter(self, name: str) -> Chapter | str:
        """
        Provides an underwriting chapter given the name.
        """
        chapter_data = self.df[self.df["page_name"] == name]
        if not chapter_data.empty:
            content = "\n".join(chapter_data["content"].values)
            return Chapter(name=name, content=content)
        return f"Chapter '{name}' is not available."
