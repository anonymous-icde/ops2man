import os
from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    data_dir: Path = os.getenv("DATA_DIR", Path(__file__).parent.parent.parent / "data")
    prompts_dir: Path = Path(__file__).parent.parent.parent / "prompts"
