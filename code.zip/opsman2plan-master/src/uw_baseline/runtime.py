import os

import pendulum as pen

DEFAULT_TIMEZONE = "America/Toronto"


def current_date() -> str:
    """
    Provides current date in ISO8601 format.
    """
    return pen.now(os.getenv("TZ", DEFAULT_TIMEZONE)).to_iso8601_string()
