from contextlib import contextmanager

import mlflow
from mlflow.entities import Feedback

from .rating import simple_compare, get_average_inconsistencies


@contextmanager
def disable_mlflow_temporarily():
    mlflow.autolog(disable=True)
    try:
        yield
    finally:
        mlflow.autolog(disable=False)


@mlflow.genai.scorer
def condition_details_match(outputs, expectations):
    if outputs is None:
        rationale = "No output from system"
        return [
            Feedback(
                name="all_condition_ratings_correct", value=False, rationale=rationale
            ),
            Feedback(name="has_same_condition_count", value=False, rationale=rationale),
            Feedback(
                name="has_all_expected_conditions", value=False, rationale=rationale
            ),
        ]

    expected = expectations["workup"]
    total_conditions = len(expected)
    output_conditions = {
        condition.name.strip(): condition for condition in outputs.conditions
    }

    incorrect_condition_ratings = [
        f"{name}: expected {expected[name]} got {output_conditions[name].condition_rating}"
        for name in expected
        if name in output_conditions
        and not simple_compare(
            output_conditions[name].condition_rating, expected[name]
        ).value
    ]

    missing_conditions = set(s.strip() for s in expected.keys()) - set(
        output_conditions.keys()
    )
    extra_conditions = set(output_conditions.keys()) - set(
        s.strip() for s in expected.keys()
    )

    return [
        Feedback(
            name="all_condition_ratings_correct",
            value=len(incorrect_condition_ratings) == 0,
            rationale="\n".join(incorrect_condition_ratings)
            if incorrect_condition_ratings
            else "All ratings correct",
        ),
        Feedback(
            name="has_same_condition_count",
            value=len(outputs.conditions) == total_conditions,
            rationale=(
                f"Expected {total_conditions} conditions, detected {len(outputs.conditions)} conditions."
                if len(outputs.conditions) != total_conditions
                else "Condition count matches"
            ),
        ),
        Feedback(
            name="has_all_expected_conditions",
            value=len(missing_conditions) == 0,
            rationale=(
                (
                    (
                        f"Did not run: {' | '.join(missing_conditions)}; "
                        if missing_conditions
                        else ""
                    )
                    + (
                        f"Did run Extra: {' | '.join(extra_conditions)}"
                        if extra_conditions
                        else ""
                    )
                ).strip("; ")
                if missing_conditions or extra_conditions
                else "All expected conditions present"
            ),
        ),
    ]


@mlflow.genai.scorer
def rating_is_exact_match(outputs, expectations):
    if outputs is None:
        return [
            Feedback(
                name="rating_is_exact_match",
                value=False,
                rationale="No output from system",
            )
        ]

    res = simple_compare(outputs.rating, expectations["rating"])
    return res


@mlflow.genai.scorer
def inconsistency_scorer(outputs, expectations):
    if outputs is None:
        rationale = "No output from system"
        return [
            Feedback(name="impairment_inconsistencies", value=False, rationale=rationale),
            Feedback(name="rating_inconsistency", value=False, rationale=rationale),
            Feedback(name="process_graph_rating_inconsistency", value=False, rationale=rationale),
            Feedback(name="is_rating_consistent", value=False, rationale=rationale),
        ]

    if len(outputs) < 2:
        rationale = "Not enough outputs to compare inconsistencies"
        return [
            Feedback(name="impairment_inconsistencies", value=False, rationale=rationale),
            Feedback(name="rating_inconsistency", value=False, rationale=rationale),
            Feedback(name="process_graph_rating_inconsistency", value=False, rationale=rationale),
            Feedback(name="is_rating_consistent", value=False, rationale=rationale),
        ]

    avg_rating_inconsistencies, avg_condition_inconsistencies, avg_process_graph_rating_inconsistencies = get_average_inconsistencies(outputs)

    return [
        Feedback(
            name="rating_inconsistency",
            value=avg_rating_inconsistencies,
            rationale=f"Average number of rating inconsistencies between responses: {avg_rating_inconsistencies:.2f}",
        ),
        Feedback(
            name="impairment_inconsistencies",
            value=avg_condition_inconsistencies,
            rationale=f"Average number of condition inconsistencies between responses: {avg_condition_inconsistencies:.2f}",
        ),
        Feedback(
            name="process_graph_rating_inconsistency",
            value=avg_process_graph_rating_inconsistencies,
            rationale=f"Average number of process graph rating inconsistencies between responses: {avg_process_graph_rating_inconsistencies:.2f}",
        ),
        Feedback(
            name="is_rating_consistent",
            value=avg_rating_inconsistencies == 0,
            rationale="Ratings are consistent across all responses"
            if avg_rating_inconsistencies == 0
            else "Ratings are not consistent across all responses",
        ),
    ]
