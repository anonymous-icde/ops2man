Consider the following rules below and convert the user provided ratings.

# Underwriting Rating Units

Below are some of the units of rating being used within underwriting and some of the key characteristics of those units.

| Unit       | Properties            | Convertable to                |
| ---------- | --------------------- | ----------------------------- |
| Percentage | Ranged, Single Value  | Absolute                      |
| Absolute   | Ranged, Single Value  | Percentage                    |
| Textual    | Single Value, Aliases | Percentage, Absolute (maybe?) |
| Table      | Single value, Aliases | Textual, Percentage, Absolute |


## Units / Scales

- Percentage Scale (Precise)

| Rating |
| ------ |
| 100%   |
| 150%   |
| 200%   |
| 250%   |
| 300%   |
| 350%   |

- Absolute Scale (Precise)

| Rating |
| ------ |
| -40 |
| -15 |
| +0  or 0   |
| +50 or 50    |
| +100 or 100 |
| +150 or 150   |
| +200 or 200  |
| +250 or 250  |

- Textual Scale (Only on aggregation step)

| Rating          | Aliases | Rating Ranges |
| --------------- | ------- | ------- |
| Standard        | std     | |
| Standard Plus   | std+    | | 
| Substandard     |         | > +0  - < +200 |
| Preffered       |         | |
| Super Preferred |         | |
| Postpone        | pp      | |
| Decline         |         | |


- Table Scale (Only on aggregation step)

| Name    | Aliases            |
| ------- | ------------------ |
| Table 1 | Table 1/a, Table a |
| Table 2 | Table 2/b, Table b |
| Table 3 | Table 3/c, Table c |
| Table 4 | table 4/d, Table d |

- Flags (Various Priorities)

IC = Individual Consideration 
RMD = Refer to Medical Doctor
NA = Not Available

- Multiplier (only on ADB and WP? how do they translate to ratings i.e to either absolute scale)

| Rating |
| ------ |
| 1x     |
| 2x     |
| 3x     |

## Conversions

To convert from percentage value to absolute value, use the following formula

```latex
\text{absolute value} = (\text{percentage value}) - 100
```

From absolute value to percentage value, use the following formula

```latex
\text{percentage value} = \text{absolute value} + 100
```

Conversion to Textual Representation, use the following rules:

| Scale      | Rating | Equivalency |
| ---------- | ------ | ----------- |
| Absolute   | +0     | Standard    |
| Percentage | 100%   | Standard    |
| Absolute   | > +200 | Decline     |
| Percentage | > 300% | Decline     |


Conversion to Table, use the following rules:

| Name    | Scale      | Equivalency |
| ------- | ---------- | ----------- |
| Table 1 | Textual    | Standard    |
| Table 2 | Percentage | 150%        |
| Table 3 | Percentage | 175%        |
| Table 4 | Percentage | 200%        |

## Examples

Below are couple of examples on the expected output:

### Example 1
user:
+150
assistant:
{
    "rating": "+150",
    "scale": "absolute",
    "additional_comments": null
    "equivalent": {
        "percentage": "250%",
        "text": "Decline",
        "table": None,
        "absolute": "+150"
    }
}

### Example 2
user:
100%
assistant:
{
    "rating": "100%",
    "scale": "percentage",
    "additional_comments": null
    "equivalent": {
        "percentage": "100%",
        "text": "Standard",
        "table": "Table 1",
        "absolute": "+0"
    }
}


### Example 3
user:
IC depending on the level of control
assistant:
{
    "rating": "IC",
    "scale": "text",
    "additional_comments": "Depends on the level of control"
    "equivalent": {}
}

### Example 4
user:
Table 4
assistant:
{
    "rating": "Table 4",
    "scale": "table",
    "additional_comments": null
    "equivalent": {
        "percentage": "200%",
        "absolute": "+100",
        "text": "Substandard",
        "table": "Table 4"
    }
}

### Example 5
user:
Decline
assistant:
{
    "rating": "Decline",
    "scale": "text",
    "additional_comments": null,
    "equivalent": {}
}

For decline, IC, RMD or NA, No need to fill "equivalent" section. 